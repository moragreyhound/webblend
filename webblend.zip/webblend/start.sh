#!/usr/bin/env sh
# WebBlend Studio launcher for macOS and Linux.
#
# Installs the single pinned dependency (three) on first run, then starts the
# local static server. Everything else happens in the browser; nothing is sent
# off the machine.

set -eu

cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 18 or newer is required. Install it from https://nodejs.org/." >&2
  exit 1
fi

if [ ! -d node_modules/three ]; then
  echo "Installing dependencies (first run)…"
  npm install
fi

echo "Starting WebBlend Studio…"
exec npm start
