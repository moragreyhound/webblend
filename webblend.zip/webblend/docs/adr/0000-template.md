# ADR-<NNNN>: <Short decision title>
- **Status:** Proposed | Accepted | Superseded by ADR-<NNNN> | Deprecated
- **Date:** <YYYY-MM-DD>
- **Deciders (human, accountable):** <names>
- **AI assistance:** <none | tool + how used; human selection rationale>

## Context
<Problem, constraints, forces, requirements (security, privacy, licensing, performance, brand/UX).>

## Options Considered
1. <Option A> — pros / cons / risks / cost
2. <Option B> — pros / cons / risks / cost

## Decision
<What we chose and why. The human creative/architectural contribution is explicit here.>

## Consequences
- Positive: <...>   - Negative/trade-offs: <...>   - Follow-ups: <...>

## Compliance Impact
Security: <...> · Privacy/Data inventory: <...> · Licensing/SBOM: <...> · Accessibility: <...> · Performance budget: <...>

## Rollout & Rollback
<Flags, migration plan, monitoring, rollback steps.>
