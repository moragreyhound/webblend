# Data Subject Request (DSR) Runbook
Statutory clocks: GDPR/UK GDPR 1 month (extendable); CCPA/CPRA 45 days (extendable) — confirm with counsel.

1. **Intake** — verify identity proportionately; log request ID, type (access/export/rectify/erase/restrict/object/opt-out), timestamp.
2. **Scope** — locate data via `docs/data-inventory.md` (primary DB, replicas, caches, search, vector stores, analytics, logs, object storage, processors).
3. **Execute**
   - Access/Export: machine-readable bundle (JSON/CSV), delivered through an authenticated, expiring link.
   - Erasure: cascading delete job + processor purge requests; backups expire per schedule or are crypto-shredded; legal-hold exceptions documented.
   - Opt-out/GPC: update consent store; propagate to downstream processors.
4. **Verify** — automated test/query proves no residual personal data; record evidence.
5. **Respond** — confirmation to requester; record completion date.
6. **Audit** — retain minimal request record (no unnecessary personal data) for compliance evidence.
