# AI Agent Rule Exceptions

> Only human maintainers may add or edit entries. Expired entries are void and must be removed.

| ID | Rule ID / section | Scope (paths, services) | Justification | Compensating controls | Risk accepted by | Approver | Date granted | Expires |
|---|---|---|---|---|---|---|---|---|

## Rules
- Maximum duration 90 days; renewal requires re-review.
- Security-critical rules (§2, §4) require two approvers including a security owner.
- Every exception must link to a tracking issue and a remediation plan.
