# Data Inventory & Flow Register

| Data element | Category | Classification | Purpose | Legal basis | Source | Stored in | Processors / recipients | Region | Retention | Deletion mechanism | Encrypted (rest/transit) | Access roles | DSR supported (access/export/erase) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| email | Contact | Confidential (PII) | Account auth, notices | Contract | User input | `users.email` | <Email vendor> | <EU> | Life of account + <30d> | Cascade delete + vendor purge | Yes/Yes | owner, support | Yes/Yes/Yes |
| <field> | <category> | <class> | <purpose> | <basis> | <source> | <store> | <vendors> | <region> | <retention> | <mechanism> | <enc> | <roles> | <dsr> |

## Data Classes
- **Public:** intended for public release.
- **Internal:** operational, low sensitivity.
- **Confidential:** PII, business-sensitive.
- **Restricted:** PHI, credentials, financial identifiers, children's data, special-category data.

## Change Control
Any PR adding a field, store, vendor, log sink, or export MUST update this file. Reviewers verify purpose, minimization, retention, and erasure coverage (caches, indexes, vector stores, analytics, backups).
