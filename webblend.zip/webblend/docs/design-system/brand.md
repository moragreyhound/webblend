# Brand Guide — <PRODUCT NAME>
Version <x.y> · Owner: <design lead> · Last reviewed: <YYYY-MM-DD>

## 1. Positioning
- **Audience:** <primary users, their context, their goals>
- **Promise:** <one sentence: what we do, for whom, why better>
- **Competitive contrast:** <3 competitors and how we visibly differ>

## 2. Personality ("this, not that")
| We are | We are not |
|---|---|
| <Precise> | <Pedantic> |
| <Calm> | <Sleepy> |
| <Confident> | <Arrogant> |
| <Warm> | <Cutesy> |

## 3. Visual Principles (settle design arguments)
1. <e.g., Density over decoration — show data, remove chrome.>
2. <e.g., One accent, used sparingly to mark what matters.>
3. <e.g., Motion explains; it never entertains.>
4. <e.g., Typography does the heavy lifting.>

## 4. Signature Devices (what makes us recognizable)
- Shape language: <radius scale and rationale>
- Type pairing: <families, roles, weights>
- Color signature: <primary accent + neutral tint>
- Motion character: <durations, easing, what animates>
- Imagery/illustration style: <rules>

## 5. Voice & Tone
- Voice attributes: <3–5>
- Tone map: success / error / destructive / onboarding / billing / security (see AGENTS.md §6.5)
- **Lexicon** — Prefer: <term list>. Avoid: <term list>. Capitalization: <sentence case>.
- Banned phrases: seamless, unlock, supercharge, revolutionize, game-changing, effortless, leverage (unless quoted).

## 6. Logo
- Files: `/public/brand/logo.svg`, `logo-mono.svg`, `logo-reversed.svg`, `mark.svg`
- Clear space: <1× mark height>. Minimum size: <24px mark / 96px wordmark>.
- Backgrounds: <approved>. Misuse: no recolor, stretch, rotate, effects, or recreation.

## 7. Color
- Primitive ramps and semantic roles: see `tokens.css` / `tokens.json`.
- Contrast pairs verified in CI: <link to script/report>.
- Data-viz palettes: categorical (<n>), sequential, diverging.

## 8. Typography
- Families, licenses, subsets, and loading strategy: <details>
- Scale and roles: <display/h1–h6/body/caption/code>

## 9. Do / Don't Gallery
| Do | Don't |
|---|---|
| <link to approved screens> | <link to rejected "slop" examples> |

## 10. Application Surfaces Checklist
App UI · Marketing site · Emails · Error pages (404/500/offline) · Docs · Status page · PDFs/exports · CLI/README · Social/OG images · App store assets

## 11. Governance
Brand changes require updating this guide and tokens first, a design review, and updated visual-regression baselines.
