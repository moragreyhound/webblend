# Design System

## Layers
tokens → primitives (Button, Input, Text, Icon, Stack) → composites (Field, Dialog, Menu, Table) → features → pages

## Contribution Rules
1. Search the catalog before creating a component; extend via variants.
2. Each component ships: API docs, a11y notes (roles, keys, focus), all states as stories, tests (unit + a11y + visual), and a migration note if breaking.
3. Controlled/uncontrolled behavior is documented; forwards refs; spreads safe DOM props only.
4. Styling uses tokens only; no raw values; supports light/dark/high-contrast/RTL/compact.
5. No new dependency for a single component without a size/license review (AGENTS.md §3, §7).

## Component Status
| Component | Status (Draft/Beta/Stable) | Owner | A11y audited | Visual tests | Notes |
|---|---|---|---|---|---|
| Button | Stable | <name> | Yes | Yes | |
| Dialog | Stable | <name> | Yes | Yes | Uses `<dialog>`/Radix |
| <...> | | | | | |

## Required Story States
default · hover · focus-visible · active · disabled · loading · error · success · empty · long-content · RTL · dark · compact
