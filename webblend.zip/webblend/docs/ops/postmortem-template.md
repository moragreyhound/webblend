# Postmortem — <Incident title> (INC-<ID>)
Severity: <S0–S3> · Date: <YYYY-MM-DD> · Duration: <hh:mm> · Author: <name> · Status: Draft | Final

## Summary
<What happened, who was affected, how it was resolved.>

## Impact
Users/tenants affected · Data exposure (Y/N, categories) · SLO/error-budget impact · Legal/regulatory notification required (Y/N, deadlines).

## Timeline (UTC)
| Time | Event |
|---|---|

## Root Cause & Contributing Factors
<Technical, process, and human factors. Blameless.>

## What Went Well / What Didn't / Where We Got Lucky

## Action Items
| Action | Type (prevent/detect/mitigate) | Owner | Due | Ticket |
|---|---|---|---|---|

## Compliance Follow-up
Credentials rotated · Regulators/customers notified · Data inventory/threat model/AGENTS.md updated.
