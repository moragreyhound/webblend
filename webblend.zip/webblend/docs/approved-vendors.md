# Approved Vendors, Processors, SDKs & AI Services

> Nothing that sends data off-device or off-network may be added unless listed here with status "Approved".
> Agents MUST NOT add entries. Humans complete and sign every row.

| Vendor / SDK | Purpose | Data categories sent | Classification | Region(s) | Legal basis | DPA/BAA signed? | Consent required? | Retention | Owner | Approved by / date | Review due | Status |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| <Example Analytics> | Product analytics | Pseudonymous event data | Internal | <EU> | Consent | <Yes (date)> | Yes | <14 months> | <name> | <name, YYYY-MM-DD> | <YYYY-MM-DD> | <Approved/Pending/Rejected> |
| <Example LLM Provider> | Feature X (text generation) | Prompts excluding PII/PHI | Confidential | <US/EU> | Contract | <Yes> | No | <zero-retention> | <name> | <name, date> | <date> | <Status> |

## Rules
1. **PHI** may only be sent to vendors with a signed **BAA**.
2. **Personal data** requires a signed **DPA** and a transfer mechanism for cross-border flows.
3. **AI/LLM vendors:** no training on customer data; documented retention; prompt/response logging policy reviewed.
4. **Telemetry/analytics** must be consent-gated where required and honor GPC/opt-outs.
5. Review each vendor at least annually and on any change in terms, ownership, or breach.
