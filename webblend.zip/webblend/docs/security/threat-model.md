# Threat Model — <Feature/Service>
Owner: <name> · Date: <YYYY-MM-DD> · Reviewers: <security>

## 1. Scope & Assets
Assets: <data, credentials, availability, reputation>. Entry points: <routes, queues, uploads, webhooks, admin tools>.

## 2. Data Flow Diagram
<mermaid or link>. Trust boundaries marked.

## 3. STRIDE Analysis
| Threat | Component | Scenario | Likelihood | Impact | Mitigation | Test | Status |
|---|---|---|---|---|---|---|---|
| Spoofing | Auth | Stolen session cookie | M | H | HttpOnly, rotation, device binding | `auth.session.test` | Done |
| Tampering | API | Mass assignment on profile | M | H | Allow-listed schema | `profile.schema.test` | Done |
| Repudiation | Admin | Unlogged privilege change | L | H | Append-only audit log | `audit.test` | Done |
| Information disclosure | DB | Missing RLS | M | H | RLS + CI tests | `rls.test.sql` | Done |
| Denial of service | Public API | Expensive query abuse | H | M | Rate limit, pagination caps | `ratelimit.test` | Done |
| Elevation of privilege | RBAC | IDOR on tenant resource | M | H | Object-level checks | `bola.test` | Done |

## 4. Abuse & Misuse Cases (incl. LLM features)
Prompt injection, data exfiltration through tools, cost abuse, scraping, enumeration.

## 5. Residual Risk & Sign-off
Accepted by: <name/date>. Linked exceptions: <EXC-IDs>.
