# License Approvals & Exceptions

| ID | Component / snippet | Version | License (SPDX) | Usage (link/dynamic/static/copy) | Distribution model (SaaS/binary/library) | Obligations | Risk | Approved by | Date | Expiry/Review | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|
| LIC-0001 | <package> | <x.y.z> | <LGPL-3.0-only> | <dynamic link> | <SaaS> | <Provide source of LGPL lib mods> | <Low/Med/High> | <legal/maintainer> | <YYYY-MM-DD> | <YYYY-MM-DD> | <rationale> |

## Policy Summary
- **Default allow:** MIT, BSD-2/3, Apache-2.0, ISC, 0BSD, CC0/Unlicense.
- **Needs approval:** LGPL, MPL-2.0, EPL, CDDL.
- **Prohibited without legal sign-off:** GPL, AGPL, SSPL, BUSL, Commons Clause, non-commercial or field-of-use licenses, unlicensed code.
- Agents MUST NOT add rows. Humans approve.
