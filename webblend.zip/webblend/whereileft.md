# Where I left off — WebBlend Studio

_Last updated: after wiring the full app, styles, launch scripts and docs. The
project is runnable end-to-end. This file is a working handoff note, not a
deliverable._

## Objective

Convert the single-file `index.html` Blender-style editor into a multi-file
Node.js project, keeping every original feature and adding: Roblox Studio-style
camera/navigation, Google Material Symbols icons, particles + smoke, custom file
import (OBJ/GLTF/GLB/STL/PLY/FBX), bones/armature, and wireframe shading.

## Status: working, verified to the extent this machine allows

`npm start` serves the app; every first-party module parses; unit tests pass; the
HTTP surface returns 200 with correct MIME types; the CSP nonce is injected; path
traversal is rejected; and the whole ES module graph resolves (including the
import-map entries for `three` and `three/addons/`).

**The one thing NOT verified is a live browser run.** This session has no desktop
browser attached, so WebGL rendering, pointer interaction and the Google icon
requests were not executed. Everything else below was actually run.

## How to run

```sh
./start.sh      # macOS / Linux   (installs three on first run, then serves)
start.bat       # Windows
# or
npm install && npm start          # http://127.0.0.1:5173
```

Optional env vars: `HOST` (default `127.0.0.1`), `PORT` (default `5173`).

## Verification actually performed

| Check | Command | Result |
| --- | --- | --- |
| Syntax of all first-party JS | `npm run check` | 40/40 modules parsed |
| Unit tests (pure layers) | `npm test` | 43/43 passing |
| HTTP routes + MIME | `fetch` against `/`, `/src/main.js`, `/styles/*.css`, `/vendor/three/build/three.module.js`, `/healthz` | all 200, correct `content-type` |
| Served CSS is the on-disk file | sha256(served) vs sha256(local) | match |
| CSP + nonce injection | header inspection + HTML scan | nonce present, `{{CSP_NONCE}}` gone |
| Traversal / dotfile guards | `/src/../server.js`, `/.env`, `/src/%2e%2e/server.js` | all 404 |
| Module graph | static import scan (90 specifiers, 32 modules) | all resolve |

Not run: Lighthouse, a11y manual pass, visual review.

## Recent fixes (reported from a live browser)

| Symptom | Cause | Fix |
| --- | --- | --- |
| `TypeError: Private method '#tick' is not writable` at `new Viewport` → fatal boot panel | `this.#tick = this.#tick.bind(this)` assigned to a private **method** (non-writable). An extracted private method also loses `this`, so the bind itself was necessary. | Bind onto a public property: `this.tick = this.#tick.bind(this)`, and use `this.tick` in both `requestAnimationFrame` calls (`src/scene/viewport.js`). |
| `THREE.Clock: This module has been deprecated … use THREE.Timer` | three r183+ deprecates `Clock`. | Replaced with `THREE.Timer` + `connect(document)`: `#tick(timestamp)` calls `this.timer.update(timestamp)` then `getDelta()`; `dispose()` calls `this.timer.dispose()`. Verified `new THREE.Timer()` round-trips a 16 ms delta to `0.016`. |

Re-verified after the fix: `npm run check` 40/40 · `npm test` 43/43 · served
`/src/scene/viewport.js` contains the corrected lines and no `THREE.Clock`.

## What is DONE

**Server / tooling**
- `server.js` — dependency-free static server: allowlisted mounts, traversal
  rejection, GET/HEAD only, nonce CSP, `{{CSP_NONCE}}` injection, `/healthz`.
- `scripts/check.mjs` — `node --check` over `server.js src scripts tests`.
- `package.json` — scripts `start`/`dev`/`check`/`test`; `three@0.186.1` (pinned, MIT).
- `start.sh`, `start.bat`, `.gitignore`, `README.md`.

**Shell / styles**
- `index.html` — dark-first shell, inline-SVG favicon, token + app CSS, nonce'd
  import map, `#app`, `<noscript>` fallback.
- `public/styles/tokens.css` — the only place raw values live. Contrast ratios
  were computed (not asserted) and pass AA.
- `public/styles/app.css` — full component + layout CSS, tokens only, three-theme
  hooks, responsive breakpoints.

**Core / logic (pure, unit-tested)**
- `src/core/{math,names,bus,history,theme,version}.js`
- `src/anim/{keyframes,timeline}.js`
- `src/io/format.js` (pure) — with `src/io/files.js` for DOM/three import/export.

**Scene / objects**
- `src/scene/{viewport,camera,transform,picking,editing}.js`
- `src/objects/{registry,particles,armature}.js`
- `src/world.js` — entries, create/remove/duplicate/rename/visibility,
  serialize/restore, undo/redo, gizmo-drag snapshots, `stats()`, `addImported`.

**UI / orchestration**
- `src/ui/{dom,icons,notifications,navcube,shortcuts,fields,outliner,inspector,`
  `timeline-panel,toolbar,statusbar}.js`
- `src/app.js` — single wiring point (`boot(root)`), full `commands` surface,
  pointer/box-select, drag-and-drop, per-frame update.
- `src/main.js` — entry point with a CSP-safe fatal-error panel.

**Docs / compliance artifacts** (Appendix B templates, placeholders intact)
- `SECURITY.md`, `THIRD_PARTY.md`, `.env.example`, `lighthouserc.json`,
  `budget.json`, `docs/**`, `.github/**`, `supabase/tests/rls.test.sql`.

## What REMAINS

Nothing is required to run the app. The remaining work is review-and-verify:

1. **Browser/WebGL smoke test** — load it, click through add/transform/animate/
   import/export, confirm no console errors. This is the biggest unverified gap.
2. **Manual a11y pass** — keyboard-only + a screen reader; only automated/
   structural checks were done.
3. **Lighthouse / performance** — run `lighthouserc.json`; the JS budget will
   fail for the reason below.
4. **Light-theme toggle** — tokens exist; no UI switch is wired yet.
5. **`check:contrast` / `check:routes` scripts** — the CI template references
   them; they are not implemented (contrast was verified by hand).

## Known limitations (honest list)

- **JS budget**: the three.js bundle is ~660 KB; the repo's 170 KB target cannot
  be met by a Three.js app. Needs a human exception (below).
- **Imported-model project save**: `Object3D.toJSON` stores blob-URL texture
  sources that do not survive a page reload. Re-import source files after a
  reload. (Meshes/transforms themselves restore fine.)
- **Icons**: Material Symbols SVGs fetched from `fonts.gstatic.com` are black, so
  they are inverted in CSS to stay legible on the dark chrome; an inline-SVG
  fallback replaces them on error/offline.
- **Responsive**: desktop tool. ≤980 px the inspector hides, ≤720 px the outliner
  hides. View-cube and keyframe hit targets are ~30 px / ~16 px (below the 44 px
  touch ideal; keyboard alternatives exist).
- **No brand guide** exists, so the neutral dark studio theme was used.

## OPEN ITEMS REQUIRING A HUMAN (escalation — do not silently resolve)

- **No brand guide** → used a documented dark studio theme + Baseline-theme
  tokens; a brand questionnaire / sign-off is needed (AGENTS.md §6.1).
- **Google Material Symbols** load from `fonts.gstatic.com`, which reveals the
  viewer's IP to Google. Needs a signed `docs/approved-vendors.md` row; the
  inline-SVG fallback mitigates but does not remove the request.
- **Performance budget exception**: the §7.2 JS budget cannot be met. A human
  must record an exception in `docs/agents-exceptions.md`; agents must not.
- **Greenfield subsystem** (§3.1): needs a named human architect/approver and
  an AI-assistance disclosure on the PR.
- `AGENTS - Copy.md` is the user's file and must stay untouched.

## Size (lines of first-party code)

Excludes `node_modules/` and the user's `AGENTS - Copy.md`.

| Area | Lines | Files |
| --- | ---: | ---: |
| `src/` | 6,451 | 32 |
| `public/` (tokens + app CSS) | 1,596 | 2 |
| root (server, html, scripts, manifest) | 738 | 14 |
| `tests/` | 337 | 6 |
| `docs/` | 338 | 13 |
| `.github/` | 133 | 3 |
| `scripts/` | 49 | 1 |
| `supabase/` | 34 | 1 |
| **Total** | **9,676** | **72** |

Application code alone (server + HTML/CSS/JS + tests + scripts): **8,804** lines.
