// Syntax-checks every first-party JavaScript module with `node --check`.
// Zero dependencies: this is the repo's cheap static gate (AGENTS.md 8.2).
import { spawnSync } from 'node:child_process';
import { readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const TARGETS = ['server.js', 'src', 'scripts', 'tests'];
const EXTENSIONS = new Set(['.js', '.mjs']);

function walk(entry, out = []) {
  const abs = path.join(ROOT, entry);
  let info;
  try {
    info = statSync(abs);
  } catch {
    return out;
  }
  if (info.isDirectory()) {
    for (const child of readdirSync(abs)) {
      if (child === 'node_modules') continue;
      walk(path.join(entry, child), out);
    }
  } else if (EXTENSIONS.has(path.extname(abs))) {
    out.push(abs);
  }
  return out;
}

const files = TARGETS.flatMap((t) => walk(t));
let failures = 0;

for (const file of files) {
  const result = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
  const rel = path.relative(ROOT, file);
  if (result.status === 0) {
    console.log(`ok    ${rel}`);
  } else {
    failures += 1;
    console.error(`FAIL  ${rel}\n${result.stderr.trim()}`);
  }
}

console.log(`\n${files.length - failures}/${files.length} modules parsed.`);
if (failures > 0) {
  console.error(`${failures} module(s) failed the syntax check.`);
  process.exit(1);
}
