# Security Policy

## Supported Versions
| Version | Supported until | Notes |
|---|---|---|
| <MAJOR.MINOR> | <YYYY-MM-DD> | Security fixes |
| < <MAJOR.MINOR> | End of support | Upgrade required |

## Reporting a Vulnerability
Please **do not open a public issue** for security problems.

- Email: <security@your-domain.example>  (PGP key: <FINGERPRINT / link>)
- Or use GitHub's private vulnerability reporting: <repository>/security/advisories/new
- Include: affected component/version, reproduction steps, impact, and any proof of concept.

## Our Commitments
- Acknowledge receipt within **<2> business days**.
- Provide an initial assessment within **<7> days** and status updates at least every **<14> days**.
- Coordinate disclosure; target fix and advisory within **<90> days** (sooner for actively exploited issues).
- Credit reporters who wish to be credited. No legal action for good-faith research that follows this policy
  (avoid privacy violations, data destruction, and service degradation).

## Scope
In scope: <list of repositories, domains, apps>.
Out of scope: social engineering, physical attacks, third-party services, denial-of-service testing, automated scanner noise without a demonstrated impact.

## Security Updates
- Security releases are published as <tags / advisories / changelog entries> and announced via <channel>.
- Automatic update mechanism: <describe, or N/A>. Users can opt out via <setting>.
- Software Bill of Materials (CycloneDX/SPDX) is published with each release: <location>.

## Handling of Actively Exploited Vulnerabilities and Severe Incidents
Maintainers follow `docs/ops/postmortem-template.md` and applicable legal reporting obligations
(e.g., EU CRA reporting duties, GDPR breach notification). Contact: <incident-response@your-domain.example>.
