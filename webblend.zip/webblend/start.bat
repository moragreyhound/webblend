@echo off
rem WebBlend Studio launcher for Windows.
rem
rem Installs the single pinned dependency (three) on first run, then starts the
rem local static server. Everything else happens in the browser.

setlocal
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 18 or newer is required. Install it from https://nodejs.org/. 1>&2
  exit /b 1
)

if not exist "node_modules\three" (
  echo Installing dependencies ^(first run^)...
  call npm install
  if errorlevel 1 exit /b 1
)

echo Starting WebBlend Studio...
call npm start
