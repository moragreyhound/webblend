// Entry point. Keeps the boot sequence in one place so app.js stays pure wiring:
//  - resolve the mount element
//  - start the application, converting any failure into a readable error panel
//    instead of a blank screen (AGENTS.md 5.1: no blank/console-only failures)
//
// The failure panel is built with DOM APIs (createElement/textContent) because
// the server sends a Content-Security-Policy without 'unsafe-inline'; no markup
// is ever parsed from strings.

import { boot } from './app.js';
import { APP_NAME } from './core/version.js';

const root = document.getElementById('app');

/** Build a persistent, actionable error panel. */
function showFatal(headline, detail) {
  const existing = document.getElementById('fatal-error');
  if (existing) existing.remove();

  const panel = document.createElement('div');
  panel.id = 'fatal-error';
  panel.className = 'fatal';
  panel.setAttribute('role', 'alert');

  const title = document.createElement('h1');
  title.className = 'fatal__title';
  title.textContent = headline;

  const message = document.createElement('p');
  message.className = 'fatal__message';
  message.textContent = detail;

  const hint = document.createElement('p');
  hint.className = 'fatal__hint';
  hint.textContent = 'Reload the page to try again. If the problem persists, check the browser console for details.';

  const reload = document.createElement('button');
  reload.type = 'button';
  reload.className = 'btn btn--primary';
  reload.textContent = 'Reload';
  reload.addEventListener('click', () => window.location.reload());

  panel.append(title, message, hint, reload);

  const mount = root ?? document.body;
  mount.replaceChildren(panel);
}

if (!root) {
  // Nothing to mount into; surface it rather than failing silently.
  showFatal(`${APP_NAME} could not start`, 'The #app mount element is missing from the page.');
} else {
  try {
    const app = boot(root);

    // Any error that escapes a listener/handler surfaces here instead of
    // silently breaking the editor.
    window.addEventListener('error', (event) => {
      console.error('[main] uncaught error', event.error ?? event.message);
    });
    window.addEventListener('unhandledrejection', (event) => {
      console.error('[main] unhandled promise rejection', event.reason);
    });

    // Expose a tiny teardown hook for debugging in the console.
    window.__webblend = { dispose: () => app.dispose() };
  } catch (error) {
    console.error('[main] failed to start', error);
    showFatal(
      `${APP_NAME} could not start`,
      error instanceof Error ? error.message : String(error),
    );
  }
}
