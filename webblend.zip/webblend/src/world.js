// The editable scene: the list of entries, their selection, creation/removal,
// serialization, and the undo history.
//
// An "entry" is the editor's unit of work. It wraps a Three.js Object3D plus
// the metadata the editor needs (type, name, kind, keyframes and kind-specific
// state). The viewport only ever sees the raw Object3D roots.

import * as THREE from 'three';
import { bus } from './core/bus.js';
import { History } from './core/history.js';
import { uniqueName, sanitizeName } from './core/names.js';
import { getType, defaultNameFor, PRIMITIVE_DATA } from './objects/registry.js';
import { ParticleSystem } from './objects/particles.js';
import { createArmature, applyBoneAngles, getBoneAngles, defaultBoneAngles } from './objects/armature.js';

let idCounter = 0;
function makeId() {
  idCounter += 1;
  return `e${Date.now().toString(36)}${idCounter.toString(36)}`;
}

function lightHelperFor(light) {
  if (light.isPointLight) return new THREE.PointLightHelper(light, 0.35);
  if (light.isDirectionalLight) return new THREE.DirectionalLightHelper(light, 0.7);
  if (light.isSpotLight) return new THREE.SpotLightHelper(light);
  if (light.isHemisphereLight) return new THREE.HemisphereLightHelper(light, 0.4);
  return null;
}

function cameraHelperFor(camera) {
  const helper = new THREE.CameraHelper(camera);
  helper.name = '__helper';
  return helper;
}

export class World {
  constructor(viewport) {
    this.viewport = viewport;
    this.entries = [];
    this.history = new History(200);
    this.selectedId = null;
    this.#pendingDrag = null;
  }

  #pendingDrag;

  get selectedEntry() {
    return this.entries.find((e) => e.id === this.selectedId) ?? null;
  }

  /** Object roots eligible for ray picking. */
  pickRoots() {
    return this.entries.filter((e) => e.visible !== false).map((e) => e.object);
  }

  entryForObject(object) {
    let node = object;
    while (node) {
      if (node.userData?.entryId) {
        return this.entries.find((e) => e.id === node.userData.entryId) ?? null;
      }
      node = node.parent;
    }
    return null;
  }

  get names() {
    return this.entries.map((e) => e.name);
  }

  /** Place a new object just in front of the current view. */
  #spawnPosition(height = 0.5) {
    const dir = new THREE.Vector3();
    this.viewport.camera.getWorldDirection(dir);
    const pos = this.viewport.camera.position.clone().addScaledVector(dir, 7);
    pos.y = Math.max(pos.y, height);
    return pos;
  }

  create(typeId, options = {}) {
    const type = getType(typeId);
    if (!type) throw new Error(`Unknown type: ${typeId}`);

    const name = uniqueName(
      options.name ?? defaultNameFor(typeId),
      this.names,
    );
    const id = makeId();
    const entry = {
      id,
      name,
      typeId,
      kind: type.kind,
      visible: true,
      keys: options.keys ?? [],
      data: {},
      object: null,
      particles: null,
      armature: null,
      aux: [],
    };

    if (type.kind === 'mesh') {
      entry.object = type.make(PRIMITIVE_DATA[typeId] ?? {});
      entry.data.primitive = { ...(PRIMITIVE_DATA[typeId] ?? {}) };
      entry.data.material = this.#readMaterial(entry.object.material);
    } else if (type.kind === 'light') {
      entry.object = type.make({});
      entry.data.light = this.#readLight(entry.object);
    } else if (type.kind === 'camera') {
      entry.object = type.make({});
      entry.data.camera = { fov: entry.object.fov, near: entry.object.near, far: entry.object.far };
      entry.aux.push(this.#makeHelper(cameraHelperFor(entry.object)));
    } else if (type.kind === 'empty') {
      entry.object = type.make({});
    } else if (type.kind === 'particles' || type.kind === 'smoke') {
      const presetId = type.kind === 'smoke' ? 'smoke' : 'spark';
      const position = options.at ? new THREE.Vector3().fromArray(options.at) : this.#spawnPosition(1.2);
      entry.particles = new ParticleSystem(position, presetId);
      entry.object = entry.particles.points;
      entry.data.particles = entry.particles.toJSON();
      entry.object.position.copy(position);
    } else if (type.kind === 'armature') {
      const armature = createArmature({ boneCount: options.boneCount ?? 3 });
      entry.armature = armature;
      entry.object = armature.root;
      entry.data.armature = { boneCount: armature.boneCount, angles: defaultBoneAngles(armature.boneCount) };
      this.viewport.addEditorObject(armature.helper);
      entry.aux.push(armature.helper);
    }

    entry.object.name = name;
    entry.object.userData.entryId = id;

    if (type.kind === 'mesh' || type.kind === 'empty') {
      entry.object.position.copy(options.at ? new THREE.Vector3().fromArray(options.at) : this.#spawnPosition(0.5));
    } else if (type.kind !== 'particles' && type.kind !== 'smoke') {
      entry.object.position.copy(options.at ? new THREE.Vector3().fromArray(options.at) : this.#spawnPosition(1));
    }

    // Light/skin helpers ride along with the object.
    if (type.kind === 'light') {
      const helper = lightHelperFor(entry.object);
      if (helper) entry.aux.push(this.#makeHelper(helper));
    }

    this.entries.push(entry);
    this.viewport.add(entry.object);
    bus.emit('world.change', { reason: 'create', entry });
    if (options.select !== false) this.select(entry.id);
    return entry;
  }

  #makeHelper(helper) {
    helper.name = '__helper';
    this.viewport.addEditorObject(helper);
    return helper;
  }

  #readMaterial(material) {
    if (!material || Array.isArray(material)) return null;
    return {
      color: `#${material.color.getHexString()}`,
      roughness: material.roughness ?? 0.65,
      metalness: material.metalness ?? 0.1,
      flatShading: !!material.flatShading,
      wireframe: !!material.wireframe,
      opacity: material.opacity ?? 1,
      transparent: !!material.transparent,
    };
  }

  #readLight(light) {
    return {
      color: `#${light.color.getHexString()}`,
      intensity: light.intensity,
      distance: light.distance ?? 0,
      angle: light.angle ?? 0,
      penumbra: light.penumbra ?? 0,
      castShadow: !!light.castShadow,
    };
  }

  remove(entryOrId) {
    const entry = typeof entryOrId === 'string'
      ? this.entries.find((e) => e.id === entryOrId)
      : entryOrId;
    if (!entry) return false;

    this.#disposeEntry(entry);
    this.viewport.remove(entry.object);
    for (const aux of entry.aux) this.viewport.removeEditorObject(aux);
    this.entries = this.entries.filter((e) => e.id !== entry.id);

    if (this.selectedId === entry.id) {
      this.selectedId = null;
      bus.emit('selection.change', null);
    }
    bus.emit('world.change', { reason: 'remove', entry });
    return true;
  }

  #disposeEntry(entry) {
    entry.particles?.dispose();
    if (entry.armature) entry.aux.push(entry.armature.helper);
    entry.object.traverse?.((node) => {
      if (node.isMesh || node.isPoints) {
        node.geometry?.dispose?.();
        const material = node.material;
        if (Array.isArray(material)) material.forEach((m) => m.dispose?.());
        else material?.dispose?.();
      }
    });
  }

  duplicate(entryOrId) {
    const entry = typeof entryOrId === 'string'
      ? this.entries.find((e) => e.id === entryOrId)
      : entryOrId;
    if (!entry) return null;
    const data = this.serializeEntry(entry);
    data.id = makeId();
    data.name = uniqueName(entry.name, this.names);
    data.transform.position[0] += 1;
    data.transform.position[1] += 0.4;
    return this.deserializeEntry(data, { select: true });
  }

  /** Wrap an already-built object (e.g. a loaded OBJ/GLB) as a mesh entry. */
  addImported(name, object, meta = {}) {
    const id = makeId();
    const finalName = uniqueName(name, this.names);
    const entry = {
      id,
      name: finalName,
      typeId: 'imported',
      kind: 'mesh',
      visible: true,
      keys: [],
      data: {
        imported: { format: meta.format ?? '', source: meta.source ?? '' },
        material: this.#readMaterial(object.material),
      },
      object,
      particles: null,
      armature: null,
      aux: [],
    };
    object.name = finalName;
    object.userData.entryId = id;
    this.entries.push(entry);
    this.viewport.add(entry.object);
    bus.emit('world.change', { reason: 'import', entry });
    this.select(entry.id);
    return entry;
  }

  rename(entry, rawName) {
    if (!entry) return null;
    const next = uniqueName(sanitizeName(rawName, entry.name), this.names.filter((n) => n !== entry.name));
    entry.name = next;
    entry.object.name = next;
    bus.emit('world.entry', entry);
    bus.emit('world.change', { reason: 'rename', entry });
    return next;
  }

  setVisible(entry, flag) {
    if (!entry) return;
    entry.visible = !!flag;
    entry.object.visible = entry.visible;
    bus.emit('world.entry', entry);
    bus.emit('world.change', { reason: 'visibility', entry });
  }

  /** Read an entry's current transform as plain arrays (plus bone angles). */
  objectTransform(entry) {
    const t = {
      position: entry.object.position.toArray(),
      quaternion: entry.object.quaternion.toArray(),
      scale: entry.object.scale.toArray(),
    };
    if (entry.armature) t.bones = getBoneAngles(entry.armature);
    return t;
  }

  applyTransform(entry, transform) {
    if (!entry || !transform) return;
    if (Array.isArray(transform.position)) entry.object.position.fromArray(transform.position);
    if (Array.isArray(transform.quaternion)) entry.object.quaternion.fromArray(transform.quaternion);
    if (Array.isArray(transform.scale)) entry.object.scale.fromArray(transform.scale);
    if (transform.bones && entry.armature) applyBoneAngles(entry.armature, transform.bones);
  }

  select(idOrEntry) {
    const entry = typeof idOrEntry === 'object' ? idOrEntry : this.entries.find((e) => e.id === idOrEntry);
    const nextId = entry ? entry.id : null;
    if (nextId === this.selectedId) return this.selectedEntry;
    this.selectedId = nextId;
    bus.emit('selection.change', this.selectedEntry);
    return this.selectedEntry;
  }

  // ---------------------------------------------------------------------------
  // Serialization
  // ---------------------------------------------------------------------------

  serializeEntry(entry) {
    const base = {
      id: entry.id,
      name: entry.name,
      typeId: entry.typeId,
      kind: entry.kind,
      visible: entry.visible,
      transform: this.objectTransform(entry),
      data: structuredCloneSafe(entry.data),
      keys: entry.keys.map((k) => ({
        f: k.f,
        position: [...k.position],
        quaternion: [...k.quaternion],
        scale: [...k.scale],
        ...(k.bones ? { bones: k.bones.map((row) => [...row]) } : {}),
      })),
    };

    if (entry.kind === 'mesh') {
      base.asset = entry.object.toJSON();
    } else if (entry.kind === 'particles' || entry.kind === 'smoke') {
      base.particles = entry.particles.toJSON();
    } else if (entry.kind === 'armature') {
      base.armature = { boneCount: entry.armature.boneCount, angles: getBoneAngles(entry.armature) };
    } else if (entry.kind === 'light') {
      base.data.light = this.#readLight(entry.object);
    } else if (entry.kind === 'camera') {
      base.data.camera = { fov: entry.object.fov, near: entry.object.near, far: entry.object.far };
    }
    return base;
  }

  deserializeEntry(data, { select = false, atEnd = true } = {}) {
    const type = getType(data.typeId);
    if (!type) throw new Error(`Cannot restore unknown type: ${data.typeId}`);

    const id = data.id ?? makeId();
    const entry = {
      id,
      name: sanitizeName(data.name ?? defaultNameFor(data.typeId)),
      typeId: data.typeId,
      kind: data.kind ?? type.kind,
      visible: data.visible !== false,
      keys: (data.keys ?? []).map((k) => ({
        f: k.f,
        position: [...k.position],
        quaternion: [...k.quaternion],
        scale: [...k.scale],
        ...(k.bones ? { bones: k.bones.map((row) => [...row]) } : {}),
      })),
      data: data.data ? structuredCloneSafe(data.data) : {},
      object: null,
      particles: null,
      armature: null,
      aux: [],
    };

    if (entry.kind === 'mesh' && data.asset) {
      const loader = new THREE.ObjectLoader();
      entry.object = loader.parse(data.asset);
      if (entry.data.material && entry.object.material && !Array.isArray(entry.object.material)) {
        this.#applyMaterial(entry.object.material, entry.data.material);
      }
    } else if (type.kind === 'mesh') {
      entry.object = type.make(entry.data.primitive ?? {});
    } else if (entry.kind === 'light') {
      entry.object = type.make(entry.data.light ?? {});
      this.#applyLight(entry.object, entry.data.light ?? {});
      const helper = lightHelperFor(entry.object);
      if (helper) entry.aux.push(this.#makeHelper(helper));
    } else if (entry.kind === 'camera') {
      entry.object = type.make({});
      Object.assign(entry.object, entry.data.camera ?? {});
      entry.object.updateProjectionMatrix();
      entry.aux.push(this.#makeHelper(cameraHelperFor(entry.object)));
    } else if (entry.kind === 'empty') {
      entry.object = type.make({});
    } else if (entry.kind === 'particles' || entry.kind === 'smoke') {
      const presetId = data.particles?.presetId ?? (entry.kind === 'smoke' ? 'smoke' : 'spark');
      entry.particles = new ParticleSystem(new THREE.Vector3(), presetId);
      entry.particles.applyJSON(data.particles);
      entry.object = entry.particles.points;
      entry.data.particles = entry.particles.toJSON();
    } else if (entry.kind === 'armature') {
      const boneCount = data.armature?.boneCount ?? entry.data.armature?.boneCount ?? 3;
      const armature = createArmature({ boneCount });
      entry.armature = armature;
      entry.object = armature.root;
      entry.data.armature = { boneCount, angles: data.armature?.angles ?? defaultBoneAngles(boneCount) };
      applyBoneAngles(armature, entry.data.armature.angles);
      this.viewport.addEditorObject(armature.helper);
      entry.aux.push(armature.helper);
    } else {
      entry.object = type.make({});
    }

    entry.object.name = entry.name;
    entry.object.userData.entryId = id;
    entry.object.visible = entry.visible;
    this.applyTransform(entry, data.transform);
    // target-carrying lights need their target in the graph
    if (entry.object.isSpotLight) {
      const target = new THREE.Object3D();
      target.position.set(0, -1, 0);
      entry.aux.push(this.#makeHelper(target));
      entry.object.target = target;
    }

    this.entries.push(entry);
    this.viewport.add(entry.object);
    bus.emit('world.change', { reason: 'restore', entry });
    if (select) this.select(entry.id);
    return entry;
  }

  #applyMaterial(material, data) {
    if (data.color) material.color.set(data.color);
    material.roughness = data.roughness ?? material.roughness;
    material.metalness = data.metalness ?? material.metalness;
    material.flatShading = !!data.flatShading;
    material.wireframe = !!data.wireframe;
    material.opacity = data.opacity ?? 1;
    material.transparent = !!data.transparent;
    material.needsUpdate = true;
  }

  #applyLight(light, data) {
    if (data.color) light.color.set(data.color);
    if (Number.isFinite(data.intensity)) light.intensity = data.intensity;
    if (Number.isFinite(data.distance) && 'distance' in light) light.distance = data.distance;
    if (Number.isFinite(data.angle) && 'angle' in light) light.angle = data.angle;
    if (Number.isFinite(data.penumbra) && 'penumbra' in light) light.penumbra = data.penumbra;
    light.castShadow = data.castShadow ?? light.castShadow;
  }

  serialize() {
    return {
      version: 1,
      selectedId: this.selectedId,
      entries: this.entries.map((entry) => this.serializeEntry(entry)),
    };
  }

  replaceFromSerialized(data) {
    this.clear({ silent: true });
    const entries = Array.isArray(data?.entries) ? data.entries : [];
    for (const entryData of entries) {
      try {
        this.deserializeEntry(entryData, { select: false });
      } catch (error) {
        console.error('[world] failed to restore entry', entryData?.name, error);
      }
    }
    this.selectedId = null;
    const wanted = data?.selectedId;
    if (wanted && this.entries.some((e) => e.id === wanted)) this.select(wanted);
    else bus.emit('selection.change', null);
    bus.emit('world.change', { reason: 'replace' });
  }

  clear({ silent = false } = {}) {
    for (const entry of [...this.entries]) {
      this.#disposeEntry(entry);
      this.viewport.remove(entry.object);
      for (const aux of entry.aux) this.viewport.removeEditorObject(aux);
    }
    this.entries = [];
    this.selectedId = null;
    if (!silent) bus.emit('world.change', { reason: 'clear' });
  }

  // ---------------------------------------------------------------------------
  // History
  // ---------------------------------------------------------------------------

  /** Run a mutation and record a single undo step. */
  record(fn) {
    const before = this.serialize();
    const result = fn();
    this.history.push(before);
    bus.emit('world.change', { reason: 'record' });
    return result;
  }

  beginGizmoDrag() {
    this.#pendingDrag = this.serialize();
  }

  endGizmoDrag() {
    if (!this.#pendingDrag) return;
    const changed = JSON.stringify(this.#pendingDrag) !== JSON.stringify(this.serialize());
    if (changed) this.history.push(this.#pendingDrag);
    this.#pendingDrag = null;
  }

  canUndo() {
    return this.history.canUndo();
  }

  canRedo() {
    return this.history.canRedo();
  }

  undo() {
    if (!this.history.canUndo()) return false;
    const current = this.serialize();
    const previous = this.history.undo(current);
    if (!previous) return false;
    this.replaceFromSerialized(previous);
    return true;
  }

  redo() {
    if (!this.history.canRedo()) return false;
    const current = this.serialize();
    const next = this.history.redo(current);
    if (!next) return false;
    this.replaceFromSerialized(next);
    return true;
  }

  stats() {
    const byKind = {};
    let vertices = 0;
    for (const entry of this.entries) {
      byKind[entry.kind] = (byKind[entry.kind] ?? 0) + 1;
      entry.object.traverse?.((node) => {
        const position = node.geometry?.getAttribute?.('position');
        if (position) vertices += position.count;
      });
    }
    return { total: this.entries.length, byKind, vertices };
  }
}

/** structuredClone with a JSON fallback for older engines. */
function structuredCloneSafe(value) {
  if (value == null) return value;
  if (typeof structuredClone === 'function') {
    try {
      return structuredClone(value);
    } catch {
      // fall through to JSON
    }
  }
  return JSON.parse(JSON.stringify(value));
}