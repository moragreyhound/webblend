// CPU-simulated particle systems (sparks + smoke) rendered as soft sprites
// through a small custom ShaderMaterial. Simulation stays on the CPU so it is
// deterministic, cheap to pause, and trivial to serialize (no GPU state).

import * as THREE from 'three';

function makeSoftSpriteTexture() {
  const size = 64;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  const gradient = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  gradient.addColorStop(0, 'rgba(255,255,255,1)');
  gradient.addColorStop(0.35, 'rgba(255,255,255,0.7)');
  gradient.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, size, size);
  return new THREE.CanvasTexture(canvas);
}

const VERTEX = /* glsl */ `
  attribute float aSize;
  attribute float aSeed;
  varying float vAge;
  uniform float uPixelRatio;
  uniform float uFocal;

  void main() {
    vAge = aSeed;
    vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
    float projected = uFocal / max(0.1, -mvPosition.z);
    gl_PointSize = aSize * uPixelRatio * projected;
    gl_Position = projectionMatrix * mvPosition;
  }
`;

const FRAGMENT = /* glsl */ `
  uniform vec3 uColorA;
  uniform vec3 uColorB;
  uniform float uAlpha;
  uniform sampler2D uSprite;
  varying float vAge;

  void main() {
    float t = clamp(vAge, 0.0, 1.0);
    vec4 tex = texture2D(uSprite, gl_PointCoord);
    vec3 color = mix(uColorA, uColorB, t);
    float fade = (1.0 - t) * (1.0 - t);
    float alpha = tex.a * fade * uAlpha;
    if (alpha < 0.012) discard;
    gl_FragColor = vec4(color, alpha);
  }
`;

const PRESETS = {
  spark: {
    count: 240,
    lifetime: 1.4,
    lifetimeJitter: 0.9,
    speed: 2.6,
    size: 0.55,
    sizeJitter: 0.5,
    spread: 2.2,
    gravity: -3.5,
    drift: 0.35,
    colorA: '#ffd166',
    colorB: '#ff7a29',
    alpha: 0.95,
    additive: true,
  },
  smoke: {
    count: 128,
    lifetime: 4.2,
    lifetimeJitter: 1.6,
    speed: 1.1,
    size: 2.4,
    sizeJitter: 1.1,
    spread: 0.5,
    gravity: 0.9,
    drift: 0.15,
    colorA: '#7d8594',
    colorB: '#c3cad6',
    alpha: 0.35,
    additive: false,
  },
};

export const PARTICLE_PRESETS = Object.fromEntries(
  Object.entries(PRESETS).map(([id, preset]) => [id, { ...preset }]),
);

export function defaultParticleParams(presetId = 'spark') {
  return { ...PRESETS[presetId] ?? PRESETS.spark };
}

export class ParticleSystem {
  /**
   * @param {import('three').Vector3} emitterPosition initial emitter location
   * @param {string} presetId 'spark' | 'smoke'
   */
  constructor(emitterPosition, presetId = 'spark') {
    const params = defaultParticleParams(presetId);
    const count = Math.max(1, Math.floor(params.count));
    this.params = params;
    this.presetId = PRESETS[presetId] ? presetId : 'spark';
    this.emitting = true;

    this.count = count;
    this.seed = [];
    this.velocities = [];
    this.lifetimes = [];
    this.ages = new Float32Array(count).fill(count); // start dead

    const positions = new Float32Array(count * 3).fill(0);
    const sizes = new Float32Array(count).fill(1);
    const seeds = new Float32Array(count);
    for (let i = 0; i < count; i += 1) {
      positions[i * 3] = emitterPosition.x;
      positions[i * 3 + 1] = emitterPosition.y;
      positions[i * 3 + 2] = emitterPosition.z;
      sizes[i] = 1;
      seeds[i] = 0;
      this.seed.push([emitterPosition.x, emitterPosition.y, emitterPosition.z]);
      this.velocities.push(new THREE.Vector3());
      this.lifetimes.push(0);
    }

    this.geometry = new THREE.BufferGeometry();
    this.geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    this.geometry.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));
    this.geometry.setAttribute('aSeed', new THREE.BufferAttribute(seeds, 1));

    const sharedTexture = ParticleSystem.texture ??= makeSoftSpriteTexture();
    this.material = new THREE.ShaderMaterial({
      vertexShader: VERTEX,
      fragmentShader: FRAGMENT,
      uniforms: {
        uPixelRatio: { value: 1 },
        uFocal: { value: 1 },
        uColorA: { value: new THREE.Color(params.colorA) },
        uColorB: { value: new THREE.Color(params.colorB) },
        uAlpha: { value: params.alpha },
        uSprite: { value: sharedTexture },
      },
      transparent: true,
      depthWrite: false,
      blending: params.additive ? THREE.AdditiveBlending : THREE.NormalBlending,
    });

    this.points = new THREE.Points(this.geometry, this.material);
    this.points.frustumCulled = false;
    this.points.name = 'Particles';
  }

  static texture = null;

  setParams(next) {
    const merged = { ...this.params, ...next };
    // Color & alpha are uniform updates (cheap); bulk re-emission is avoided.
    this.params = merged;
    this.material.uniforms.uColorA.value.set(merged.colorA);
    this.material.uniforms.uColorB.value.set(merged.colorB);
    this.material.uniforms.uAlpha.value = merged.alpha;
    this.material.blending = merged.additive ? THREE.AdditiveBlending : THREE.NormalBlending;
    this.material.needsUpdate = true;
  }

  setEmitting(flag) {
    this.emitting = !!flag;
  }

  /** Emit a burst at an explicit world position (fireworks style). */
  burst(position, count = 40) {
    const base = position || this.points.position;
    for (let i = 0; i < count; i += 1) {
      const index = (this.#cursor + i) % this.count;
      this.#spawn(index, base);
    }
    this.#cursor = (this.#cursor + count) % this.count;
  }

  #cursor = 0;

  #spawn(index, emitter) {
    const p = this.params;
    const e = this.seed[index];
    e[0] = emitter.x;
    e[1] = emitter.y;
    e[2] = emitter.z;
    this.velocities[index].set(
      (Math.random() - 0.5) * p.spread,
      p.speed * (0.55 + Math.random() * 0.9),
      (Math.random() - 0.5) * p.spread,
    );
    const life = Math.max(0.05, p.lifetime + (Math.random() - 0.5) * 2 * p.lifetimeJitter);
    this.lifetimes[index] = life;
    this.ages[index] = 0;
  }

  /** Advance the simulation by dt seconds. Call once per frame. */
  step(dt) {
    const p = this.params;
    const emitter = this.points.position;
    const posAttr = this.geometry.getAttribute('position');
    const seedAttr = this.geometry.getAttribute('aSeed');
    const pos = posAttr.array;
    const seeds = seedAttr.array;

    for (let i = 0; i < this.count; i += 1) {
      if (this.ages[i] >= this.lifetimes[i]) {
        if (this.emitting) this.#spawn(i, emitter);
        seeds[i] = 1;
      } else {
        this.ages[i] += dt;
        const v = this.velocities[i];
        v.y += p.gravity * dt;
        v.x += (Math.random() - 0.5) * p.drift * dt;
        v.z += (Math.random() - 0.5) * p.drift * dt;
        pos[i * 3] += v.x * dt;
        pos[i * 3 + 1] += v.y * dt;
        pos[i * 3 + 2] += v.z * dt;
        seeds[i] = Math.min(1, this.ages[i] / this.lifetimes[i]);
      }
    }
    // Noise added to point size keeps the smoke looking organic while staying cheap.
    const sizeAttr = this.geometry.getAttribute('aSize');
    const sizes = sizeAttr.array;
    if (sizes[0] !== p.size) {
      for (let i = 0; i < this.count; i += 1) {
        sizes[i] = p.size * (0.6 + (Math.random() * p.sizeJitter) % 1);
      }
      sizeAttr.needsUpdate = true;
    }
    posAttr.needsUpdate = true;
    seedAttr.needsUpdate = true;
  }

  toJSON() {
    return {
      presetId: this.presetId,
      params: { ...this.params },
      emitting: this.emitting,
    };
  }

  applyJSON(data) {
    if (!data) return;
    if (data.params) this.setParams(data.params);
    if (data.presetId) this.presetId = data.presetId;
    if (typeof data.emitting === 'boolean') this.setEmitting(data.emitting);
  }

  dispose() {
    this.geometry.dispose();
    this.material.dispose();
  }
}