// Armature: a chain of THREE.Bone nodes with a distance-influenced skinned mesh
// wrapping them. Bones are edited through the Inspector (per-bone angles) and
// can be keyframed on the timeline (each key carries a `bones` array of angles).

import * as THREE from 'three';
import { COLORS } from '../core/theme.js';

const SEGMENT_LENGTH = 1.2;

/** Closest point on segment ab to p. */
function closestPointOnSegment(p, a, b, out) {
  const abX = b.x - a.x;
  const abY = b.y - a.y;
  const abZ = b.z - a.z;
  const len2 = abX * abX + abY * abY + abZ * abZ;
  let t = 0;
  if (len2 > 1e-8) {
    t = ((p.x - a.x) * abX + (p.y - a.y) * abY + (p.z - a.z) * abZ) / len2;
    t = Math.min(1, Math.max(0, t));
  }
  out.set(a.x + abX * t, a.y + abY * t, a.z + abZ * t);
  return t;
}

function distanceToSegment(p, a, b) {
  const closest = new THREE.Vector3();
  closestPointOnSegment(p, a, b, closest);
  return p.distanceTo(closest);
}

/**
 * Build an armature: `boneCount` bones stacked along +Y inside a root Group,
 * with a skinned "limb" mesh influenced by the nearest bones.
 */
export function createArmature({ boneCount = 3 } = {}) {
  const count = Math.max(1, Math.min(8, boneCount));
  const root = new THREE.Group();
  root.name = 'Armature';

  const bones = [];
  const segments = [];
  let parent = null;
  for (let i = 0; i < count; i += 1) {
    const bone = new THREE.Bone();
    bone.name = `Bone.${String(i + 1).padStart(2, '0')}`;
    bone.position.set(0, SEGMENT_LENGTH, 0);
    (parent ?? root).add(bone);
    bones.push(bone);
    parent = bone;
  }

  const material = new THREE.MeshStandardMaterial({
    color: '#8aa0ff',
    roughness: 0.45,
    metalness: 0.2,
    skinning: true,
  });

  // Skin geometry: a tapered limb from the base of the chain to its tip.
  const totalHeight = count * SEGMENT_LENGTH;
  const geo = new THREE.CylinderGeometry(0.22, 0.4, totalHeight, 12, 16 * count);
  geo.translate(0, totalHeight / 2, 0); // base sits at the root origin.

  // Compute per-vertex bone influence by distance to each bone segment at rest.
  const positionAttr = geo.getAttribute('position');
  const vertexCount = positionAttr.count;
  const worldP = new THREE.Vector3();
  const a = new THREE.Vector3();
  const b = new THREE.Vector3(0, SEGMENT_LENGTH, 0);
  const indices = new Uint8Array(vertexCount * 4);
  const weights = new Float32Array(vertexCount * 4);

  for (let i = 0; i < vertexCount; i += 1) {
    worldP.fromBufferAttribute(positionAttr, i);
    const distances = [];
    for (let j = 0; j < count; j += 1) {
      a.set(0, j * SEGMENT_LENGTH, 0);
      b.set(0, (j + 1) * SEGMENT_LENGTH, 0);
      distances.push({ bone: j, d: distanceToSegment(worldP, a, b) });
    }
    distances.sort((x, y) => x.d - y.d);
    const primary = distances[0];
    const secondary = distances[1];
    const d1 = Math.max(0.001, primary.d);
    const d2 = Math.max(0.001, secondary ? secondary.d : 1);
    const w1 = 1 / (1 + d1 * d1);
    const w2 = 1 / (1 + d2 * d2);
    const sum = w1 + w2 || 1;
    indices[i * 4] = primary.bone;
    indices[i * 4 + 1] = secondary ? secondary.bone : primary.bone;
    weights[i * 4] = w1 / sum;
    weights[i * 4 + 1] = w2 / sum;
  }
  geo.setAttribute('skinIndex', new THREE.BufferAttribute(indices, 4));
  geo.setAttribute('skinWeight', new THREE.BufferAttribute(weights, 4));

  const skin = new THREE.SkinnedMesh(geo, material);
  skin.name = 'Skin';
  root.add(skin);
  skin.bind(new THREE.Skeleton(bones));

  // Bone shafts (visual noodles) parented to each bone so they ride the chain.
  for (let i = 0; i < count; i += 1) {
    const shaft = new THREE.Mesh(
      new THREE.CylinderGeometry(0.05, 0.05, SEGMENT_LENGTH * 0.92, 6),
      new THREE.MeshBasicMaterial({ color: COLORS.selection, transparent: true, opacity: 0.85 }),
    );
    shaft.position.y = SEGMENT_LENGTH / 2;
    shaft.name = '__bone';
    bones[i].add(shaft);
  }

  // SkeletonHelper is a scene-graph overlay; caller adds/removes it.
  const helper = new THREE.SkeletonHelper(root);

  const armature = {
    root,
    bones,
    skeleton: skin.skeleton,
    helper,
    boneCount: count,
    segmentLength: SEGMENT_LENGTH,
  };

  applyBoneAngles(armature, defaultBoneAngles(count));
  return armature;
}

/** Zero angles, one row (x,y,z degrees) per bone. */
export function defaultBoneAngles(boneCount) {
  return Array.from({ length: boneCount }, () => [0, 0, 0]);
}

/**
 * Apply per-bone Euler angles (degrees, relative to the parent) to the bones.
 * @param {ReturnType<typeof createArmature>} armature
 * @param {number[][]} angles boneCount rows of [x, y, z] degrees
 */
export function applyBoneAngles(armature, angles) {
  const { bones, boneCount, root } = armature;
  if (!Array.isArray(angles)) return;
  for (let i = 0; i < boneCount; i += 1) {
    const row = angles[i];
    if (!row) continue;
    bones[i].quaternion.setFromEuler(
      new THREE.Euler((row[0] * Math.PI) / 180, (row[1] * Math.PI) / 180, (row[2] * Math.PI) / 180),
      'XYZ',
    );
  }
  // Let the skeleton glue the skin to the updated bone poses.
  root.updateMatrixWorld();
  armature.skeleton.update();
}

export function getBoneAngles(armature) {
  return armature.bones.map((bone) => {
    const e = new THREE.Euler().setFromQuaternion(bone.quaternion, 'XYZ');
    return [(e.x * 180) / Math.PI, (e.y * 180) / Math.PI, (e.z * 180) / Math.PI];
  });
}

export function armatureToJSON(armature) {
  return {
    boneCount: armature.boneCount,
    segmentLength: armature.segmentLength,
    angles: getBoneAngles(armature),
  };
}