// Registry of every object type the editor can create, plus the factories that
// build a Three.js object from a type id. UI metadata (label, icon) lives next
// to the builder so the Add menu and the Outliner stay in sync by construction.

import * as THREE from 'three';
import { COLORS, MATERIAL_DEFAULTS } from '../core/theme.js';

function standardMaterial(overrides = {}) {
  const m = new THREE.MeshStandardMaterial({ ...MATERIAL_DEFAULTS, ...overrides });
  m.name = 'Mat';
  return m;
}

const meshFactories = {
  cube: (opts = {}) => new THREE.Mesh(
    new THREE.BoxGeometry(opts.width ?? 1, opts.height ?? 1, opts.depth ?? 1),
    standardMaterial({ color: opts.color ?? '#8a94a8' }),
  ),
  sphere: (opts = {}) => new THREE.Mesh(
    new THREE.SphereGeometry(opts.radius ?? 0.5, opts.widthSegments ?? 24, opts.heightSegments ?? 16),
    standardMaterial({ color: opts.color ?? '#8a94a8' }),
  ),
  cylinder: (opts = {}) => new THREE.Mesh(
    new THREE.CylinderGeometry(opts.radiusTop ?? 0.5, opts.radiusBottom ?? 0.5, opts.height ?? 1, opts.radialSegments ?? 24),
    standardMaterial({ color: opts.color ?? '#8a94a8' }),
  ),
  cone: (opts = {}) => new THREE.Mesh(
    new THREE.ConeGeometry(opts.radius ?? 0.5, opts.height ?? 1, opts.radialSegments ?? 24),
    standardMaterial({ color: opts.color ?? '#8a94a8' }),
  ),
  torus: (opts = {}) => new THREE.Mesh(
    new THREE.TorusGeometry(opts.radius ?? 0.4, opts.tube ?? 0.15, opts.radialSegments ?? 12, opts.tubularSegments ?? 24),
    standardMaterial({ color: opts.color ?? '#8a94a8' }),
  ),
  torusKnot: (opts = {}) => new THREE.Mesh(
    new THREE.TorusKnotGeometry(opts.radius ?? 0.45, opts.tube ?? 0.12, opts.tubularSegments ?? 64, opts.radialSegments ?? 8),
    standardMaterial({ color: opts.color ?? '#8a94a8' }),
  ),
  plane: (opts = {}) => {
    const mesh = new THREE.Mesh(
      new THREE.PlaneGeometry(opts.width ?? 2, opts.height ?? 2),
      standardMaterial({ color: opts.color ?? '#8a94a8', roughness: 0.5 }),
    );
    mesh.rotation.x = -Math.PI / 2; // Blender-style: a plane lies flat.
    return mesh;
  },
  icosahedron: (opts = {}) => new THREE.Mesh(
    new THREE.IcosahedronGeometry(opts.radius ?? 0.6, opts.detail ?? 0),
    standardMaterial({ color: opts.color ?? '#8a94a8' }),
  ),
};

const lightFactories = {
  point_light: (opts = {}) => {
    const light = new THREE.PointLight(opts.color ?? '#ffd9a0', opts.intensity ?? 30, 20);
    light.castShadow = true;
    return light;
  },
  directional_light: (opts = {}) => {
    const light = new THREE.DirectionalLight(opts.color ?? '#fff4e0', opts.intensity ?? 2);
    light.position.set(3, 6, 4);
    light.castShadow = true;
    return light;
  },
  spot_light: (opts = {}) => {
    const light = new THREE.SpotLight(opts.color ?? '#ffe6bf', opts.intensity ?? 60, 25, Math.PI / 6, 0.5);
    light.position.set(0, 4, 0);
    light.target.position.set(0, 0, 0);
    light.castShadow = true;
    return light;
  },
  hemisphere_light: (opts = {}) => new THREE.HemisphereLight(opts.color ?? '#dce8ff', '#3a4150', opts.intensity ?? 0.8),
};

/**
 * Type table. `kind` drives serialization and inspector behavior.
 * `make(data)` must return an Object3D whose userData.id matches the entry id
 * when the entry id is known (see factory).
 */
export const TYPES = [
  { id: 'cube', kind: 'mesh', label: 'Cube', icon: 'cube', make: meshFactories.cube },
  { id: 'sphere', kind: 'mesh', label: 'Sphere', icon: 'circle', make: meshFactories.sphere },
  { id: 'cylinder', kind: 'mesh', label: 'Cylinder', icon: 'cylinder', make: meshFactories.cylinder },
  { id: 'cone', kind: 'mesh', label: 'Cone', icon: 'change_history', make: meshFactories.cone },
  { id: 'torus', kind: 'mesh', label: 'Torus', icon: 'donut_small', make: meshFactories.torus },
  { id: 'torusKnot', kind: 'mesh', label: 'Torus Knot', icon: 'sports_score', make: meshFactories.torusKnot },
  { id: 'plane', kind: 'mesh', label: 'Plane', icon: 'crop_square', make: meshFactories.plane },
  { id: 'icosahedron', kind: 'mesh', label: 'Icosahedron', icon: 'workspaces', make: meshFactories.icosahedron },
  { id: 'point_light', kind: 'light', label: 'Point Light', icon: 'lightbulb', make: lightFactories.point_light },
  { id: 'directional_light', kind: 'light', label: 'Sun Light', icon: 'wb_sunny', make: lightFactories.directional_light },
  { id: 'spot_light', kind: 'light', label: 'Spot Light', icon: 'highlight', make: lightFactories.spot_light },
  { id: 'hemisphere_light', kind: 'light', label: 'Hemisphere Light', icon: 'brightness_6', make: lightFactories.hemisphere_light },
  { id: 'camera', kind: 'camera', label: 'Camera', icon: 'videocam', make: cameraFactory },
  { id: 'empty', kind: 'empty', label: 'Empty (locator)', icon: 'panorama_fish_eye', make: emptyFactory },
  { id: 'particles', kind: 'particles', label: 'Particle System', icon: 'auto_awesome', make: () => null }, // built by Particles
  { id: 'smoke', kind: 'smoke', label: 'Smoke', icon: 'cloud', make: () => null }, // built by Particles
  { id: 'armature', kind: 'armature', label: 'Armature', icon: 'accessibility_new', make: () => null }, // built by Armature
  // Created by the import pipeline, never shown in the Add menu.
  { id: 'imported', kind: 'mesh', label: 'Imported Model', icon: 'deployed_code', hidden: true, make: () => new THREE.Mesh() },
];

const TYPE_INDEX = new Map(TYPES.map((t) => [t.id, t]));

export function getType(id) {
  return TYPE_INDEX.get(id);
}

export const MESH_TYPE_IDS = TYPES.filter((t) => t.kind === 'mesh').map((t) => t.id);
export const LIGHT_TYPE_IDS = TYPES.filter((t) => t.kind === 'light').map((t) => t.id);
export const PRIMITIVE_DATA = {
  cube: { width: 1, height: 1, depth: 1 },
  sphere: { radius: 0.5 },
  cylinder: { radiusTop: 0.5, radiusBottom: 0.5, height: 1 },
  cone: { radius: 0.5, height: 1 },
  torus: { radius: 0.4, tube: 0.15 },
  torusKnot: { radius: 0.45, tube: 0.12 },
  plane: { width: 2, height: 2 },
  icosahedron: { radius: 0.6, detail: 0 },
};

function cameraFactory() {
  const cam = new THREE.PerspectiveCamera(50, 1, 0.1, 500);
  cam.position.set(4, 3, 6);
  cam.lookAt(0, 0.5, 0);
  return cam;
}

function emptyFactory() {
  const group = new THREE.Group();
  const size = 0.35;
  const helper = new THREE.LineSegments(
    new THREE.EdgesGeometry(new THREE.BoxGeometry(size, size, size)),
    new THREE.LineBasicMaterial({ color: COLORS.selection, transparent: true, opacity: 0.7 }),
  );
  helper.name = '__helper';
  group.add(helper);
  return group;
}

/** Default display name for a freshly created entry of a given type. */
export function defaultNameFor(typeId) {
  const t = getType(typeId);
  return t ? t.label : 'Object';
}