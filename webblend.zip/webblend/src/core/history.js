// Bounded undo/redo stack over opaque snapshots produced by the world layer.
// The world owns what a snapshot looks like; this module only stores them.

export class History {
  #undo = [];
  #redo = [];
  #limit;

  constructor(limit = 100) {
    this.#limit = limit;
  }

  /** Record a snapshot taken *before* a mutation. Clears the redo branch. */
  push(snapshot) {
    this.#undo.push(snapshot);
    if (this.#undo.length > this.#limit) this.#undo.shift();
    this.#redo.length = 0;
  }

  /** Drop the most recent snapshot (used to cancel a no-op/aborted action). */
  drop() {
    this.#undo.pop();
  }

  canUndo() {
    return this.#undo.length > 0;
  }

  canRedo() {
    return this.#redo.length > 0;
  }

  /**
   * Pop the previous state.
   * `current` is stored on the redo branch so the action can be reversed.
   */
  undo(current) {
    if (!this.canUndo()) return null;
    const previous = this.#undo.pop();
    this.#redo.push(current);
    return previous;
  }

  redo(current) {
    if (!this.canRedo()) return null;
    const next = this.#redo.pop();
    this.#undo.push(current);
    return next;
  }

  clear() {
    this.#undo.length = 0;
    this.#redo.length = 0;
  }

  get depth() {
    return { undo: this.#undo.length, redo: this.#redo.length };
  }
}
