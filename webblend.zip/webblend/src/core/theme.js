// 3D-side visual constants. CSS design tokens cannot reach WebGL, so the
// editor's 3D chrome (grid, axes, selection) is centralized here instead of
// being scattered as literals through scene code. Keep this file free of DOM.

export const COLORS = {
  background: '#12141a',
  ground: '#0f1116',
  gridMajor: '#262b36',
  gridMinor: '#1b1f29',
  axisX: '#e5484d',
  axisY: '#46a758',
  axisZ: '#6096ff',
  selection: '#7aa2ff',
  vertex: '#ffd166',
  particleDust: '#8f9bb3',
};

export const MATERIAL_DEFAULTS = {
  color: '#4a5568',
  roughness: 0.65,
  metalness: 0.1,
};