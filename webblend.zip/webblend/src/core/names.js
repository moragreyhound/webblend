// Pure naming helpers. No DOM, no Three.js - safe to unit test in Node.

const MAX_NAME_LENGTH = 64;

/** Strip control characters and excess length from a user-supplied name. */
export function sanitizeName(raw, fallback = 'Object') {
  const text = String(raw ?? '')
    // Control characters become single spaces (a newline inside a name reads
    // as a space, never as nothing or as markup).
    // eslint-disable-next-line no-control-regex -- intentional: reject control chars
    .replace(/[\u0000-\u001f\u007f]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (text.length === 0) return fallback;
  return text.slice(0, MAX_NAME_LENGTH);
}

/**
 * Produce a name that does not collide with `existing`.
 * "Cube" -> "Cube 2" -> "Cube 3" ...
 */
export function uniqueName(base, existing, separator = ' ') {
  const clean = sanitizeName(base);
  const list = Array.isArray(existing) ? existing : [];
  if (!list.includes(clean)) return clean;
  let n = 2;
  while (list.includes(`${clean}${separator}${n}`)) n += 1;
  return `${clean}${separator}${n}`;
}

/** "Cube 3" -> "Cube". */
export function baseName(name) {
  return String(name ?? '').replace(/\s+\d+$/, '');
}
