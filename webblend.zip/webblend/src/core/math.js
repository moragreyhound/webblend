// Pure numeric helpers. No DOM, no Three.js - safe to unit test in Node.

export const EPSILON = 1e-6;

/** Clamp `value` into [min, max]. NaN collapses to `min`. */
export function clamp(value, min, max) {
  const v = Number.isFinite(value) ? value : min;
  return Math.min(max, Math.max(min, v));
}

export function lerp(a, b, t) {
  return a + (b - a) * t;
}

export function degToRad(deg) {
  return (deg * Math.PI) / 180;
}

export function radToDeg(rad) {
  return (rad * 180) / Math.PI;
}

/** Round to `precision` decimal places (used for stable numeric display). */
export function round(value, precision = 3) {
  const p = 10 ** precision;
  // Number.EPSILON nudges values like 1.005 (stored as 1.004999...) so that
  // conventional decimal rounding wins instead of binary-float artifacts.
  return Math.round((value + Number.EPSILON) * p) / p;
}

/** Snap `value` to the nearest multiple of `step` when snapping is enabled. */
export function snap(value, step, enabled = true) {
  if (!enabled || !Number.isFinite(step) || step <= 0) return value;
  return Math.round(value / step) * step;
}

/** Signed angle between two 2D screen-space directions, in radians. */
export function screenAngle(dx, dy) {
  return Math.atan2(dy, dx);
}
