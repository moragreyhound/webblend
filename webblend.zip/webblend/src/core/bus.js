// Minimal synchronous event bus. Keeps modules decoupled: the scene layer emits,
// the UI subscribes, and neither imports the other.

export class Bus {
  #listeners = new Map();

  on(type, handler) {
    if (typeof handler !== 'function') throw new TypeError('handler must be a function');
    const set = this.#listeners.get(type) ?? new Set();
    set.add(handler);
    this.#listeners.set(type, set);
    return () => this.off(type, handler);
  }

  off(type, handler) {
    this.#listeners.get(type)?.delete(handler);
  }

  emit(type, payload) {
    const set = this.#listeners.get(type);
    if (!set) return;
    // Copy so handlers may unsubscribe during dispatch without skipping peers.
    for (const handler of [...set]) {
      try {
        handler(payload);
      } catch (error) {
        // A failing listener must not break other listeners or the emitter.
        console.error(`[bus] listener for "${type}" threw`, error);
      }
    }
  }

  clear(type) {
    if (type === undefined) this.#listeners.clear();
    else this.#listeners.delete(type);
  }
}

/** Shared application bus. */
export const bus = new Bus();
