// Single source of truth for the product name and version shown in the UI.
// Kept dependency-free and DOM-free so it can be imported from any layer
// (including future Node-side tooling and tests).
//
// Keep in step with package.json: "name": "webblend-studio", "version": "1.0.0".

export const APP_NAME = 'WebBlend Studio';
export const APP_VERSION = '1.0.0';
