// Import/export of external model formats and the native `.webblend` project.
//
// Design notes:
// - A whole import batch shares one LoadingManager so that sibling resources
//   dropped together (textures, `.bin`, `.mtl`) resolve to in-memory blob URLs.
//   Nothing is uploaded: the browser reads the dropped files and exposes object
//   URLs which are revoked once the batch has had time to decode textures.
// - Only three's own loaders/exporters are used (no third-party format code).
// - DOM access (Blob/URL/anchor/File) is confined to this module. Pure helpers
//   live in src/io/format.js so the test suite stays Three- and DOM-free.

import * as THREE from 'three';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';
import { MTLLoader } from 'three/addons/loaders/MTLLoader.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { STLLoader } from 'three/addons/loaders/STLLoader.js';
import { PLYLoader } from 'three/addons/loaders/PLYLoader.js';
import { FBXLoader } from 'three/addons/loaders/FBXLoader.js';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import { OBJExporter } from 'three/addons/exporters/OBJExporter.js';
import { STLExporter } from 'three/addons/exporters/STLExporter.js';
import { clone as cloneSkinned } from 'three/addons/utils/SkeletonUtils.js';

import {
  IMPORT_FORMATS,
  EXPORT_FORMATS,
  PROJECT_EXTENSION,
  extensionOf,
  baseNameOf,
  firstMtlLibrary,
  stripEditorNodes,
  validateProject,
  projectFileName,
  serializeProject,
} from './format.js';

export {
  IMPORT_FORMATS,
  EXPORT_FORMATS,
  PROJECT_EXTENSION,
  extensionOf,
  baseNameOf,
  firstMtlLibrary,
  stripEditorNodes,
  validateProject,
  projectFileName,
  serializeProject,
} from './format.js';

// Textures attached via MTLLoader load lazily (preload() is synchronous), so we
// keep the batch's blob URLs alive briefly rather than revoke them mid-decode.
const REVOKE_DELAY_MS = 30000;

// ---------------------------------------------------------------------------
// Browser download helper
// ---------------------------------------------------------------------------

export function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.rel = 'noopener';
  anchor.style.display = 'none';
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  // Give the browser a tick to start the download before releasing the URL.
  setTimeout(() => URL.revokeObjectURL(url), 0);
}

// ---------------------------------------------------------------------------
// Import
// ---------------------------------------------------------------------------

function defaultImportMaterial() {
  return new THREE.MeshStandardMaterial({ color: '#8a94a8', roughness: 0.6, metalness: 0.1 });
}

/**
 * Make a freshly loaded subtree render sensibly in the editor: shadows on,
 * normals computed when the format omitted them, and a fallback material so a
 * geometry-only import (STL/PLY) is never invisible.
 */
export function prepareImported(object) {
  object.traverse((node) => {
    if (node.isMesh || node.isSkinnedMesh) {
      node.castShadow = true;
      node.receiveShadow = true;
      const geometry = node.geometry;
      if (geometry && !geometry.getAttribute('normal')) geometry.computeVertexNormals();
      if (!node.material) node.material = defaultImportMaterial();
    } else if (node.isPoints || node.isLine) {
      node.castShadow = false;
      node.receiveShadow = false;
    }
  });
  return object;
}

function lookupUrl(urlByName, name) {
  if (!name) return undefined;
  const direct = urlByName.get(name) ?? urlByName.get(name.toLowerCase());
  if (direct) return direct;
  const first = name.split(/\s+/)[0];
  return first ? urlByName.get(first) ?? urlByName.get(first.toLowerCase()) : undefined;
}

async function loadObj(file, manager, urlByName, virtualPath) {
  const loader = new OBJLoader(manager);
  const text = await file.text();
  const mtlName = firstMtlLibrary(text);
  if (mtlName && lookupUrl(urlByName, mtlName)) {
    const mtlLoader = new MTLLoader(manager);
    mtlLoader.setResourcePath('./imports/');
    const materials = await mtlLoader.loadAsync(`./imports/${encodeURIComponent(mtlName)}`);
    if (materials && typeof materials.preload === 'function') materials.preload();
    loader.setMaterials(materials);
  }
  return loader.loadAsync(virtualPath(file));
}

async function loadGeometryAsMesh(file, manager, virtualPath, GeometryLoader) {
  const geometry = await new GeometryLoader(manager).loadAsync(virtualPath(file));
  if (!geometry.getAttribute('normal')) geometry.computeVertexNormals();
  return new THREE.Mesh(geometry, defaultImportMaterial());
}

async function loadOne(file, ext, manager, urlByName, virtualPath) {
  switch (ext) {
    case 'obj':
      return loadObj(file, manager, urlByName, virtualPath);
    case 'gltf':
    case 'glb': {
      const gltf = await new GLTFLoader(manager).loadAsync(virtualPath(file));
      return gltf.scene ?? gltf.scenes?.[0] ?? null;
    }
    case 'stl':
      return loadGeometryAsMesh(file, manager, virtualPath, STLLoader);
    case 'ply':
      return loadGeometryAsMesh(file, manager, virtualPath, PLYLoader);
    case 'fbx':
      return new FBXLoader(manager).loadAsync(virtualPath(file));
    default:
      return null;
  }
}

function summarizeImport(result) {
  const parts = [];
  const ok = result.imported.length;
  if (ok) parts.push(`Imported ${ok} model${ok === 1 ? '' : 's'}.`);
  if (result.failed.length) {
    parts.push(`${result.failed.length} failed: ${result.failed.map((f) => f.name).join(', ')}.`);
  }
  if (result.skipped.length) parts.push(`${result.skipped.length} skipped.`);
  return parts.join(' ') || 'Nothing to import.';
}

/**
 * Import dropped/selected files into the world.
 *
 * @param {FileList|File[]} fileList
 * @param {import('../world.js').World} world
 * @param {{ onNotice?: (message: string) => void }} [options]
 * @returns {Promise<{ imported: object[], failed: {name:string,message:string}[], skipped: {name:string,reason:string}[] }>}
 */
export async function importFiles(fileList, world, { onNotice } = {}) {
  const files = Array.from(fileList ?? []);
  const result = { imported: [], failed: [], skipped: [] };
  if (files.length === 0) return result;

  // Every dropped file gets a blob URL so cross-references resolve by basename.
  const urlByName = new Map();
  const objectUrls = [];
  for (const file of files) {
    const url = URL.createObjectURL(file);
    objectUrls.push(url);
    urlByName.set(file.name, url);
    urlByName.set(file.name.toLowerCase(), url);
  }

  const manager = new THREE.LoadingManager();
  manager.setURLModifier((url) => {
    const clean = decodeURIComponent(url.split(/[?#]/)[0]);
    const base = clean.split('/').pop() ?? clean;
    return urlByName.get(base) ?? urlByName.get(base.toLowerCase()) ?? url;
  });

  const virtualPath = (file) => `./imports/${encodeURIComponent(file.name)}`;

  try {
    for (const file of files) {
      const ext = extensionOf(file.name);
      if (!IMPORT_FORMATS.includes(ext)) {
        const reason = ext === 'mtl'
          ? 'material library (applied when its OBJ is imported)'
          : `unsupported .${ext || 'file'}`;
        result.skipped.push({ name: file.name, reason });
        continue;
      }
      try {
        const object = await loadOne(file, ext, manager, urlByName, virtualPath);
        if (!object) {
          result.skipped.push({ name: file.name, reason: 'no displayable content' });
          continue;
        }
        prepareImported(object);
        const entry = world.addImported(baseNameOf(file.name), object, { format: ext, source: file.name });
        result.imported.push(entry);
      } catch (error) {
        result.failed.push({ name: file.name, message: error?.message ?? String(error) });
      }
    }
  } finally {
    if (typeof window === 'undefined') {
      for (const url of objectUrls) URL.revokeObjectURL(url);
    } else {
      window.setTimeout(() => {
        for (const url of objectUrls) URL.revokeObjectURL(url);
      }, REVOKE_DELAY_MS);
    }
  }

  onNotice?.(summarizeImport(result));
  return result;
}

// ---------------------------------------------------------------------------
// Export
// ---------------------------------------------------------------------------

async function buildExportBlob(group, format) {
  switch (format) {
    case 'glb': {
      const data = await new GLTFExporter().parseAsync(group, { binary: true, trs: false, onlyVisible: true });
      return { blob: new Blob([data], { type: 'model/gltf-binary' }), filename: 'webblend-scene.glb' };
    }
    case 'gltf': {
      const data = await new GLTFExporter().parseAsync(group, { binary: false, trs: false, onlyVisible: true });
      return {
        blob: new Blob([JSON.stringify(data, null, 2)], { type: 'model/gltf+json' }),
        filename: 'webblend-scene.gltf',
      };
    }
    case 'obj': {
      const text = new OBJExporter().parse(group);
      return { blob: new Blob([text], { type: 'text/plain' }), filename: 'webblend-scene.obj' };
    }
    case 'stl': {
      const view = new STLExporter().parse(group, { binary: true });
      const bytes = view instanceof DataView
        ? new Uint8Array(view.buffer, view.byteOffset, view.byteLength)
        : view;
      return { blob: new Blob([bytes], { type: 'model/stl' }), filename: 'webblend-scene.stl' };
    }
    default:
      throw new Error(`Unsupported export format: ${format}`);
  }
}

/**
 * Export the whole scene (or just the selection) to a downloadable model.
 *
 * @param {import('../world.js').World} world
 * @param {{ format?: 'glb'|'gltf'|'obj'|'stl', selectedOnly?: boolean, download?: boolean }} [options]
 */
export async function exportScene(world, { format = 'glb', selectedOnly = false, download = true } = {}) {
  const fmt = EXPORT_FORMATS.includes(format) ? format : 'glb';
  const entries = selectedOnly && world.selectedEntry ? [world.selectedEntry] : world.entries;

  const skipped = [];
  const group = new THREE.Group();
  group.name = 'WebBlendExport';
  for (const entry of entries) {
    if (entry.kind === 'particles' || entry.kind === 'smoke') {
      skipped.push({ name: entry.name, reason: 'particle systems have no exportable mesh' });
      continue;
    }
    const clone = cloneSkinned(entry.object);
    clone.name = entry.name;
    stripEditorNodes(clone);
    group.add(clone);
  }

  if (group.children.length === 0) {
    throw new Error('Nothing to export. Create or select a mesh first.');
  }
  group.updateMatrixWorld(true);

  const { blob, filename } = await buildExportBlob(group, fmt);
  if (download) downloadBlob(blob, filename);
  return { blob, filename, skipped };
}

// ---------------------------------------------------------------------------
// Project file (.webblend)
// ---------------------------------------------------------------------------

/** Read and validate a `.webblend` file, returning the parsed payload. */
export async function openProjectFile(file) {
  const text = await file.text();
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error('That file is not valid JSON.');
  }
  const check = validateProject(data);
  if (!check.ok) throw new Error(check.reason);
  return data;
}

/** Replace the world's contents with a validated payload. Returns entry count. */
export function loadProject(world, data) {
  const check = validateProject(data);
  if (!check.ok) throw new Error(check.reason);
  world.replaceFromSerialized(data.world ?? data);
  return world.entries.length;
}

/** Serialize and download the world as a `.webblend` file. */
export function saveProject(world) {
  const data = serializeProject(world);
  const filename = projectFileName(world);
  if (typeof document !== 'undefined') {
    downloadBlob(new Blob([JSON.stringify(data)], { type: 'application/json' }), filename);
  }
  return { filename, data };
}
