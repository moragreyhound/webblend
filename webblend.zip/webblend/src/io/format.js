// Pure, dependency-free helpers for file handling: format detection, name
// derivation, project validation, and export-name generation.
//
// Kept free of Three.js and the DOM so `node --test` can exercise them directly
// (see tests/files.test.js). `src/io/files.js` re-exports these for callers that
// already depend on the browser-side import/export code.

export const IMPORT_FORMATS = ['obj', 'gltf', 'glb', 'stl', 'ply', 'fbx'];
export const EXPORT_FORMATS = ['glb', 'gltf', 'obj', 'stl'];
export const PROJECT_EXTENSION = 'webblend';
export const PROJECT_VERSION = 1;

// Hard cap on restored entries: a project file is untrusted input, so we refuse
// absurd sizes rather than allocate for them.
export const MAX_PROJECT_ENTRIES = 20000;

// Editor-only overlay nodes that must never appear in an exported file.
export const EDITOR_NODE_NAMES = ['__helper', '__bone', '__editor'];

/** Lower-cased extension of a file name, without the dot. '' when absent. */
export function extensionOf(name) {
  const clean = String(name ?? '').split(/[?#]/)[0];
  const dot = clean.lastIndexOf('.');
  if (dot <= 0 || dot === clean.length - 1) return '';
  return clean.slice(dot + 1).toLowerCase();
}

/** File name without directories or extension (used as the default object name). */
export function baseNameOf(name) {
  const clean = String(name ?? '').replace(/\\/g, '/').split('/').pop() ?? '';
  const ext = extensionOf(clean);
  return ext ? clean.slice(0, -(ext.length + 1)) : clean;
}

/** First `mtllib` referenced by an OBJ document (may be an empty string). */
export function firstMtlLibrary(objText) {
  const match = /^[ \t]*mtllib[ \t]+(.+?)[ \t]*$/im.exec(String(objText ?? ''));
  return match ? match[1].trim() : '';
}

/** Remove a cloned subtree's editor-only overlay nodes in place. */
export function stripEditorNodes(object) {
  const doomed = [];
  object.traverse((node) => {
    if (EDITOR_NODE_NAMES.includes(node.name)) doomed.push(node);
  });
  for (const node of doomed) node.removeFromParent();
  return object;
}

/**
 * Validate a parsed `.webblend` payload without touching the world.
 * Returns `{ ok: true }` or `{ ok: false, reason }`.
 */
export function validateProject(data) {
  if (!data || typeof data !== 'object') {
    return { ok: false, reason: 'File is not a WebBlend project.' };
  }
  const payload = data.world ?? data;
  if (!payload || typeof payload !== 'object' || !Array.isArray(payload.entries)) {
    return { ok: false, reason: 'Project is missing its object list.' };
  }
  if (payload.entries.length > MAX_PROJECT_ENTRIES) {
    return { ok: false, reason: `Project has too many objects (${payload.entries.length}).` };
  }
  for (const entry of payload.entries) {
    if (!entry || typeof entry !== 'object' || typeof entry.typeId !== 'string') {
      return { ok: false, reason: 'Project contains a malformed object entry.' };
    }
  }
  return { ok: true };
}

/** Safe on-disk file name for a project (single-object scenes use that name). */
export function projectFileName(world) {
  const base = world?.entries?.length === 1 ? world.entries[0].name : 'scene';
  const safe = String(base ?? 'scene')
    .replace(/[^a-z0-9._-]+/gi, '-') // keep an allowlist of characters
    .replace(/\.{2,}/g, '.') // collapse dot runs so no ".." survives
    .replace(/^[.-]+|[.-]+$/g, '') // trim leading/trailing dots and dashes
    .slice(0, 60) || 'scene';
  return `${safe}.${PROJECT_EXTENSION}`;
}

/** Build the object graph that gets serialized for a project save. */
export function serializeProject(world) {
  return {
    app: 'webblend',
    projectVersion: PROJECT_VERSION,
    savedAt: new Date().toISOString(),
    world: world.serialize(),
  };
}
