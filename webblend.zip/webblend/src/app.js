// Application orchestrator.
//
// Responsibility split:
//   - scene/* owns rendering, camera, gizmo, picking and vertex editing
//   - world.js owns the entry model, serialization and history
//   - anim/timeline.js owns the frame clock
//   - ui/* owns presentation and forwards every mutation through ctx.commands
//
// This module is the only place that wires those layers together: it builds the
// shell, implements every command, and runs the per-frame update.

import { bus } from './core/bus.js';
import { degToRad } from './core/math.js';
import { APP_NAME, APP_VERSION } from './core/version.js';
import { World } from './world.js';
import { Timeline } from './anim/timeline.js';
import { Viewport } from './scene/viewport.js';
import { StudioCamera } from './scene/camera.js';
import { TransformTool } from './scene/transform.js';
import { VertexEditor } from './scene/editing.js';
import { pickEntry, pickVertex, pickVerticesInBox } from './scene/picking.js';
import { getType } from './objects/registry.js';
import { defaultBoneAngles, applyBoneAngles as applyAngles } from './objects/armature.js';
import { importFiles, exportScene, saveProject, loadProject, openProjectFile } from './io/files.js';
import { IMPORT_FORMATS, PROJECT_EXTENSION, baseNameOf } from './io/format.js';
import { h, openDialog, promptDialog, confirmDialog } from './ui/dom.js';
import { icon } from './ui/icons.js';
import { Notifier } from './ui/notifications.js';
import { createNavCube } from './ui/navcube.js';
import { Shortcuts } from './ui/shortcuts.js';
import { createToolbar } from './ui/toolbar.js';
import { createOutliner } from './ui/outliner.js';
import { createInspector } from './ui/inspector.js';
import { createTimelinePanel } from './ui/timeline-panel.js';
import { createStatusbar } from './ui/statusbar.js';

const CLICK_SLOP_PX = 4;
const DEFAULT_VIEW = { theta: Math.PI * 0.28, phi: Math.PI * 0.36, radius: 12, target: [0, 1, 0] };

/**
 * Build the whole application inside `root`.
 * @param {HTMLElement} root
 * @returns {{ dispose: () => void }}
 */
export function boot(root) {
  if (!root) throw new Error('boot(root): root element is required');
  root.replaceChildren();

  // -------------------------------------------------------------------------
  // Scene layer
  // -------------------------------------------------------------------------

  const viewportEl = h('div', { class: 'viewport', id: 'viewport' });
  const viewport = new Viewport(viewportEl);
  const camera = new StudioCamera(viewport.camera, viewport.canvas);
  const transform = new TransformTool(viewport.camera, viewport.canvas);
  viewport.addEditorObject(transform.helper);
  const editing = new VertexEditor(viewport, transform);
  const world = new World(viewport);
  const timeline = new Timeline();
  timeline.setFrame(1);

  const notifier = new Notifier();
  const shortcuts = new Shortcuts();

  // -------------------------------------------------------------------------
  // Shell DOM
  // -------------------------------------------------------------------------

  const navcube = createNavCube({
    onSelect: (view) => commands.setView(view),
    onHome: () => commands.resetView(),
  });

  const selectBox = h('div', { class: 'selectbox', 'aria-hidden': 'true' });
  const dropHint = h(
    'div',
    { class: 'dropzone', 'aria-hidden': 'true' },
    icon('download', { size: 28 }),
    h('p', { text: 'Drop .obj, .gltf, .glb, .stl, .ply, .fbx or .webblend files to open them' }),
  );
  viewportEl.append(navcube, selectBox, dropHint);

  const toolbarState = {
    mode: 'object',
    gizmo: 'translate',
    shading: 'smooth',
    snap: false,
    helpers: true,
    fly: false,
    canEdit: false,
    wireframe: false,
  };

  // The context object every panel receives.
  const ctx = {
    bus,
    world,
    viewport,
    camera,
    transform,
    editing,
    timeline,
    notifier,
    toolbarState,
    docName: 'Untitled',
    onFrame: (callback) => viewport.onFrame(callback),
    beginLive: () => world.beginGizmoDrag(),
    commitLive: () => {
      world.endGizmoDrag();
      refreshChrome();
    },
    onTransformChanged: (entry) => updateSelectionHelper(entry),
    refreshSelectionHelper: (entry) => updateSelectionHelper(entry),
    commands: null,
  };

  const toolbar = createToolbar(ctx);
  ctx.toolbarState = toolbar.state;
  const outliner = createOutliner(ctx);
  const inspector = createInspector(ctx);
  const timelinePanel = createTimelinePanel(ctx);
  const statusbar = createStatusbar(ctx);

  const center = h('div', { class: 'app__center' }, viewportEl, timelinePanel.element);
  const body = h('div', { class: 'app__body' }, outliner.element, center, inspector.element);
  const app = h('div', { class: 'app' }, toolbar.element, body, statusbar.element);

  // Hidden file inputs are the platform file pickers.
  const importInput = h('input', {
    type: 'file',
    multiple: true,
    accept: IMPORT_FORMATS.map((ext) => `.${ext}`).join(','),
    class: 'visually-hidden',
    tabindex: -1,
  });
  const projectInput = h('input', {
    type: 'file',
    accept: `.${PROJECT_EXTENSION},application/json`,
    class: 'visually-hidden',
    tabindex: -1,
  });
  app.append(importInput, projectInput);

  root.appendChild(app);

  const docLabel = toolbar.element.querySelector('.topbar__doc')
    ?? h('span', { class: 'topbar__doc' });
  docLabel.title = 'Current project';

  // -------------------------------------------------------------------------
  // Helpers
  // -------------------------------------------------------------------------

  function setDocName(name) {
    ctx.docName = name;
    docLabel.textContent = name;
    document.title = `${APP_NAME} - ${name}`;
  }

  function refreshChrome() {
    toolbarState.canEdit = Boolean(world.selectedEntry?.object?.isMesh);
    toolbar.render();
  }

  function updateSelectionHelper(entry = world.selectedEntry) {
    const helper = viewport.selectionHelper;
    if (!helper) return;
    if (!entry || toolbarState.mode === 'edit' || entry.visible === false) {
      helper.visible = false;
      return;
    }
    helper.setFromObject(entry.object);
    helper.visible = true;
  }

  /** Attach or detach the gizmo according to mode and selection. */
  function syncGizmo() {
    if (toolbarState.mode === 'edit' && editing.active) return; // editing owns the gizmo
    const entry = world.selectedEntry;
    if (entry && entry.visible !== false) transform.attach(entry.object);
    else transform.detach();
  }

  function applyKeyframesAtCurrentFrame() {
    for (const entry of world.entries) {
      if (entry.keys.length === 0) continue;
      const evaluated = timeline.evaluate(entry);
      if (evaluated) world.applyTransform(entry, evaluated);
    }
    updateSelectionHelper();
  }

  function sceneIsEmpty() {
    return world.entries.length === 0;
  }

  // -------------------------------------------------------------------------
  // Commands (single mutation surface for the UI)
  // -------------------------------------------------------------------------

  const commands = {
    create(typeId) {
      const entry = world.create(typeId);
      if (!entry) return null;
      notifier.success(`Added ${getType(typeId)?.label ?? typeId}.`, {
        action: { label: 'Undo', onSelect: () => commands.undo() },
      });
      refreshChrome();
      return entry;
    },

    setEntryVisible(entry, flag) {
      world.record(() => world.setVisible(entry, flag));
      refreshChrome();
    },

    renameEntry(entry, name) {
      world.record(() => world.rename(entry, name));
    },

    deleteEntry(entry) {
      if (!entry) return;
      const removed = { name: entry.name };
      world.record(() => world.remove(entry));
      notifier.info(`Deleted ${removed.name}.`, {
        action: { label: 'Undo', onSelect: () => commands.undo() },
      });
      refreshChrome();
    },

    deleteSelected() {
      const entry = world.selectedEntry;
      if (!entry) {
        notifier.warning('Nothing is selected.');
        return;
      }
      commands.deleteEntry(entry);
    },

    async renameSelected() {
      const entry = world.selectedEntry;
      if (!entry) {
        notifier.warning('Nothing is selected.');
        return;
      }
      const next = await promptDialog({ title: 'Rename object', label: 'Name', value: entry.name });
      if (next !== null) commands.renameEntry(entry, next);
    },

    duplicateSelected() {
      const entry = world.selectedEntry;
      if (!entry) {
        notifier.warning('Nothing is selected.');
        return;
      }
      world.record(() => world.duplicate(entry));
      refreshChrome();
    },

    mutate(fn) {
      world.record(fn);
      refreshChrome();
    },

    setSnap(flag) {
      toolbarState.snap = !!flag;
      transform.setSnapEnabled(toolbarState.snap);
      refreshChrome();
    },

    toggleSnap() {
      commands.setSnap(!toolbarState.snap);
    },

    applyBoneAngles(entry) {
      if (!entry?.armature) return;
      applyAngles(entry.armature, entry.data.armature.angles);
    },

    resetPose(entry) {
      if (!entry?.armature) return;
      world.record(() => {
        entry.data.armature.angles = defaultBoneAngles(entry.armature.boneCount);
        applyAngles(entry.armature, entry.data.armature.angles);
      });
    },

    burstParticles(entry) {
      if (!entry?.particles) return;
      entry.particles.burst(null, 60);
    },

    insertKey() {
      const entry = world.selectedEntry;
      if (!entry) {
        notifier.warning('Select an object before inserting a keyframe.');
        return;
      }
      world.record(() =>
        timeline.insertKey(entry, timeline.frame, world.objectTransform(entry)),
      );
    },

    deleteKey() {
      const entry = world.selectedEntry;
      if (!entry) return;
      world.record(() => timeline.deleteKeyAt(entry, timeline.frame));
    },

    setFrame(frame) {
      timeline.setFrame(frame);
    },

    stepFrame(delta) {
      timeline.setFrame(timeline.frame + delta);
    },

    togglePlay() {
      timeline.toggle();
    },

    setFps(fps) {
      timeline.setFps(fps);
    },

    setEndFrame(end) {
      timeline.setEndFrame(end);
    },

    setLoop(flag) {
      timeline.loop = !!flag;
      bus.emit('timeline.change', timeline.toJSON());
    },

    setAutoKey(flag) {
      timeline.autoKey = !!flag;
      bus.emit('timeline.change', timeline.toJSON());
      notifier.info(flag ? 'Auto-key is on: gizmo edits create keyframes.' : 'Auto-key is off.');
    },

    undo() {
      if (!world.undo()) {
        notifier.info('Nothing to undo.');
        return;
      }
      refreshChrome();
    },

    redo() {
      if (!world.redo()) {
        notifier.info('Nothing to redo.');
        return;
      }
      refreshChrome();
    },

    frameSelected() {
      const entry = world.selectedEntry;
      if (entry) camera.focusOn(entry.object);
      else camera.focusOn(null);
    },

    setMode(mode) {
      if (mode === 'edit') {
        const entry = world.selectedEntry;
        if (!entry?.object?.isMesh || !entry.object.geometry) {
          notifier.warning('Select a mesh to edit its vertices (lights, cameras, particles and armatures cannot be vertex-edited).');
          return;
        }
        toolbarState.mode = 'edit';
        if (!editing.enter(entry.object)) {
          toolbarState.mode = 'object';
          notifier.error('That mesh has no editable geometry.');
          return;
        }
        viewport.selectionHelper.visible = false;
        notifier.info('Edit mode: click or drag a box over vertices, then drag the gizmo.');
      } else {
        if (editing.active) editing.exit();
        toolbarState.mode = 'object';
        syncGizmo();
        updateSelectionHelper();
      }
      refreshChrome();
      statusbar.render();
    },

    toggleEditMode() {
      commands.setMode(toolbarState.mode === 'edit' ? 'object' : 'edit');
    },

    setGizmoMode(mode) {
      toolbarState.gizmo = mode;
      transform.setMode(mode);
      refreshChrome();
    },

    setShading(mode) {
      toolbarState.shading = mode;
      toolbarState.wireframe = mode === 'wireframe';
      viewport.setShading(mode);
      refreshChrome();
    },

    toggleWireframe() {
      commands.setShading(toolbarState.shading === 'wireframe' ? 'smooth' : 'wireframe');
    },

    toggleHelpers() {
      toolbarState.helpers = !toolbarState.helpers;
      viewport.setHelpersVisible(toolbarState.helpers);
      refreshChrome();
    },

    toggleFly() {
      toolbarState.fly = !toolbarState.fly;
      camera.setFly(toolbarState.fly);
      refreshChrome();
      notifier.info(
        toolbarState.fly
          ? 'Fly camera: right-drag to look, W/A/S/D to move, Q/E down/up.'
          : 'Orbit camera.',
      );
    },

    setView(view) {
      camera.setView(view);
      if (toolbarState.fly) {
        toolbarState.fly = false;
        refreshChrome();
      }
    },

    resetView() {
      camera.fly = false;
      camera.theta = DEFAULT_VIEW.theta;
      camera.phi = DEFAULT_VIEW.phi;
      camera.radius = DEFAULT_VIEW.radius;
      camera.target.set(...DEFAULT_VIEW.target);
      camera.apply();
      toolbarState.fly = false;
      refreshChrome();
    },

    selectAllVertices() {
      if (!editing.active) return;
      editing.selectAll();
    },

    clearVertexSelection() {
      if (editing.active) editing.setSelection([]);
    },

    weldVertices() {
      if (!editing.active) return;
      const result = editing.weld();
      if (result.merged > 0) {
        notifier.success(`Weld merged ${result.merged} vertices.`, {
          action: { label: 'Undo', onSelect: () => commands.undo() },
        });
      } else {
        notifier.info(`Nothing to weld (${result.reason ?? 'no change'}).`);
      }
    },

    async newScene() {
      const ok = await confirmDialog({
        title: 'Start a new scene?',
        message: 'The current scene will be replaced. You can undo this with Ctrl+Z.',
        confirmLabel: 'New scene',
      });
      if (!ok) return;
      world.record(() => {
        world.clear();
        timeline.stop();
        timeline.setFrame(1);
        world.create('cube');
      });
      setDocName('Untitled');
      refreshChrome();
      notifier.info('New scene created.');
    },

    openProject() {
      projectInput.click();
    },

    saveProject() {
      try {
        const { filename } = saveProject(world);
        setDocName(filename.replace(/\.webblend$/i, ''));
        notifier.success(`Saved ${filename}.`);
      } catch (error) {
        notifier.error(`Could not save the project: ${error.message}`);
      }
    },

    importFiles() {
      importInput.click();
    },

    async exportScene({ format = 'glb', selectedOnly = false } = {}) {
      if (selectedOnly && !world.selectedEntry) {
        notifier.warning('Select an object to export the selection.');
        return;
      }
      try {
        const { filename, skipped } = await exportScene(world, { format, selectedOnly });
        notifier.success(`Exported ${filename}.`);
        if (skipped.length > 0) {
          notifier.info(`${skipped.length} object(s) skipped: ${skipped.map((s) => s.name).join(', ')}.`);
        }
      } catch (error) {
        notifier.error(error.message);
      }
    },

    openHelp() {
      const groups = shortcuts.grouped();
      const body = h('div', { class: 'help' });
      body.appendChild(
        h('p', {
          class: 'muted',
          text: 'Viewport: right-drag orbit · middle-drag pan · scroll to zoom · W/A/S/D + Q/E to move · hold Shift to move faster.',
        }),
      );
      for (const { group, list } of groups) {
        body.appendChild(h('h3', { class: 'help__group', text: group }));
        const dl = h('dl', { class: 'help__list' });
        for (const binding of list) {
          if (!binding.label) continue;
          dl.appendChild(h('dt', { class: 'help__keys', text: Shortcuts.display(binding.keys) }));
          dl.appendChild(h('dd', { class: 'help__desc', text: binding.label }));
        }
        body.appendChild(dl);
      }
      openDialog({
        title: 'Keyboard shortcuts',
        body,
        actions: [{ label: 'Close', value: true, variant: 'primary', autofocus: true }],
      });
    },

    openAbout() {
      const body = h(
        'div',
        { class: 'about' },
        h('p', { text: `${APP_NAME} ${APP_VERSION}` }),
        h('p', {
          class: 'muted',
          text: 'A browser-native 3D editor for primitives, imported models, particles, armatures and keyframe animation.',
        }),
        h('p', { class: 'muted', text: 'Rendering by three.js (MIT). No data leaves your machine: imports, exports and project files are handled entirely in the browser.' }),
      );
      openDialog({
        title: `About ${APP_NAME}`,
        body,
        actions: [{ label: 'Close', value: true, variant: 'primary', autofocus: true }],
      });
    },
  };

  ctx.commands = commands;

  // -------------------------------------------------------------------------
  // Import / project file pickers
  // -------------------------------------------------------------------------

  async function runImport(files) {
    if (!files || files.length === 0) return;
    const result = await world.record(() =>
      importFiles(files, world, { onNotice: () => {} }),
    );
    if (result.imported.length > 0) {
      notifier.success(`Imported ${result.imported.length} model${result.imported.length === 1 ? '' : 's'}.`);
      commands.frameSelected();
    }
    if (result.failed.length > 0) {
      notifier.error(`Failed to import: ${result.failed.map((f) => f.name).join(', ')}.`);
    }
    if (result.skipped.length > 0) {
      notifier.info(`Skipped ${result.skipped.length} file(s): ${result.skipped.map((s) => `${s.name} (${s.reason})`).join(', ')}.`);
    }
    refreshChrome();
  }

  importInput.addEventListener('change', async () => {
    const files = Array.from(importInput.files ?? []);
    importInput.value = '';
    try {
      await runImport(files);
    } catch (error) {
      notifier.error(`Import failed: ${error.message}`);
    }
  });

  projectInput.addEventListener('change', async () => {
    const file = projectInput.files?.[0];
    projectInput.value = '';
    if (!file) return;
    try {
      const data = await openProjectFile(file);
      world.record(() => loadProject(world, data));
      applyKeyframesAtCurrentFrame();
      setDocName(baseNameOf(file.name));
      commands.frameSelected();
      refreshChrome();
      notifier.success(`Opened ${file.name}.`);
    } catch (error) {
      notifier.error(`Could not open that project: ${error.message}`);
    }
  });

  // -------------------------------------------------------------------------
  // Drag & drop
  // -------------------------------------------------------------------------

  let dragDepth = 0;
  window.addEventListener('dragenter', (event) => {
    if (!event.dataTransfer?.types?.includes('Files')) return;
    dragDepth += 1;
    viewportEl.classList.add('is-dropping');
  });
  window.addEventListener('dragover', (event) => {
    if (!event.dataTransfer?.types?.includes('Files')) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = 'copy';
  });
  window.addEventListener('dragleave', () => {
    dragDepth = Math.max(0, dragDepth - 1);
    if (dragDepth === 0) viewportEl.classList.remove('is-dropping');
  });
  window.addEventListener('drop', async (event) => {
    if (!event.dataTransfer?.files?.length) return;
    event.preventDefault();
    dragDepth = 0;
    viewportEl.classList.remove('is-dropping');
    const files = Array.from(event.dataTransfer.files);
    const project = files.find((file) => file.name.toLowerCase().endsWith(`.${PROJECT_EXTENSION}`));
    try {
      if (project) {
        const data = await openProjectFile(project);
        world.record(() => loadProject(world, data));
        applyKeyframesAtCurrentFrame();
        setDocName(baseNameOf(project.name));
        refreshChrome();
        notifier.success(`Opened ${project.name}.`);
      } else {
        await runImport(files);
      }
    } catch (error) {
      notifier.error(error.message);
    }
  });

  // -------------------------------------------------------------------------
  // Viewport pointer interaction (selection + box select)
  // -------------------------------------------------------------------------

  const canvas = viewport.canvas;
  let pointerDown = null;
  let suppressing = false;
  let boxOrigin = null;

  function localPoint(event) {
    const rect = canvas.getBoundingClientRect();
    return { x: event.clientX - rect.left, y: event.clientY - rect.top };
  }

  function beginBoxSelect(event) {
    const point = localPoint(event);
    boxOrigin = { clientX: event.clientX, clientY: event.clientY, start: point };
    selectBox.hidden = false;
    drawBox(point, point);
  }

  function drawBox(a, b) {
    const left = Math.min(a.x, b.x);
    const top = Math.min(a.y, b.y);
    selectBox.style.setProperty('left', `${Math.round(left)}px`);
    selectBox.style.setProperty('top', `${Math.round(top)}px`);
    selectBox.style.setProperty('width', `${Math.round(Math.abs(b.x - a.x))}px`);
    selectBox.style.setProperty('height', `${Math.round(Math.abs(b.y - a.y))}px`);
  }

  function endBoxSelect(event, additive) {
    selectBox.hidden = true;
    if (!boxOrigin) return;
    const box = {
      minX: Math.min(boxOrigin.clientX, event.clientX),
      maxX: Math.max(boxOrigin.clientX, event.clientX),
      minY: Math.min(boxOrigin.clientY, event.clientY),
      maxY: Math.max(boxOrigin.clientY, event.clientY),
    };
    boxOrigin = null;
    if (!editing.mesh) return;
    const indices = pickVerticesInBox(viewport, editing.mesh, box);
    if (indices.length === 0) {
      if (!additive) editing.setSelection([]);
      return;
    }
    if (additive) editing.setSelection([...editing.selected, ...indices]);
    else editing.setSelection(indices);
  }

  canvas.addEventListener('pointerdown', (event) => {
    if (event.button !== 0) return;
    suppressing = transform.isDragging === true;
    if (suppressing) return;
    pointerDown = { clientX: event.clientX, clientY: event.clientY };
    if (toolbarState.mode === 'edit' && editing.active) {
      canvas.setPointerCapture?.(event.pointerId);
      beginBoxSelect(event);
    }
  });

  canvas.addEventListener('pointermove', (event) => {
    if (!boxOrigin) return;
    if (transform.isDragging) {
      // The gizmo won the gesture; abandon the selection box.
      selectBox.hidden = true;
      boxOrigin = null;
      return;
    }
    drawBox(boxOrigin.start, localPoint(event));
  });

  canvas.addEventListener('pointerup', (event) => {
    if (event.button !== 0) return;
    if (suppressing) {
      suppressing = false;
      pointerDown = null;
      return;
    }
    const wasBox = boxOrigin !== null;
    const moved = pointerDown
      ? Math.hypot(event.clientX - pointerDown.clientX, event.clientY - pointerDown.clientY) > CLICK_SLOP_PX
      : false;

    if (toolbarState.mode === 'edit' && editing.active && (wasBox || moved)) {
      endBoxSelect(event, event.shiftKey);
      pointerDown = null;
      canvas.releasePointerCapture?.(event.pointerId);
      return;
    }
    if (wasBox) {
      selectBox.hidden = true;
      boxOrigin = null;
    }
    if (!moved) {
      if (toolbarState.mode === 'edit' && editing.active) {
        const index = editing.mesh ? pickVertex(viewport, editing.mesh, event.clientX, event.clientY) : -1;
        editing.select(index, event.shiftKey);
      } else {
        const hit = pickEntry(viewport, world, event.clientX, event.clientY);
        world.select(hit ? hit.entry.id : null);
      }
    }
    pointerDown = null;
  });

  canvas.addEventListener('pointercancel', () => {
    selectBox.hidden = true;
    boxOrigin = null;
    pointerDown = null;
  });

  // -------------------------------------------------------------------------
  // World / selection / timeline reactions
  // -------------------------------------------------------------------------

  bus.on('selection.change', () => {
    if (toolbarState.mode === 'edit' && editing.active) commands.setMode('object');
    syncGizmo();
    updateSelectionHelper();
    refreshChrome();
  });

  bus.on('world.change', (payload) => {
    // New roots pick up the active shading inside viewport.add(); only
    // structural replacements need the gizmo/selection rebuilt here.
    if (payload?.reason === 'replace' || payload?.reason === 'clear') {
      syncGizmo();
      updateSelectionHelper();
    }
    refreshChrome();
  });

  bus.on('gizmo.start', () => {
    world.beginGizmoDrag();
  });

  bus.on('gizmo.end', () => {
    world.endGizmoDrag();
    if (timeline.autoKey && toolbarState.mode === 'object') {
      const entry = world.selectedEntry;
      if (entry) {
        timeline.insertKey(entry, timeline.frame, world.objectTransform(entry));
        notifier.info(`Keyframed ${entry.name} at frame ${timeline.frame}.`);
      }
    }
    updateSelectionHelper();
    refreshChrome();
  });

  bus.on('gizmo.change', () => updateSelectionHelper());
  bus.on('edit.change', () => updateSelectionHelper());
  bus.on('timeline.frame', () => applyKeyframesAtCurrentFrame());

  // -------------------------------------------------------------------------
  // Per-frame update
  // -------------------------------------------------------------------------

  viewport.onFrame((dt) => {
    camera.update(dt);
    timeline.tick(dt);

    const focal =
      viewport.size.height / (2 * Math.tan(degToRad(viewport.camera.fov) / 2));
    const pixelRatio = viewport.renderer.getPixelRatio();
    for (const entry of world.entries) {
      const system = entry.particles;
      if (!system) continue;
      system.step(dt);
      const uniforms = system.material.uniforms;
      uniforms.uPixelRatio.value = pixelRatio;
      uniforms.uFocal.value = focal;
    }
  });

  // -------------------------------------------------------------------------
  // Keyboard shortcuts
  // -------------------------------------------------------------------------

  shortcuts.addAll([
    { keys: 'Tab', group: 'Edit mode', label: 'Toggle object / vertex edit mode', run: () => commands.toggleEditMode() },
    { keys: 'G', group: 'Transform', label: 'Move tool', run: () => commands.setGizmoMode('translate') },
    { keys: 'R', group: 'Transform', label: 'Rotate tool', run: () => commands.setGizmoMode('rotate') },
    { keys: 'S', group: 'Transform', label: 'Scale tool', run: () => commands.setGizmoMode('scale') },
    { keys: 'F', group: 'Transform', label: 'Frame selection (or the whole scene)', run: () => commands.frameSelected() },
    { keys: 'Shift+A', group: 'Object', label: 'Open the Add menu', run: () => toolbar.openMenu('Add') },
    { keys: 'Ctrl+D', group: 'Object', label: 'Duplicate selection', run: () => commands.duplicateSelected() },
    { keys: 'Delete', group: 'Object', label: 'Delete selection', run: () => commands.deleteSelected() },
    { keys: 'F2', group: 'Object', label: 'Rename selection', run: () => commands.renameSelected() },
    { keys: 'Ctrl+Z', group: 'Object', label: 'Undo', run: () => commands.undo() },
    { keys: 'Ctrl+Shift+Z', group: 'Object', label: 'Redo', run: () => commands.redo() },
    { keys: 'Ctrl+Y', group: 'Object', label: 'Redo (alternate)', run: () => commands.redo() },
    { keys: 'Ctrl+A', group: 'Edit mode', label: 'Select all vertices', when: () => editing.active, run: () => commands.selectAllVertices() },
    { keys: 'Escape', group: 'Edit mode', label: 'Clear vertex selection', when: () => editing.active, run: () => commands.clearVertexSelection() },
    { keys: 'Space', group: 'Animation', label: 'Play / pause', run: () => commands.togglePlay() },
    { keys: 'K', group: 'Animation', label: 'Insert keyframe at the playhead', run: () => commands.insertKey() },
    { keys: 'Home', group: 'Animation', label: 'Jump to the first frame', run: () => commands.setFrame(1) },
    { keys: 'End', group: 'Animation', label: 'Jump to the last frame', run: () => commands.setFrame(timeline.endFrame) },
    { keys: 'ArrowLeft', group: 'Animation', label: 'Previous frame', run: () => commands.stepFrame(-1) },
    { keys: 'ArrowRight', group: 'Animation', label: 'Next frame', run: () => commands.stepFrame(1) },
    { keys: 'V', group: 'Camera', label: 'Toggle fly camera', run: () => commands.toggleFly() },
    { keys: 'Numpad1', group: 'Camera', label: 'Front view', run: () => commands.setView('front') },
    { keys: 'Numpad2', group: 'Camera', label: 'Back view', run: () => commands.setView('back') },
    { keys: 'Numpad3', group: 'Camera', label: 'Right view', run: () => commands.setView('right') },
    { keys: 'Numpad4', group: 'Camera', label: 'Left view', run: () => commands.setView('left') },
    { keys: 'Numpad7', group: 'Camera', label: 'Top view', run: () => commands.setView('top') },
    { keys: 'Numpad8', group: 'Camera', label: 'Bottom view', run: () => commands.setView('bottom') },
    { keys: 'F1', group: 'General', label: 'Show this help', run: () => commands.openHelp() },
  ]);
  shortcuts.attach(window);

  // -------------------------------------------------------------------------
  // Initial state
  // -------------------------------------------------------------------------

  transform.setMode('translate');
  transform.setSnapEnabled(false);
  viewport.setShading(toolbarState.shading);
  viewport.setHelpersVisible(toolbarState.helpers);
  setDocName('Untitled');

  if (sceneIsEmpty()) world.create('cube');
  syncGizmo();
  updateSelectionHelper();
  refreshChrome();

  // Refresh undo/redo affordances after the first snapshot lands.
  statusbar.render();
  notifier.info('Welcome to WebBlend Studio. Press F1 for keyboard shortcuts.');

  return {
    dispose() {
      shortcuts.detach();
      camera.dispose();
      transform.dispose();
      viewport.dispose();
    },
  };
}
