// The WebGL viewport: renderer, scene, lighting rig, editor-only helpers
// (grid/axes/selection box) and the render loop. It knows nothing about
// entries or UI - the world and app layers add/remove root objects here.

import * as THREE from 'three';
import { COLORS } from '../core/theme.js';

export class Viewport {
  constructor(container) {
    this.container = container;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(COLORS.background);

    this.camera = new THREE.PerspectiveCamera(52, 1, 0.05, 3000);
    this.camera.position.set(9, 7, 11);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;

    this.canvas = this.renderer.domElement;
    this.canvas.className = 'viewport__canvas';
    this.canvas.tabIndex = 0;
    this.canvas.setAttribute('aria-label', '3D viewport. Right-drag to orbit, middle-drag to pan, scroll to zoom.');
    container.appendChild(this.canvas);

    this.roots = new Set();
    this.editorObjects = new Set();
    this.frameCallbacks = new Set();
    this.raycaster = new THREE.Raycaster();
    this.timer = new THREE.Timer();
    // Use the Page Visibility API so returning to a hidden tab does not produce
    // one huge delta (Timer zeroes it instead).
    this.timer.connect(document);
    this.shading = 'smooth';
    this.helpersVisible = true;
    this.fps = 0;
    this.#frameTimes = [];

    this.#buildLighting();
    this.#buildHelpers();

    this.selectionHelper = new THREE.BoxHelper(new THREE.Object3D(), new THREE.Color(COLORS.selection));
    this.selectionHelper.name = '__editor';
    this.selectionHelper.visible = false;
    this.selectionHelper.material.depthTest = false;
    this.selectionHelper.material.transparent = true;
    this.selectionHelper.material.opacity = 0.9;
    this.addEditorObject(this.selectionHelper);

    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(container);
    this.resize();

    this.running = true;
    // A private method does not carry its `this` when it is passed as a callback,
    // so bind it onto a public (writable) property. Assigning to the private
    // method itself is illegal: private methods are not writable.
    this.tick = this.#tick.bind(this);
    this.rafId = requestAnimationFrame(this.tick);
  }

  #frameTimes;

  #buildLighting() {
    this.hemisphere = new THREE.HemisphereLight(0xdfe8ff, 0x2a2e38, 0.6);
    this.keyLight = new THREE.DirectionalLight(0xffffff, 1.7);
    this.keyLight.position.set(6, 10, 6);
    this.keyLight.castShadow = true;
    this.keyLight.shadow.mapSize.set(2048, 2048);
    this.keyLight.shadow.camera.near = 1;
    this.keyLight.shadow.camera.far = 60;
    const s = 18;
    this.keyLight.shadow.camera.left = -s;
    this.keyLight.shadow.camera.right = s;
    this.keyLight.shadow.camera.top = s;
    this.keyLight.shadow.camera.bottom = -s;
    this.keyLight.shadow.bias = -0.0006;

    this.fillLight = new THREE.DirectionalLight(0xbfd4ff, 0.35);
    this.fillLight.position.set(-7, 5, -6);

    for (const light of [this.hemisphere, this.keyLight, this.fillLight]) {
      light.name = '__editor-light';
      this.scene.add(light);
    }
  }

  #buildHelpers() {
    this.grid = new THREE.GridHelper(120, 120, COLORS.gridMajor, COLORS.gridMinor);
    this.grid.name = '__editor';
    this.grid.material.transparent = true;
    this.grid.material.opacity = 0.75;
    this.grid.material.depthWrite = false;
    this.grid.position.y = -0.001;
    this.addEditorObject(this.grid);

    this.axes = new THREE.AxesHelper(1.5);
    this.axes.name = '__editor';
    this.axes.material.depthWrite = false;
    this.axes.material.transparent = true;
    this.addEditorObject(this.axes);
  }

  addEditorObject(object) {
    this.scene.add(object);
    this.editorObjects.add(object);
  }

  removeEditorObject(object) {
    this.scene.remove(object);
    this.editorObjects.delete(object);
  }

  add(root) {
    this.scene.add(root);
    this.roots.add(root);
    this.#applyShadingTo(root);
  }

  remove(root) {
    this.scene.remove(root);
    this.roots.delete(root);
  }

  /** Register a per-frame callback; returns a disposer. */
  onFrame(callback) {
    this.frameCallbacks.add(callback);
    return () => this.frameCallbacks.delete(callback);
  }

  pointerToNDC(clientX, clientY) {
    const rect = this.canvas.getBoundingClientRect();
    return new THREE.Vector2(
      ((clientX - rect.left) / rect.width) * 2 - 1,
      -((clientY - rect.top) / rect.height) * 2 + 1,
    );
  }

  /** Canvas size in CSS pixels (used for screen-space picking thresholds). */
  get size() {
    const rect = this.canvas.getBoundingClientRect();
    return { width: rect.width, height: rect.height };
  }

  /**
   * Raycast against the given roots (recursive) and return the first real hit.
   * Editor helpers (`__helper`, `__bone`, `__editor`) are ignored.
   */
  raycast(clientX, clientY, roots) {
    const ndc = this.pointerToNDC(clientX, clientY);
    this.raycaster.setFromCamera(ndc, this.camera);
    const targets = roots ? [...roots] : [...this.roots];
    const hits = this.raycaster.intersectObjects(targets, true);
    for (const hit of hits) {
      if (!this.#isPickable(hit.object)) continue;
      return hit;
    }
    return null;
  }

  #isPickable(object) {
    let node = object;
    while (node) {
      const name = node.name || '';
      if (name === '__helper' || name === '__bone' || name === '__editor' || name.startsWith('__editor-light')) {
        return false;
      }
      node = node.parent;
    }
    return object.visible !== false;
  }

  setShading(mode) {
    this.shading = mode;
    for (const root of this.roots) this.#applyShadingTo(root);
  }

  #applyShadingTo(root) {
    root.traverse((node) => {
      const material = node.material;
      if (!material || Array.isArray(material)) return;
      if (material.isMeshStandardMaterial || material.isMeshPhongMaterial || material.isMeshLambertMaterial) {
        material.flatShading = this.shading === 'flat';
        material.wireframe = this.shading === 'wireframe';
        material.needsUpdate = true;
      }
    });
  }

  setHelpersVisible(flag) {
    this.helpersVisible = !!flag;
    this.grid.visible = this.helpersVisible;
    this.axes.visible = this.helpersVisible;
  }

  resize() {
    const rect = this.container.getBoundingClientRect();
    const width = Math.max(1, Math.floor(rect.width));
    const height = Math.max(1, Math.floor(rect.height));
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height, false);
  }

  #tick(timestamp) {
    if (!this.running) return;
    this.rafId = requestAnimationFrame(this.tick);
    this.timer.update(timestamp);
    const dt = Math.min(this.timer.getDelta(), 0.05);

    for (const callback of this.frameCallbacks) {
      try {
        callback(dt, this);
      } catch (error) {
        console.error('[viewport] frame callback failed', error);
      }
    }

    if (this.selectionHelper.visible && this.selectionHelper.object) {
      this.selectionHelper.update();
    }

    this.renderer.render(this.scene, this.camera);
    this.#sampleFps(dt);
  }

  #sampleFps(dt) {
    this.#frameTimes.push(dt);
    if (this.#frameTimes.length > 30) this.#frameTimes.shift();
    const avg = this.#frameTimes.reduce((a, b) => a + b, 0) / this.#frameTimes.length;
    this.fps = avg > 0 ? Math.round(1 / avg) : 0;
  }

  dispose() {
    this.running = false;
    cancelAnimationFrame(this.rafId);
    this.timer.dispose();
    this.resizeObserver.disconnect();
    for (const root of [...this.roots]) this.remove(root);
    this.renderer.dispose();
    if (this.canvas.parentNode) this.canvas.parentNode.removeChild(this.canvas);
  }
}