// Wraps THREE.TransformControls for move/rotate/scale (objects and vertex
// selections). In three r0.186 TransformControls extends Controls (it is NOT an
// Object3D), so the visual helper must be added to the scene via getHelper().
// Gizmo lifecycle events are re-emitted on the app bus so the world/history
// layer can snapshot before and commit after a drag.

import * as THREE from 'three';
import { TransformControls } from 'three/addons/controls/TransformControls.js';
import { bus } from '../core/bus.js';

export const MODES = ['translate', 'rotate', 'scale'];

export class TransformTool {
  constructor(camera, domElement) {
    this.controls = new TransformControls(camera, domElement);
    this.controls.setSize(0.9);
    this.helper = this.controls.getHelper();
    this.helper.name = '__editor';
    this.helper.visible = false;

    this.mode = 'translate';
    this.space = 'world';
    this.snapEnabled = false;
    this.snap = { translate: 0.25, rotate: (15 * Math.PI) / 180, scale: 0.1 };
    this.object = null;

    this.controls.addEventListener('mouseDown', () => {
      if (this.controls.dragging) bus.emit('gizmo.start', { object: this.object, mode: this.mode });
    });
    this.controls.addEventListener('objectChange', () => {
      bus.emit('gizmo.change', { object: this.object, mode: this.mode });
    });
    this.controls.addEventListener('mouseUp', () => {
      bus.emit('gizmo.end', { object: this.object, mode: this.mode });
    });
    this.#applySnap();
  }

  attach(object) {
    if (!object) return;
    this.object = object;
    this.controls.attach(object);
    this.helper.visible = true;
  }

  detach() {
    this.object = null;
    this.controls.detach();
    this.helper.visible = false;
  }

  setMode(mode) {
    if (!MODES.includes(mode)) return;
    this.mode = mode;
    this.controls.setMode(mode);
    bus.emit('gizmo.mode', mode);
  }

  setSpace(space) {
    this.space = space === 'local' ? 'local' : 'world';
    this.controls.setSpace(this.space);
  }

  setSnapEnabled(flag) {
    this.snapEnabled = !!flag;
    this.#applySnap();
  }

  setSnapValues(values) {
    this.snap = { ...this.snap, ...values };
    this.#applySnap();
  }

  #applySnap() {
    if (!this.snapEnabled) {
      this.controls.setTranslationSnap(null);
      this.controls.setRotationSnap(null);
      this.controls.setScaleSnap(null);
      return;
    }
    this.controls.setTranslationSnap(this.snap.translate);
    this.controls.setRotationSnap(this.snap.rotate);
    this.controls.setScaleSnap(this.snap.scale);
  }

  get isDragging() {
    return this.controls.dragging === true;
  }

  dispose() {
    this.controls.detach();
    this.controls.dispose();
  }
}