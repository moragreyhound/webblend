// Studio-style viewport camera.
//
// Navigation model (matches Roblox Studio conventions):
//   Right mouse drag .... orbit around the pivot (fly mode: free-look)
//   Middle mouse drag ... pan
//   Mouse wheel ......... dolly toward / away from the pivot
//   W A S D ............. move (in orbit mode the pivot travels with the camera)
//   Q / E ............... down / up
//   Shift ............... speed boost
//   F ................... focus the current target
// Left mouse is reserved for selection and gizmo manipulation, so it never
// rotates the camera - this is what keeps the gizmo and camera from fighting.

import * as THREE from 'three';
import { clamp } from '../core/math.js';

const MIN_RADIUS = 0.4;
const MAX_RADIUS = 800;
const MIN_PITCH = -Math.PI / 2 + 0.02;
const MAX_PITCH = Math.PI / 2 - 0.02;

const VIEW_PRESETS = {
  front: { theta: 0, phi: Math.PI / 2 },
  back: { theta: Math.PI, phi: Math.PI / 2 },
  left: { theta: -Math.PI / 2, phi: Math.PI / 2 },
  right: { theta: Math.PI / 2, phi: Math.PI / 2 },
  top: { theta: 0, phi: 0.02 },
  bottom: { theta: 0, phi: Math.PI - 0.02 },
};

export class StudioCamera {
  constructor(camera, domElement) {
    this.camera = camera;
    this.dom = domElement;
    this.enabled = true;
    this.target = new THREE.Vector3(0, 1, 0);
    this.radius = 12;
    this.theta = Math.PI * 0.28;
    this.phi = Math.PI * 0.36;

    this.fly = false;
    this.yaw = 0;
    this.pitch = 0;
    this.baseSpeed = 9;
    this.lookSensitivity = 0.0032;

    this.keys = new Set();
    this.dragMode = null; // 'orbit' | 'pan' | 'look'
    this.pointerId = null;
    this.last = { x: 0, y: 0 };

    this.#bind();
    this.apply();
  }

  #bind() {
    this.onPointerDown = this.#handlePointerDown.bind(this);
    this.onPointerMove = this.#handlePointerMove.bind(this);
    this.onPointerUp = this.#handlePointerUp.bind(this);
    this.onWheel = this.#handleWheel.bind(this);
    this.onContextMenu = (e) => e.preventDefault();
    this.onKeyDown = (e) => this.#handleKey(e, true);
    this.onKeyUp = (e) => this.#handleKey(e, false);

    this.dom.addEventListener('pointerdown', this.onPointerDown);
    this.dom.addEventListener('pointermove', this.onPointerMove);
    this.dom.addEventListener('pointerup', this.onPointerUp);
    this.dom.addEventListener('pointercancel', this.onPointerUp);
    this.dom.addEventListener('wheel', this.onWheel, { passive: false });
    this.dom.addEventListener('contextmenu', this.onContextMenu);
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', () => this.keys.clear());
  }

  #isTypingTarget(el) {
    if (!el) return false;
    const tag = el.tagName;
    return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || el.isContentEditable;
  }

  #handleKey(event, down) {
    if (this.#isTypingTarget(event.target)) return;
    const code = event.code;
    if (['KeyW', 'KeyA', 'KeyS', 'KeyD', 'KeyQ', 'KeyE', 'ShiftLeft', 'ShiftRight'].includes(code)) {
      if (down) this.keys.add(code);
      else this.keys.delete(code);
    }
  }

  #handlePointerDown(event) {
    if (!this.enabled) return;
    // Left button belongs to selection / gizmo.
    if (event.button === 0) return;
    event.preventDefault();
    this.dom.setPointerCapture?.(event.pointerId);
    this.pointerId = event.pointerId;
    this.last.x = event.clientX;
    this.last.y = event.clientY;
    if (event.button === 1) this.dragMode = 'pan';
    else if (event.button === 2) this.dragMode = this.fly ? 'look' : 'orbit';
  }

  #handlePointerMove(event) {
    if (!this.dragMode || !this.enabled) return;
    const dx = event.clientX - this.last.x;
    const dy = event.clientY - this.last.y;
    this.last.x = event.clientX;
    this.last.y = event.clientY;

    if (this.dragMode === 'pan') {
      this.pan(dx, dy);
    } else if (this.dragMode === 'look') {
      this.yaw -= dx * this.lookSensitivity;
      this.pitch = clamp(this.pitch - dy * this.lookSensitivity, MIN_PITCH, MAX_PITCH);
    } else {
      this.theta -= dx * this.lookSensitivity;
      this.phi = clamp(this.phi - dy * this.lookSensitivity, 0.02, Math.PI - 0.02);
    }
    this.apply();
  }

  #handlePointerUp(event) {
    if (this.pointerId !== null && event.pointerId !== this.pointerId) return;
    this.dom.releasePointerCapture?.(event.pointerId);
    this.pointerId = null;
    this.dragMode = null;
  }

  #handleWheel(event) {
    if (!this.enabled) return;
    event.preventDefault();
    const delta = Math.sign(event.deltaY);
    if (this.fly) this.dolly(-delta * 1.2);
    else this.radius = clamp(this.radius * (delta > 0 ? 1.12 : 0.89), MIN_RADIUS, MAX_RADIUS);
    this.apply();
  }

  /** Pan the camera (and pivot) in screen space. */
  pan(dx, dy) {
    const scale = (this.radius * 0.0022) * (this.fly ? 1 : 1.15);
    const right = new THREE.Vector3().setFromMatrixColumn(this.camera.matrix, 0);
    const up = new THREE.Vector3().setFromMatrixColumn(this.camera.matrix, 1);
    const offset = right.multiplyScalar(-dx * scale).add(up.multiplyScalar(dy * scale));
    this.target.add(offset);
    this.camera.position.add(offset);
  }

  dolly(amount) {
    const forward = new THREE.Vector3();
    this.camera.getWorldDirection(forward);
    this.camera.position.addScaledVector(forward, amount);
    this.target.copy(this.camera.position).addScaledVector(forward, this.radius);
  }

  /** Integrate keyboard movement. Called every frame with dt seconds. */
  update(dt) {
    if (!this.enabled || this.keys.size === 0) return;
    const boost = this.keys.has('ShiftLeft') || this.keys.has('ShiftRight') ? 3 : 1;
    const speed = this.baseSpeed * boost * dt;

    const forward = new THREE.Vector3();
    const right = new THREE.Vector3();
    const up = new THREE.Vector3(0, 1, 0);
    this.camera.getWorldDirection(forward);
    right.crossVectors(forward, up).normalize();

    const move = new THREE.Vector3();
    if (this.keys.has('KeyW')) move.add(forward);
    if (this.keys.has('KeyS')) move.sub(forward);
    if (this.keys.has('KeyD')) move.add(right);
    if (this.keys.has('KeyA')) move.sub(right);
    if (this.keys.has('KeyE')) move.y += 1;
    if (this.keys.has('KeyQ')) move.y -= 1;
    if (move.lengthSq() === 0) return;
    move.normalize().multiplyScalar(speed);

    this.camera.position.add(move);
    this.target.add(move);
    if (this.fly) {
      this.target.copy(this.camera.position).add(forward.multiplyScalar(this.radius));
    }
    this.apply();
  }

  /** Recompute the camera transform from mode state. */
  apply() {
    if (this.fly) {
      const euler = new THREE.Euler(this.pitch, this.yaw, 0, 'YXZ');
      this.camera.quaternion.setFromEuler(euler);
      return;
    }
    const sinPhi = Math.sin(this.phi);
    this.camera.position.set(
      this.target.x + this.radius * sinPhi * Math.sin(this.theta),
      this.target.y + this.radius * Math.cos(this.phi),
      this.target.z + this.radius * sinPhi * Math.cos(this.theta),
    );
    this.camera.lookAt(this.target);
  }

  /** Point the pivot at an object (or Vector3) and frame it. */
  focusOn(object, { framing = 1.7 } = {}) {
    const box = new THREE.Box3();
    if (object && object.isVector3) {
      box.setFromCenterAndSize(object, new THREE.Vector3(0.5, 0.5, 0.5));
    } else if (object) {
      box.setFromObject(object);
    } else {
      box.setFromCenterAndSize(new THREE.Vector3(0, 1, 0), new THREE.Vector3(2, 2, 2));
    }
    if (box.isEmpty()) return;
    const center = box.getCenter(new THREE.Vector3());
    const size = box.getSize(new THREE.Vector3());
    const maxDim = Math.max(size.x, size.y, size.z, 0.4);
    this.target.copy(center);
    this.radius = clamp(maxDim * framing + 1.2, MIN_RADIUS, MAX_RADIUS);
    if (this.fly) this.apply();
    else this.apply();
  }

  /** Snap to an orthographic-style axis view while keeping the pivot & zoom. */
  setView(name) {
    const preset = VIEW_PRESETS[name];
    if (!preset) return;
    if (this.fly) {
      // Leaving free-look: rebuild the orbit from the current pivot.
      this.fly = false;
    }
    this.theta = preset.theta;
    this.phi = preset.phi;
    this.apply();
  }

  setFly(flag) {
    const next = !!flag;
    if (next === this.fly) return;
    if (next) {
      const dir = new THREE.Vector3();
      this.camera.getWorldDirection(dir);
      this.yaw = Math.atan2(-dir.x, -dir.z);
      this.pitch = Math.asin(clamp(dir.y, -1, 1));
      this.fly = true;
    } else {
      const dir = new THREE.Vector3();
      this.camera.getWorldDirection(dir);
      this.target.copy(this.camera.position).addScaledVector(dir, this.radius);
      this.fly = false;
    }
    this.apply();
  }

  setEnabled(flag) {
    this.enabled = !!flag;
  }

  dispose() {
    this.dom.removeEventListener('pointerdown', this.onPointerDown);
    this.dom.removeEventListener('pointermove', this.onPointerMove);
    this.dom.removeEventListener('pointerup', this.onPointerUp);
    this.dom.removeEventListener('pointercancel', this.onPointerUp);
    this.dom.removeEventListener('wheel', this.onWheel);
    this.dom.removeEventListener('contextmenu', this.onContextMenu);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
  }

  toJSON() {
    return {
      target: this.target.toArray(),
      radius: this.radius,
      theta: this.theta,
      phi: this.phi,
      fly: this.fly,
      yaw: this.yaw,
      pitch: this.pitch,
    };
  }

  fromJSON(data) {
    if (!data) return;
    if (Array.isArray(data.target)) this.target.fromArray(data.target);
    if (Number.isFinite(data.radius)) this.radius = clamp(data.radius, MIN_RADIUS, MAX_RADIUS);
    if (Number.isFinite(data.theta)) this.theta = data.theta;
    if (Number.isFinite(data.phi)) this.phi = clamp(data.phi, 0.02, Math.PI - 0.02);
    this.fly = !!data.fly;
    if (Number.isFinite(data.yaw)) this.yaw = data.yaw;
    if (Number.isFinite(data.pitch)) this.pitch = clamp(data.pitch, MIN_PITCH, MAX_PITCH);
    this.apply();
  }
}