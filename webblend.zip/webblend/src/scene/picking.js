// Screen-space picking helpers. Object picking uses the viewport raycaster;
// vertex picking projects geometry to NDC and measures pixel distance.

import * as THREE from 'three';

const VERTEX_PICK_RADIUS = 14; // CSS pixels

/** Pick the top-level entry root under the cursor. Returns null on a miss. */
export function pickEntry(viewport, world, clientX, clientY) {
  const roots = world.pickRoots();
  if (roots.length === 0) return null;
  const hit = viewport.raycast(clientX, clientY, roots);
  if (!hit) return null;
  const entry = world.entryForObject(hit.object);
  if (!entry || entry.visible === false) return null;
  return { entry, point: hit.point.clone(), object: hit.object };
}

/**
 * Find the geometry vertex closest to the cursor.
 * @returns {number} vertex index, or -1 when nothing is within the radius.
 */
export function pickVertex(viewport, mesh, clientX, clientY) {
  const geometry = mesh.geometry;
  const position = geometry?.getAttribute?.('position');
  if (!position) return -1;

  const ndc = viewport.pointerToNDC(clientX, clientY);
  const { width, height } = viewport.size;
  const halfW = width / 2;
  const halfH = height / 2;

  const world = new THREE.Vector3();
  const projected = new THREE.Vector3();
  let best = -1;
  let bestDistance = VERTEX_PICK_RADIUS;

  for (let i = 0; i < position.count; i += 1) {
    world.fromBufferAttribute(position, i);
    mesh.localToWorld(world);
    projected.copy(world).project(viewport.camera);
    if (projected.z < -1 || projected.z > 1) continue;
    const dx = (projected.x - ndc.x) * halfW;
    const dy = (projected.y - ndc.y) * halfH;
    const distance = Math.hypot(dx, dy);
    if (distance < bestDistance) {
      bestDistance = distance;
      best = i;
    }
  }
  return best;
}

/** Vertices whose projected position falls inside a screen-space box. */
export function pickVerticesInBox(viewport, mesh, box) {
  const position = mesh.geometry?.getAttribute?.('position');
  if (!position) return [];
  const { width, height } = viewport.size;
  const halfW = width / 2;
  const halfH = height / 2;
  const rect = viewport.canvas.getBoundingClientRect();
  const world = new THREE.Vector3();
  const projected = new THREE.Vector3();
  const found = [];
  for (let i = 0; i < position.count; i += 1) {
    world.fromBufferAttribute(position, i);
    mesh.localToWorld(world);
    projected.copy(world).project(viewport.camera);
    const sx = rect.left + (projected.x + 1) * halfW;
    const sy = rect.top + (1 - projected.y) * halfH;
    if (sx >= box.minX && sx <= box.maxX && sy >= box.minY && sy <= box.maxY) found.push(i);
  }
  return found;
}