// Edit-mode vertex selection and manipulation for a single mesh.
//
// The gizmo never touches vertices directly: it drives a lightweight pivot
// Object3D parented to the mesh, and the editor applies the pivot's delta to
// the selected vertices every time the gizmo reports a change. Working in the
// mesh's local space keeps the math independent of the mesh's world transform.

import * as THREE from 'three';
import { bus } from '../core/bus.js';
import { COLORS } from '../core/theme.js';

const MAX_WELD_VERTICES = 60000;
const MERGE_EPSILON = 0.001;

export class VertexEditor {
  constructor(viewport, transformTool) {
    this.viewport = viewport;
    this.transform = transformTool;
    this.mesh = null;
    this.active = false;
    this.selected = new Set();
    this.base = null;
    this.start = null;

    this.pivot = new THREE.Object3D();
    this.pivot.name = '__editor';

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(0), 3));
    this.overlay = new THREE.Points(
      geo,
      new THREE.PointsMaterial({
        color: new THREE.Color(COLORS.vertex),
        size: 9,
        sizeAttenuation: false,
        depthTest: false,
        transparent: true,
      }),
    );
    this.overlay.name = '__editor';
    this.overlay.visible = false;
    this.overlay.frustumCulled = false;
    this.viewport.addEditorObject(this.overlay);

    bus.on('gizmo.start', () => this.#captureStart());
    bus.on('gizmo.change', () => {
      if (this.#ownsGizmo()) this.apply();
    });
    bus.on('gizmo.end', () => {
      if (this.#ownsGizmo()) this.finish();
    });

    this.viewport.onFrame(() => {
      if (this.active) this.updateOverlay();
    });
  }

  #ownsGizmo() {
    return this.active && this.transform.object === this.pivot && !!this.mesh;
  }

  get vertexCount() {
    return this.mesh?.geometry?.getAttribute?.('position')?.count ?? 0;
  }

  enter(mesh) {
    if (this.active) this.exit();
    if (!mesh || !mesh.geometry) return false;
    const position = mesh.geometry.getAttribute('position');
    if (!position) return false;

    this.mesh = mesh;
    this.active = true;
    this.selected.clear();
    mesh.add(this.pivot);
    this.pivot.position.copy(this.#restCentroid());
    this.pivot.quaternion.identity();
    this.pivot.scale.set(1, 1, 1);
    this.transform.attach(this.pivot);
    this.updateOverlay();
    this.overlay.visible = true;
    bus.emit('edit.change', { mesh });
    return true;
  }

  exit() {
    if (!this.active) return;
    this.transform.detach();
    this.mesh?.remove(this.pivot);
    this.selected.clear();
    this.base = null;
    this.start = null;
    this.overlay.visible = false;
    this.overlay.geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(0), 3));
    this.mesh = null;
    this.active = false;
    bus.emit('edit.change', { mesh: null });
  }

  #restCentroid() {
    const position = this.mesh.geometry.getAttribute('position');
    const box = new THREE.Box3();
    const v = new THREE.Vector3();
    for (let i = 0; i < position.count; i += 1) {
      box.expandByPoint(v.fromBufferAttribute(position, i));
    }
    return box.isEmpty() ? new THREE.Vector3() : box.getCenter(new THREE.Vector3());
  }

  setSelection(indices) {
    this.selected = new Set(indices);
    if (this.selected.size > 0) this.pivot.position.copy(this.#selectionCentroid());
    this.updateOverlay();
    bus.emit('edit.selection', { count: this.selected.size });
  }

  select(index, additive = false) {
    if (index < 0) {
      if (!additive) this.setSelection([]);
      return;
    }
    if (additive) {
      if (this.selected.has(index)) this.selected.delete(index);
      else this.selected.add(index);
      this.setSelection([...this.selected]);
    } else {
      this.setSelection([index]);
    }
  }

  selectAll() {
    const indices = [];
    for (let i = 0; i < this.vertexCount; i += 1) indices.push(i);
    this.setSelection(indices);
  }

  #selectionCentroid() {
    const position = this.mesh.geometry.getAttribute('position');
    const centroid = new THREE.Vector3();
    if (this.selected.size === 0) return this.#restCentroid();
    for (const index of this.selected) centroid.add(new THREE.Vector3().fromBufferAttribute(position, index));
    return centroid.divideScalar(this.selected.size);
  }

  #captureStart() {
    if (!this.#ownsGizmo() || this.selected.size === 0) return;
    const position = this.mesh.geometry.getAttribute('position');
    this.base = new Map();
    for (const index of this.selected) {
      this.base.set(index, new THREE.Vector3().fromBufferAttribute(position, index));
    }
    this.start = {
      position: this.pivot.position.clone(),
      quaternion: this.pivot.quaternion.clone(),
      scale: this.pivot.scale.clone(),
    };
  }

  /** Apply the pivot's delta (current · start⁻¹) to the selected vertices. */
  apply() {
    if (!this.base || !this.start || this.selected.size === 0) return;
    const position = this.mesh.geometry.getAttribute('position');

    // delta = C * S^-1 maps any point expressed in the pivot's start frame to
    // the same rotation/scale/translation the gizmo applied to the pivot. This
    // is exactly how TransformControls moves its attached object, so vertices
    // follow the handles without drift.
    const startMatrix = new THREE.Matrix4().compose(
      this.start.position,
      this.start.quaternion,
      this.start.scale,
    );
    const currentMatrix = new THREE.Matrix4().compose(
      this.pivot.position,
      this.pivot.quaternion,
      this.pivot.scale,
    );
    const delta = currentMatrix.multiply(startMatrix.invert());

    const local = new THREE.Vector3();
    for (const [index, base] of this.base) {
      local.copy(base).applyMatrix4(delta);
      position.setXYZ(index, local.x, local.y, local.z);
    }
    position.needsUpdate = true;
    this.mesh.geometry.computeBoundingSphere();
    this.updateOverlay();
  }

  /** Called when a drag ends: refresh normals once instead of every frame. */
  finish() {
    if (!this.mesh) return;
    this.mesh.geometry.computeVertexNormals();
    this.mesh.geometry.computeBoundingBox();
    this.base = null;
    this.start = null;
    bus.emit('edit.change', { mesh: this.mesh });
  }

  updateOverlay() {
    if (!this.active || !this.mesh) return;
    const position = this.mesh.geometry.getAttribute('position');
    const count = this.selected.size;
    const array = new Float32Array(count * 3);
    const v = new THREE.Vector3();
    let write = 0;
    for (const index of this.selected) {
      v.fromBufferAttribute(position, index);
      this.mesh.localToWorld(v);
      array[write] = v.x;
      array[write + 1] = v.y;
      array[write + 2] = v.z;
      write += 3;
    }
    this.overlay.geometry.setAttribute('position', new THREE.BufferAttribute(array, 3));
    this.overlay.geometry.computeBoundingSphere();
  }

  /**
   * Merge vertices that land in the same epsilon grid cell (Blender's
   * "merge by distance"). Returns a summary for the caller to report.
   */
  weld(epsilon = MERGE_EPSILON) {
    if (!this.mesh) return { merged: 0, reason: 'no-mesh' };
    const geometry = this.mesh.geometry;
    const position = geometry.getAttribute('position');
    if (!position) return { merged: 0, reason: 'no-position' };
    const vertexCount = position.count;
    if (vertexCount > MAX_WELD_VERTICES) return { merged: 0, reason: 'too-large' };

    const cell = Math.max(1e-6, Number(epsilon) || MERGE_EPSILON);
    const buckets = new Map();
    const remap = new Int32Array(vertexCount);
    const merged = [];

    for (let i = 0; i < vertexCount; i += 1) {
      const x = position.getX(i);
      const y = position.getY(i);
      const z = position.getZ(i);
      const key = `${Math.round(x / cell)},${Math.round(y / cell)},${Math.round(z / cell)}`;
      let target = buckets.get(key);
      if (target === undefined) {
        target = merged.length / 3;
        buckets.set(key, target);
        merged.push(x, y, z);
      }
      remap[i] = target;
    }

    const mergedCount = merged.length / 3;
    if (mergedCount === vertexCount) return { merged: 0, reason: 'nothing-to-merge' };

    // A representative original index per surviving vertex keeps side
    // attributes (uv, normal, color) consistent.
    const representative = new Int32Array(mergedCount).fill(-1);
    for (let i = 0; i < vertexCount; i += 1) {
      if (representative[remap[i]] === -1) representative[remap[i]] = i;
    }

    for (const name of Object.keys(geometry.attributes)) {
      if (name === 'position') continue;
      const attr = geometry.attributes[name];
      const itemSize = attr.itemSize;
      const next = new attr.array.constructor(mergedCount * itemSize);
      for (let i = 0; i < mergedCount; i += 1) {
        const src = representative[i];
        for (let c = 0; c < itemSize; c += 1) {
          next[i * itemSize + c] = src >= 0 ? attr.array[src * itemSize + c] : 0;
        }
      }
      geometry.setAttribute(name, new THREE.BufferAttribute(next, itemSize, attr.normalized));
    }
    geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(merged), 3));

    if (geometry.index) {
      const old = geometry.index.array;
      const next = new Uint32Array(old.length);
      for (let i = 0; i < old.length; i += 1) next[i] = remap[old[i]];
      geometry.setIndex(new THREE.BufferAttribute(next, 1));
    } else {
      const next = new Uint32Array(vertexCount);
      for (let i = 0; i < vertexCount; i += 1) next[i] = remap[i];
      geometry.setIndex(new THREE.BufferAttribute(next, 1));
    }

    geometry.computeVertexNormals();
    geometry.computeBoundingBox();
    geometry.computeBoundingSphere();
    this.selected.clear();
    this.updateOverlay();
    return { merged: vertexCount - mergedCount, reason: 'ok' };
  }
}