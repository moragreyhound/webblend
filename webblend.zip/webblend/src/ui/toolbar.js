// Top chrome: brand, menu bar, mode/transform segments and quick toggles.
//
// All actions route through ctx.commands so undo/history and notifications have a
// single owner. Toggle buttons expose aria-pressed so their state is conveyed
// beyond colour.

import { h } from './dom.js';
import { icon } from './icons.js';
import { createMenu } from './dom.js';
import { TYPES } from '../objects/registry.js';
import { EXPORT_FORMATS } from '../io/format.js';

export function createToolbar(ctx) {
  const state = ctx.toolbarState;

  let menus = [];
  let segments = {};
  let toggles = {};

  function destroyMenus() {
    for (const menu of menus) menu.element.remove();
    menus = [];
  }

  function menuButton(label, items, iconName) {
    const button = h(
      'button',
      { class: 'menubtn', type: 'button', 'aria-haspopup': 'true', 'aria-expanded': 'false' },
      iconName ? icon(iconName, { size: 15 }) : null,
      h('span', { text: label }),
    );
    const menu = createMenu(items);
    button.addEventListener('click', () => menu.toggle(button));
    menubtnState.set(button, menu);
    namedMenus.set(label, { button, menu });
    menus.push(menu);
    return button;
  }

  const menubtnState = new Map();
  const namedMenus = new Map();

  function items(...list) {
    return list;
  }

  function sep() {
    return { separator: true };
  }

  function meshItems() {
    return TYPES.filter((t) => t.kind === 'mesh' && !t.hidden).map((type) => ({
      label: type.label,
      icon: icon(type.icon, { size: 16 }),
      onSelect: () => ctx.commands.create(type.id),
    }));
  }

  function lightItems() {
    return TYPES.filter((t) => t.kind === 'light').map((type) => ({
      label: type.label,
      icon: icon(type.icon, { size: 16 }),
      onSelect: () => ctx.commands.create(type.id),
    }));
  }

  function fileMenu() {
    return items(
      { label: 'New scene', icon: icon('add', { size: 16 }), onSelect: () => ctx.commands.newScene() },
      { label: 'Open project…', icon: icon('folder_open', { size: 16 }), shortcut: 'Ctrl+O', onSelect: () => ctx.commands.openProject() },
      { label: 'Save project', icon: icon('save', { size: 16 }), shortcut: 'Ctrl+S', onSelect: () => ctx.commands.saveProject() },
      sep(),
      { label: 'Import model…', icon: icon('upload', { size: 16 }), shortcut: 'Ctrl+I', onSelect: () => ctx.commands.importFiles() },
      sep(),
      ...EXPORT_FORMATS.map((format) => ({
        label: `Export ${format.toUpperCase()} (whole scene)`,
        icon: icon('download', { size: 16 }),
        onSelect: () => ctx.commands.exportScene({ format, selectedOnly: false }),
      })),
      {
        label: 'Export GLB (selection only)',
        icon: icon('download', { size: 16 }),
        onSelect: () => ctx.commands.exportScene({ format: 'glb', selectedOnly: true }),
      },
    );
  }

  function addMenu() {
    return items(
      ...meshItems(),
      sep(),
      ...lightItems(),
      sep(),
      ...TYPES.filter((t) => ['camera', 'empty', 'particles', 'smoke', 'armature'].includes(t.id)).map((type) => ({
        label: type.label,
        icon: icon(type.icon, { size: 16 }),
        onSelect: () => ctx.commands.create(type.id),
      })),
    );
  }

  function objectMenu() {
    const selected = Boolean(ctx.world.selectedEntry);
    return items(
      { label: 'Rename', shortcut: 'F2', disabled: !selected, onSelect: () => ctx.commands.renameSelected() },
      { label: 'Duplicate', icon: icon('content_copy', { size: 16 }), shortcut: 'Ctrl+D', disabled: !selected, onSelect: () => ctx.commands.duplicateSelected() },
      {
        label: 'Delete',
        icon: icon('delete', { size: 16 }),
        shortcut: 'Del',
        disabled: !selected,
        onSelect: () => ctx.commands.deleteSelected(),
      },
      sep(),
      { label: 'Undo', icon: icon('undo', { size: 16 }), shortcut: 'Ctrl+Z', disabled: !ctx.world.canUndo(), onSelect: () => ctx.commands.undo() },
      { label: 'Redo', icon: icon('redo', { size: 16 }), shortcut: 'Ctrl+Shift+Z', disabled: !ctx.world.canRedo(), onSelect: () => ctx.commands.redo() },
      sep(),
      { label: 'Frame selected', icon: icon('center_focus_strong', { size: 16 }), shortcut: 'F', onSelect: () => ctx.commands.frameSelected() },
      { label: 'Toggle wireframe', icon: icon('grid_on', { size: 16 }), onSelect: () => ctx.commands.toggleWireframe() },
    );
  }

  function editMenu() {
    const editing = state.mode === 'edit';
    return items(
      { label: editing ? 'Leave edit mode' : 'Enter edit mode', icon: icon('edit', { size: 16 }), shortcut: 'Tab', onSelect: () => ctx.commands.toggleEditMode() },
      sep(),
      { label: 'Select all vertices', shortcut: 'Ctrl+A', disabled: !editing, onSelect: () => ctx.commands.selectAllVertices() },
      { label: 'Clear vertex selection', shortcut: 'Esc', disabled: !editing, onSelect: () => ctx.commands.clearVertexSelection() },
      sep(),
      { label: 'Weld vertices (merge by distance)', icon: icon('layers', { size: 16 }), disabled: !editing, onSelect: () => ctx.commands.weldVertices() },
    );
  }

  function viewMenu() {
    const current = state.shading;
    return items(
      ...['front', 'back', 'left', 'right', 'top', 'bottom'].map((view) => ({
        label: `${view[0].toUpperCase()}${view.slice(1)} view`,
        onSelect: () => ctx.commands.setView(view),
      })),
      { label: 'Perspective (home)', onSelect: () => ctx.commands.resetView() },
      sep(),
      ...['smooth', 'flat', 'wireframe'].map((mode) => ({
        label: `Shading: ${mode}`,
        checked: current === mode,
        onSelect: () => ctx.commands.setShading(mode),
      })),
      sep(),
      { label: 'Toggle grid & axes', checked: state.helpers, onSelect: () => ctx.commands.toggleHelpers() },
      { label: 'Fly mode', checked: state.fly, onSelect: () => ctx.commands.toggleFly() },
    );
  }

  function helpMenu() {
    return items(
      { label: 'Keyboard shortcuts', icon: icon('help', { size: 16 }), onSelect: () => ctx.commands.openHelp() },
      { label: 'About WebBlend Studio', icon: icon('info', { size: 16 }), onSelect: () => ctx.commands.openAbout() },
    );
  }

  const menubar = h('nav', { class: 'menubar', 'aria-label': 'Main menu' });

  function buildMenubar() {
    destroyMenus();
    menubtnState.clear();
    namedMenus.clear();
    menubar.replaceChildren(
      menuButton('File', fileMenu(), 'folder_open'),
      menuButton('Add', addMenu(), 'add'),
      menuButton('Object', objectMenu(), 'category'),
      menuButton('Edit', editMenu(), 'edit'),
      menuButton('View', viewMenu(), 'visibility'),
      menuButton('Help', helpMenu(), 'help'),
    );
  }

  function segment(name, options, { ariaLabel }) {
    const container = h('div', { class: 'seg', role: 'group', 'aria-label': ariaLabel });
    const buttons = new Map();
    for (const option of options) {
      const button = h(
        'button',
        {
          class: 'seg__btn',
          type: 'button',
          'aria-pressed': String(state[name] === option.value),
          title: option.title ?? option.label,
        },
        option.icon ? icon(option.icon, { size: 15 }) : null,
        option.hideLabel ? null : h('span', { text: option.label }),
      );
      button.addEventListener('click', () => option.onSelect());
      buttons.set(option.value, button);
      container.appendChild(button);
    }
    segments[name] = { container, buttons };
    return container;
  }

  function toggleButton(key, iconName, label, onSelect) {
    const button = h('button', {
      class: 'iconbtn toggle',
      type: 'button',
      'aria-label': label,
      'aria-pressed': String(!!state[key]),
      title: label,
    });
    button.appendChild(icon(iconName, { size: 17 }));
    button.addEventListener('click', () => onSelect());
    toggles[key] = button;
    return button;
  }

  const modeSeg = segment(
    'mode',
    [
      { value: 'object', label: 'Object', onSelect: () => ctx.commands.setMode('object') },
      { value: 'edit', label: 'Edit', onSelect: () => ctx.commands.setMode('edit') },
    ],
    { ariaLabel: 'Interaction mode' },
  );

  const gizmoSeg = segment(
    'gizmo',
    [
      { value: 'translate', label: 'Move', icon: 'open_with', hideLabel: true, title: 'Move (G)', onSelect: () => ctx.commands.setGizmoMode('translate') },
      { value: 'rotate', label: 'Rotate', icon: 'rotate_right', hideLabel: true, title: 'Rotate (R)', onSelect: () => ctx.commands.setGizmoMode('rotate') },
      { value: 'scale', label: 'Scale', icon: 'aspect_ratio', hideLabel: true, title: 'Scale (S)', onSelect: () => ctx.commands.setGizmoMode('scale') },
    ],
    { ariaLabel: 'Transform tool' },
  );

  const root = h(
    'header',
    { class: 'topbar' },
    h(
      'div',
      { class: 'topbar__brand' },
      icon('deployed_code', { size: 20, className: 'brand__mark' }),
      h('span', { class: 'brand__name', text: 'WebBlend Studio' }),
      h('span', { class: 'topbar__doc', text: ctx.docName ?? 'Untitled', title: 'Current project' }),
    ),
    menubar,
    h('span', { class: 'spacer' }),
    modeSeg,
    gizmoSeg,
    h(
      'div',
      { class: 'topbar__tools' },
      toggleButton('snap', 'straighten', 'Snap to grid', () => ctx.commands.toggleSnap()),
      toggleButton('wireframe', 'grid_on', 'Wireframe shading', () => ctx.commands.toggleWireframe()),
      toggleButton('helpers', 'grid_4x4', 'Show grid and axes', () => ctx.commands.toggleHelpers()),
      toggleButton('fly', 'flight', 'Fly (free-look) camera', () => ctx.commands.toggleFly()),
    ),
    h(
      'div',
      { class: 'topbar__tools' },
      quickButton('undo', 'Undo (Ctrl+Z)', () => ctx.commands.undo()),
      quickButton('redo', 'Redo (Ctrl+Shift+Z)', () => ctx.commands.redo()),
      quickButton('center_focus_strong', 'Frame selected (F)', () => ctx.commands.frameSelected()),
      quickButton('help', 'Keyboard shortcuts (?)', () => ctx.commands.openHelp()),
    ),
  );

  function quickButton(iconName, label, onSelect) {
    const button = h('button', { class: 'iconbtn', type: 'button', 'aria-label': label, title: label });
    button.appendChild(icon(iconName, { size: 17 }));
    button.addEventListener('click', onSelect);
    return button;
  }

  function render() {
    buildMenubar();
    for (const [key, entry] of Object.entries(segments)) {
      for (const [value, button] of entry.buttons) {
        const on = state[key] === value;
        button.setAttribute('aria-pressed', String(on));
        button.classList.toggle('is-on', on);
      }
    }
    const editable = state.canEdit;
    const editButton = segments.mode.buttons.get('edit');
    if (editButton) editButton.disabled = !editable;
    for (const [key, button] of Object.entries(toggles)) {
      const on = !!state[key];
      button.setAttribute('aria-pressed', String(on));
      button.classList.toggle('is-on', on);
    }
  }

  ctx.bus.on('gizmo.mode', render);
  render();

  return {
    element: root,
    render,
    state,
    /** Open a named top-level menu (used by keyboard shortcuts). */
    openMenu(name) {
      const entry = namedMenus.get(name);
      if (entry) entry.menu.open(entry.button);
    },
  };
}
