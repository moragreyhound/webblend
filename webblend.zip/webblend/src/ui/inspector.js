// Inspector: edits the selected entry's transform, geometry, material, light,
// camera, particle and armature data.
//
// Live-edit contract: sliders and number fields preview on `input` and record a
// single undo step on `change` (see fields.js). Discrete controls (checkbox,
// select, buttons) record immediately through ctx.commands / world.record.

import { h, clear } from './dom.js';
import { icon } from './icons.js';
import { getType, PRIMITIVE_DATA } from '../objects/registry.js';
import { PARTICLE_PRESETS } from '../objects/particles.js';
import { radToDeg, degToRad } from '../core/math.js';
import {
  fieldRow,
  numberInput,
  rangeInput,
  colorInput,
  checkboxInput,
  selectInput,
  vec3Input,
  section,
} from './fields.js';

const AXES = ['x', 'y', 'z'];

export function createInspector(ctx) {
  const body = h('div', { class: 'panel__body' });
  const element = h(
    'aside',
    { class: 'panel panel--inspector', 'aria-label': 'Properties' },
    h('div', { class: 'panel__head' }, h('h2', { class: 'panel__title', text: 'Properties' })),
    body,
  );

  let transformRefs = null;

  function currentEntry() {
    return ctx.world.selectedEntry;
  }

  function selectionCount() {
    return ctx.world.selectedEntry ? 1 : 0;
  }

  function live(apply) {
    return {
      onStart: () => ctx.beginLive(),
      onInput: (v) => apply(v),
      onCommit: (v) => {
        apply(v);
        ctx.commitLive();
      },
    };
  }

  // -------------------------------------------------------------------------
  // Sections
  // -------------------------------------------------------------------------

  function headerSection(entry) {
    const type = getType(entry.typeId);
    const nameInput = h('input', {
      class: 'input input--name',
      type: 'text',
      value: entry.name,
      'aria-label': 'Object name',
    });
    nameInput.addEventListener('change', () => ctx.commands.renameEntry(entry, nameInput.value));

    const visible = checkboxInput({
      checked: entry.visible,
      onChange: (checked) => ctx.commands.setEntryVisible(entry, checked),
    });

    const focus = h('button', { class: 'btn btn--icon', type: 'button', title: 'Frame selected (F)', 'aria-label': 'Frame selected' });
    focus.appendChild(icon('frame_inspect', { size: 16 }));
    focus.addEventListener('click', () => ctx.commands.frameSelected());

    const duplicate = h('button', { class: 'btn btn--icon', type: 'button', title: 'Duplicate (Ctrl+D)', 'aria-label': 'Duplicate' });
    duplicate.appendChild(icon('content_copy', { size: 16 }));
    duplicate.addEventListener('click', () => ctx.commands.duplicateSelected());

    const remove = h('button', { class: 'btn btn--icon btn--danger', type: 'button', title: 'Delete (Del)', 'aria-label': 'Delete' });
    remove.appendChild(icon('delete', { size: 16 }));
    remove.addEventListener('click', () => ctx.commands.deleteEntry(entry));

    return h(
      'div',
      { class: 'inspector__head' },
      h('div', { class: 'inspector__type' }, icon(type?.icon ?? 'deployed_code', { size: 15 }), h('span', { text: type?.label ?? entry.typeId })),
      nameInput,
      h(
        'div',
        { class: 'inspector__actions' },
        h('label', { class: 'chk' }, visible, h('span', { text: 'Visible' })),
        h('span', { class: 'spacer' }),
        focus,
        duplicate,
        remove,
      ),
    );
  }

  function transformSection(entry) {
    const object = entry.object;
    const position = vec3Input({
      values: [object.position.x, object.position.y, object.position.z],
      step: 0.1,
      onStart: () => ctx.beginLive(),
      onInput: (i, v) => {
        object.position.setComponent(i, v);
        ctx.onTransformChanged(entry);
      },
      onCommit: (i, v) => {
        object.position.setComponent(i, v);
        ctx.commitLive();
      },
    });

    const rotation = vec3Input({
      values: [radToDeg(object.rotation.x), radToDeg(object.rotation.y), radToDeg(object.rotation.z)],
      step: 1,
      onStart: () => ctx.beginLive(),
      onInput: (i, v) => {
        object.rotation[AXES[i]] = degToRad(v);
        ctx.onTransformChanged(entry);
      },
      onCommit: (i, v) => {
        object.rotation[AXES[i]] = degToRad(v);
        ctx.commitLive();
      },
    });

    const scale = vec3Input({
      values: [object.scale.x, object.scale.y, object.scale.z],
      step: 0.1,
      onStart: () => ctx.beginLive(),
      onInput: (i, v) => {
        object.scale.setComponent(i, v);
        ctx.onTransformChanged(entry);
      },
      onCommit: (i, v) => {
        object.scale.setComponent(i, v);
        ctx.commitLive();
      },
    });

    transformRefs = { entry, object, position, rotation, scale };

    const { element: box, body: boxBody } = section('Transform');
    boxBody.appendChild(fieldRow('Position', position.element));
    boxBody.appendChild(fieldRow('Rotation', rotation.element));
    boxBody.appendChild(fieldRow('Scale', scale.element));

    const snap = checkboxInput({ checked: ctx.toolbarState.snap, onChange: (v) => ctx.commands.setSnap(v) });
    boxBody.appendChild(fieldRow('Snap', h('span', { class: 'row__inline' }, snap, h('span', { class: 'muted', text: 'along the grid' }))));
    return box;
  }

  function geometrySection(entry) {
    const data = PRIMITIVE_DATA[entry.typeId];
    if (!data || !entry.data.primitive) return null;
    const { element: box, body: boxBody } = section('Geometry');
    for (const [key, value] of Object.entries(entry.data.primitive)) {
      const input = numberInput({
        value,
        min: 0.01,
        step: 0.05,
        ...live((v) => {
          entry.data.primitive[key] = Math.max(0.01, v);
          rebuildGeometry(entry);
        }),
      });
      boxBody.appendChild(fieldRow(prettyLabel(key), input));
    }
    return box;
  }

  function rebuildGeometry(entry) {
    const type = getType(entry.typeId);
    if (!type) return;
    const rebuilt = type.make({ ...entry.data.primitive });
    const previous = entry.object.geometry;
    entry.object.geometry = rebuilt.geometry;
    previous?.dispose();
    contextHack(entry);
  }

  function contextHack(entry) {
    // Keep the selection box in sync with the new geometry.
    ctx.refreshSelectionHelper?.(entry);
  }

  function materialTarget(entry) {
    const material = entry.object.material;
    if (!material || Array.isArray(material)) return null;
    return material;
  }

  function materialSection(entry) {
    const material = materialTarget(entry);
    if (!material) return null;
    const data = (entry.data.material ??= {
      color: `#${material.color?.getHexString?.() ?? '808080'}`,
      roughness: material.roughness ?? 0.6,
      metalness: material.metalness ?? 0.1,
      flatShading: !!material.flatShading,
      wireframe: !!material.wireframe,
      opacity: material.opacity ?? 1,
      transparent: !!material.transparent,
    });

    const sync = () => {
      entry.data.material = {
        color: `#${material.color.getHexString()}`,
        roughness: material.roughness,
        metalness: material.metalness,
        flatShading: material.flatShading,
        wireframe: material.wireframe,
        opacity: material.opacity,
        transparent: material.transparent,
      };
    };

    const { element: box, body: boxBody } = section('Material');

    boxBody.appendChild(
      fieldRow(
        'Base color',
        colorInput({
          value: data.color,
          onInput: (v) => {
            material.color.set(v);
            sync();
          },
          onCommit: (v) => {
            ctx.beginLive();
            material.color.set(v);
            sync();
            ctx.commitLive();
          },
        }),
      ),
    );
    boxBody.appendChild(
      fieldRow(
        'Roughness',
        rangeInput({
          value: data.roughness,
          min: 0,
          max: 1,
          label: 'Roughness',
          ...live((v) => {
            material.roughness = v;
            sync();
          }),
        }),
      ),
    );
    boxBody.appendChild(
      fieldRow(
        'Metalness',
        rangeInput({
          value: data.metalness,
          min: 0,
          max: 1,
          label: 'Metalness',
          ...live((v) => {
            material.metalness = v;
            sync();
          }),
        }),
      ),
    );
    boxBody.appendChild(
      fieldRow(
        'Opacity',
        rangeInput({
          value: data.opacity,
          min: 0.05,
          max: 1,
          label: 'Opacity',
          ...live((v) => {
            material.opacity = v;
            material.transparent = v < 1 || data.transparent;
            sync();
          }),
        }),
      ),
    );
    boxBody.appendChild(
      fieldRow(
        'Transparent',
        checkboxInput({
          checked: !!data.transparent,
          onChange: (v) =>
            ctx.commands.mutate(() => {
              material.transparent = v;
              material.needsUpdate = true;
              sync();
            }),
        }),
      ),
    );
    // Shading family (smooth / flat / wireframe) is a global view mode owned by
    // the View menu and the toolbar, so it is intentionally not duplicated here.
    boxBody.appendChild(
      h('p', { class: 'muted', text: 'Smooth, flat and wireframe shading are set from View → Shading.' }),
    );
    return box;
  }

  function lightSection(entry) {
    const light = entry.object;
    if (!light?.isLight) return null;
    const { element: box, body: boxBody } = section('Light');
    const sync = () => {
      entry.data.light = {
        color: `#${light.color.getHexString()}`,
        intensity: light.intensity,
        distance: 'distance' in light ? light.distance : undefined,
        angle: 'angle' in light ? light.angle : undefined,
        penumbra: 'penumbra' in light ? light.penumbra : undefined,
        castShadow: light.castShadow,
      };
    };
    boxBody.appendChild(
      fieldRow(
        'Color',
        colorInput({
          value: `#${light.color.getHexString()}`,
          onInput: (v) => light.color.set(v),
          onCommit: (v) => {
            ctx.beginLive();
            light.color.set(v);
            sync();
            ctx.commitLive();
          },
        }),
      ),
    );
    boxBody.appendChild(
      fieldRow(
        'Intensity',
        rangeInput({
          value: light.intensity,
          min: 0,
          max: light.isPointLight || light.isSpotLight ? 200 : 6,
          label: 'Intensity',
          ...live((v) => {
            light.intensity = v;
            sync();
          }),
        }),
      ),
    );
    if ('distance' in light) {
      boxBody.appendChild(
        fieldRow(
          'Range',
          rangeInput({
            value: light.distance || 20,
            min: 0,
            max: 100,
            label: 'Range',
            ...live((v) => {
              light.distance = v;
              sync();
            }),
          }),
        ),
      );
    }
    if ('angle' in light) {
      boxBody.appendChild(
        fieldRow(
          'Cone angle',
          rangeInput({
            value: radToDeg(light.angle),
            min: 1,
            max: 90,
            digits: 0,
            label: 'Cone angle',
            ...live((v) => {
              light.angle = degToRad(v);
              sync();
            }),
          }),
        ),
      );
      boxBody.appendChild(
        fieldRow(
          'Penumbra',
          rangeInput({
            value: light.penumbra,
            min: 0,
            max: 1,
            label: 'Penumbra',
            ...live((v) => {
              light.penumbra = v;
              sync();
            }),
          }),
        ),
      );
    }
    boxBody.appendChild(
      fieldRow(
        'Cast shadow',
        checkboxInput({
          checked: !!light.castShadow,
          onChange: (v) =>
            ctx.commands.mutate(() => {
              light.castShadow = v;
              sync();
            }),
        }),
      ),
    );
    return box;
  }

  function cameraSection(entry) {
    const camera = entry.object;
    if (!camera?.isCamera) return null;
    const { element: box, body: boxBody } = section('Camera');
    const apply = () => {
      camera.updateProjectionMatrix();
      entry.data.camera = { fov: camera.fov, near: camera.near, far: camera.far };
    };
    boxBody.appendChild(
      fieldRow('Field of view', numberInput({ value: camera.fov, min: 5, max: 140, step: 1, ...live(apply) })),
    );
    boxBody.appendChild(fieldRow('Near', numberInput({ value: camera.near, min: 0.01, step: 0.1, ...live(apply) })));
    boxBody.appendChild(fieldRow('Far', numberInput({ value: camera.far, min: 1, step: 1, ...live(apply) })));
    return box;
  }

  function particlesSection(entry) {
    const system = entry.particles;
    if (!system) return null;
    const params = system.params;
    const { element: box, body: boxBody } = section(entry.kind === 'smoke' ? 'Smoke' : 'Particles');

    const sync = () => {
      entry.data.particles = system.toJSON();
    };

    const sliders = [
      ['lifetime', 'Lifetime', 0.1, 10, 0.1],
      ['speed', 'Speed', 0, 12, 0.1],
      ['size', 'Size', 0.05, 6, 0.05],
      ['spread', 'Spread', 0, 6, 0.05],
      ['gravity', 'Gravity', -12, 4, 0.1],
      ['drift', 'Drift', 0, 3, 0.05],
      ['alpha', 'Opacity', 0.02, 1, 0.01],
    ];
    for (const [key, label, min, max, step] of sliders) {
      boxBody.appendChild(
        fieldRow(
          label,
          rangeInput({
            value: params[key],
            min,
            max,
            step,
            label,
            ...live((v) => {
              system.setParams({ [key]: v });
              sync();
            }),
          }),
        ),
      );
    }
    boxBody.appendChild(
      fieldRow(
        'Start color',
        colorInput({
          value: params.colorA,
          onInput: (v) => system.setParams({ colorA: v }),
          onCommit: (v) => {
            ctx.beginLive();
            system.setParams({ colorA: v });
            sync();
            ctx.commitLive();
          },
        }),
      ),
    );
    boxBody.appendChild(
      fieldRow(
        'End color',
        colorInput({
          value: params.colorB,
          onInput: (v) => system.setParams({ colorB: v }),
          onCommit: (v) => {
            ctx.beginLive();
            system.setParams({ colorB: v });
            sync();
            ctx.commitLive();
          },
        }),
      ),
    );
    boxBody.appendChild(
      fieldRow(
        'Additive glow',
        checkboxInput({
          checked: !!params.additive,
          onChange: (v) =>
            ctx.commands.mutate(() => {
              system.setParams({ additive: v });
              sync();
            }),
        }),
      ),
    );
    boxBody.appendChild(
      fieldRow(
        'Emitting',
        checkboxInput({
          checked: system.emitting !== false,
          onChange: (v) =>
            ctx.commands.mutate(() => {
              system.setEmitting(v);
              sync();
            }),
        }),
      ),
    );

    const burst = h('button', { class: 'btn', type: 'button', text: 'Emit burst' });
    burst.addEventListener('click', () => ctx.commands.burstParticles(entry));
    boxBody.appendChild(fieldRow('Burst', burst));

    boxBody.appendChild(
      h('p', {
        class: 'muted',
        text: `Preset “${PARTICLE_PRESETS[system.presetId] ? system.presetId : 'custom'}”, ${system.count} particles.`,
      }),
    );
    return box;
  }

  function armatureSection(entry) {
    const armature = entry.armature;
    if (!armature) return null;
    const { element: box, body: boxBody } = section('Armature');
    const angles = entry.data.armature.angles;
    const apply = () => {
      ctx.commands.applyBoneAngles(entry);
    };
    for (let bone = 0; bone < armature.boneCount; bone += 1) {
      for (let axis = 0; axis < 3; axis += 1) {
        const input = numberInput({
          value: angles[bone][axis],
          min: -180,
          max: 180,
          step: 5,
          ...live((v) => {
            angles[bone][axis] = v;
            apply();
          }),
        });
        boxBody.appendChild(fieldRow(`Bone ${bone + 1} ${AXES[axis].toUpperCase()}`, input));
      }
    }
    const reset = h('button', { class: 'btn', type: 'button', text: 'Reset pose' });
    reset.addEventListener('click', () => ctx.commands.resetPose(entry));
    boxBody.appendChild(fieldRow('Pose', reset));
    return box;
  }

  function animationSection(entry) {
    const { element: box, body: boxBody } = section('Animation');
    const info = h('p', {
      class: 'muted',
      text: entry.keys.length === 0
        ? 'No keyframes yet.'
        : `${entry.keys.length} keyframe${entry.keys.length === 1 ? '' : 's'} for this object.`,
    });
    const insert = h('button', { class: 'btn', type: 'button', text: 'Insert keyframe' });
    insert.addEventListener('click', () => ctx.commands.insertKey());
    const remove = h('button', { class: 'btn', type: 'button', text: 'Delete keyframe here' });
    remove.addEventListener('click', () => ctx.commands.deleteKey());
    boxBody.appendChild(info);
    boxBody.appendChild(h('div', { class: 'inspector__actions' }, insert, remove));
    return box;
  }

  function emptyState() {
    return h(
      'div',
      { class: 'panel__empty' },
      h('p', { text: 'Nothing is selected.' }),
      h('p', { class: 'muted', text: 'Click an object in the viewport or the outliner to edit its properties.' }),
      h(
        'button',
        { class: 'btn btn--primary', type: 'button', text: 'Add a cube', on: { click: () => ctx.commands.create('cube') } },
      ),
    );
  }

  // -------------------------------------------------------------------------
  // Render & live sync
  // -------------------------------------------------------------------------

  function syncTransform() {
    if (!transformRefs) return;
    const { object, position, rotation, scale } = transformRefs;
    if (ctx.world.selectedId !== transformRefs.entry.id) return;
    const active = document.activeElement;
    const set = (inputs, values) => {
      inputs.forEach((input, index) => {
        if (input === active) return;
        input.value = String(round(values[index], 3));
      });
    };
    set(position.inputs, [object.position.x, object.position.y, object.position.z]);
    set(rotation.inputs, [radToDeg(object.rotation.x), radToDeg(object.rotation.y), radToDeg(object.rotation.z)]);
    set(scale.inputs, [object.scale.x, object.scale.y, object.scale.z]);
  }

  function render() {
    clear(body);
    transformRefs = null;
    const entry = currentEntry();
    if (!entry) {
      body.appendChild(emptyState());
      return;
    }
    body.appendChild(headerSection(entry));
    body.appendChild(transformSection(entry));
    for (const sectionNode of [
      geometrySection(entry),
      materialSection(entry),
      lightSection(entry),
      cameraSection(entry),
      particlesSection(entry),
      armatureSection(entry),
      animationSection(entry),
    ]) {
      if (sectionNode) body.appendChild(sectionNode);
    }
  }

  function round(value, digits) {
    const factor = 10 ** digits;
    return Math.round(value * factor) / factor;
  }

  ctx.bus.on('selection.change', render);
  ctx.bus.on('world.entry', (entry) => {
    if (entry?.id === ctx.world.selectedId) render();
  });
  ctx.bus.on('world.change', (payload) => {
    if (payload?.reason === 'record' || payload?.reason === 'replace' || payload?.reason === 'clear') render();
  });
  ctx.bus.on('gizmo.change', syncTransform);
  ctx.onFrame(syncTransform);
  ctx.bus.on('timeline.keys', (payload) => {
    if (payload?.entryId === ctx.world.selectedId) render();
  });

  render();

  return { element, render, syncTransform, get selectionCount() { return selectionCount(); } };
}

function prettyLabel(key) {
  return key
    .replace(/([A-Z])/g, ' $1')
    .replace(/^./, (c) => c.toUpperCase())
    .trim();
}
