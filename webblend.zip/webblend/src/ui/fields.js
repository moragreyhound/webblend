// Reusable form controls for the Inspector and Timeline panels. Every control
// is a real labelled form element (native inputs, not div buttons) so keyboard
// and screen-reader users get platform behaviour for free.
//
// History/undo contract used by callers:
//   onStart()  - user begins an edit (pointerdown/focus): snapshot the world
//   onInput()  - live preview while the control is moving
//   onCommit() - the edit settled (change/blur): record one undo step

import { h } from './dom.js';

/** A labelled row: label on the left, control on the right. */
export function fieldRow(label, control, { hint, id } = {}) {
  return h(
    'div',
    { class: 'row' },
    h('span', { class: 'row__label', title: hint ?? label, text: label }),
    h('span', { class: 'row__control' }, control.setAttribute('aria-label', label) || control),
  );
}

function numberValue(input, fallback = 0) {
  const parsed = Number.parseFloat(input.value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

/**
 * Numeric input.
 * @param {{ value?: number, min?: number, max?: number, step?: number,
 *   onStart?: Function, onInput?: (v:number)=>void, onCommit?: (v:number)=>void,
 *   disabled?: boolean, id?: string }} opts
 */
export function numberInput(opts = {}) {
  const input = h('input', {
    class: 'input input--num',
    type: 'number',
    value: String(opts.value ?? 0),
    min: opts.min,
    max: opts.max,
    step: opts.step ?? 'any',
    disabled: opts.disabled === true,
    id: opts.id,
  });
  let dirty = false;
  const start = () => {
    if (dirty) return;
    dirty = true;
    opts.onStart?.();
  };
  input.addEventListener('focus', start);
  input.addEventListener('pointerdown', start);
  input.addEventListener('input', () => opts.onInput?.(numberValue(input, Number(input.value) || 0)));
  input.addEventListener('change', () => {
    opts.onCommit?.(numberValue(input, Number(input.value) || 0));
    dirty = false;
  });
  input.addEventListener('blur', () => {
    dirty = false;
  });
  input.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') input.blur();
  });
  return input;
}

/** Range slider with a live numeric readout. */
export function rangeInput(opts = {}) {
  const readout = h('output', { class: 'range__value', text: format(opts.value) });
  const input = h('input', {
    class: 'range',
    type: 'range',
    value: String(opts.value ?? 0),
    min: opts.min ?? 0,
    max: opts.max ?? 1,
    step: opts.step ?? 0.01,
    disabled: opts.disabled === true,
  });
  let dirty = false;
  const start = () => {
    if (dirty) return;
    dirty = true;
    opts.onStart?.();
  };
  input.addEventListener('pointerdown', start);
  input.addEventListener('focus', start);
  input.addEventListener('input', () => {
    const v = numberValue(input, 0);
    readout.textContent = format(v, opts.digits);
    opts.onInput?.(v);
  });
  input.addEventListener('change', () => {
    opts.onCommit?.(numberValue(input, 0));
    dirty = false;
  });
  input.addEventListener('blur', () => {
    dirty = false;
  });
  input.setAttribute('aria-label', opts.label ?? 'value');
  return h('div', { class: 'range-wrap' }, input, readout);
}

function format(value, digits = 2) {
  const n = Number(value);
  if (!Number.isFinite(n)) return String(value);
  return String(Number(n.toFixed(digits)));
}

/** Color swatch input bound to a hex string. */
export function colorInput(opts = {}) {
  const input = h('input', {
    class: 'color',
    type: 'color',
    value: normalizeHex(opts.value) ?? '#808080',
    disabled: opts.disabled === true,
  });
  input.addEventListener('input', () => opts.onInput?.(input.value));
  input.addEventListener('change', () => opts.onCommit?.(input.value));
  return input;
}

function normalizeHex(value) {
  if (typeof value !== 'string') return null;
  if (/^#[0-9a-f]{6}$/i.test(value)) return value.toLowerCase();
  if (/^#[0-9a-f]{3}$/i.test(value)) {
    const [, r, g, b] = value;
    return `#${r}${r}${g}${g}${b}${b}`.toLowerCase();
  }
  return null;
}

/** Checkbox with an optional inline label. */
export function checkboxInput(opts = {}) {
  const input = h('input', {
    class: 'checkbox',
    type: 'checkbox',
    checked: opts.checked === true,
    disabled: opts.disabled === true,
  });
  input.addEventListener('change', () => opts.onChange?.(input.checked));
  return input;
}

/**
 * Select.
 * @param {{ value?: string, options: Array<string|{value:string,label:string}>,
 *   onChange?: (v:string)=>void, disabled?: boolean, numeric?: boolean }} opts
 */
export function selectInput(opts = {}) {
  const select = h('select', { class: 'select', disabled: opts.disabled === true });
  for (const option of opts.options) {
    const value = typeof option === 'string' ? option : option.value;
    const label = typeof option === 'string' ? option : option.label;
    select.appendChild(h('option', { value, text: label, selected: String(value) === String(opts.value) }));
  }
  select.addEventListener('change', () => opts.onChange?.(select.value));
  return select;
}

/** Three number inputs labelled X / Y / Z. */
export function vec3Input(opts = {}) {
  const axes = ['X', 'Y', 'Z'];
  const inputs = axes.map((axis, index) =>
    numberInput({
      value: opts.values?.[index] ?? 0,
      step: opts.step ?? 0.1,
      onStart: opts.onStart,
      onInput: (v) => opts.onInput?.(index, v),
      onCommit: (v) => opts.onCommit?.(index, v),
    }),
  );
  const element = h(
    'div',
    { class: 'vec' },
    inputs.map((input, index) =>
      h('label', { class: 'vec__item' }, h('span', { class: 'vec__axis', text: axes[index] }), input),
    ),
  );
  return { element, inputs };
}

/** A collapsible section with a heading, for the Inspector. */
export function section(title, { open = true } = {}) {
  const body = h('div', { class: 'section__body' });
  const toggle = h('button', {
    class: 'section__toggle',
    type: 'button',
    'aria-expanded': String(open),
    text: title,
  });
  const element = h('section', { class: 'section' }, toggle, body);
  if (!open) element.classList.add('section--closed');
  toggle.addEventListener('click', () => {
    const isOpen = toggle.getAttribute('aria-expanded') === 'true';
    toggle.setAttribute('aria-expanded', String(!isOpen));
    element.classList.toggle('section--closed', isOpen);
  });
  return { element, body };
}
