// A compact view cube for snapping the camera to axis-aligned views. It is
// DOM-based rather than a second WebGL scene: cheap, keyboard accessible, and
// trivially styled with design tokens.

import { h } from './dom.js';

const FACES = [
  { view: 'top', label: 'Top', short: 'T' },
  { view: 'front', label: 'Front', short: 'F' },
  { view: 'right', label: 'Right', short: 'R' },
  { view: 'back', label: 'Back', short: 'B' },
  { view: 'left', label: 'Left', short: 'L' },
  { view: 'bottom', label: 'Bottom', short: 'Btm' },
];

/**
 * @param {{ onSelect: (view: string) => void, onHome: () => void }} options
 * @returns {HTMLElement}
 */
export function createNavCube({ onSelect, onHome }) {
  const grid = h('div', { class: 'navcube__grid', role: 'group', 'aria-label': 'View cube' });

  const layout = [
    null,
    'top',
    null,
    'left',
    'front',
    'right',
    null,
    'bottom',
    null,
  ];

  const byView = new Map(FACES.map((face) => [face.view, face]));

  for (const view of layout) {
    if (!view) {
      grid.appendChild(h('div', { class: 'navcube__spacer', 'aria-hidden': 'true' }));
      continue;
    }
    const face = byView.get(view);
    const button = h('button', {
      class: `navcube__face navcube__face--${view}`,
      type: 'button',
      title: `${face.label} view`,
      'aria-label': `${face.label} view`,
      text: face.short,
    });
    button.addEventListener('click', () => onSelect(view));
    grid.appendChild(button);
  }

  const home = h('button', {
    class: 'navcube__home',
    type: 'button',
    title: 'Perspective view',
    'aria-label': 'Perspective view',
    text: 'Home',
  });
  home.addEventListener('click', () => onHome());

  const element = h(
    'div',
    { class: 'navcube', role: 'toolbar', 'aria-label': 'Camera views' },
    grid,
    home,
  );

  return element;
}
