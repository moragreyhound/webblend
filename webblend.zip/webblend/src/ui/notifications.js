// Transient notifications (toasts).
//
// Rules honoured here (AGENTS.md 5.7 / 5.6):
//  - Toasts are announced through a live region that exists before content is
//    injected; errors use role="alert", everything else role="status".
//  - They are never the sole carrier of critical information: callers also show
//    persistent inline state where it matters.
//  - Timeouts pause on hover/focus, errors persist until dismissed, and the
//    stack is capped so the screen can never be buried.

import { h, on } from './dom.js';
import { icon } from './icons.js';

const DEFAULT_TIMEOUT = 5000;
const MAX_VISIBLE = 4;

const TYPE_META = {
  info: { symbol: 'info', role: 'status' },
  success: { symbol: 'check_circle', role: 'status' },
  warning: { symbol: 'warning', role: 'status' },
  error: { symbol: 'error', role: 'alert' },
};

export class Notifier {
  /** @param {HTMLElement} [container] defaults to a fixed overlay on <body>. */
  constructor(container) {
    this.container = container ?? h('div', {
      class: 'toasts',
      role: 'status',
      'aria-live': 'polite',
      'aria-relevant': 'additions',
    });
    if (!container) document.body.appendChild(this.container);
  }

  /**
   * Show a toast.
   * @param {string} message
   * @param {{ type?: 'info'|'success'|'warning'|'error', timeout?: number,
   *   action?: { label: string, onSelect: Function }, dismissible?: boolean }} [options]
   * @returns {() => void} dismiss function
   */
  show(message, { type = 'info', timeout, action, dismissible = true } = {}) {
    const meta = TYPE_META[type] ?? TYPE_META.info;
    const isError = type === 'error';
    const lifetime = timeout ?? (isError ? 0 : DEFAULT_TIMEOUT);

    const toast = h('div', { class: `toast toast--${type}`, role: meta.role });
    toast.appendChild(icon(meta.symbol, { size: 18, className: 'toast__icon' }));
    const text = h('span', { class: 'toast__text', text: message });
    toast.appendChild(text);

    let removed = false;
    const remove = () => {
      if (removed) return;
      removed = true;
      toast.remove();
    };

    if (action) {
      const actionButton = h('button', { class: 'toast__action', type: 'button', text: action.label });
      actionButton.addEventListener('click', () => {
        action.onSelect?.();
        remove();
      });
      toast.appendChild(actionButton);
    }

    if (dismissible) {
      const close = h('button', {
        class: 'toast__close',
        type: 'button',
        'aria-label': 'Dismiss notification',
      });
      close.appendChild(icon('close', { size: 16 }));
      close.addEventListener('click', remove);
      toast.appendChild(close);
    }

    // Cap the stack: evict the oldest non-error toast first.
    while (this.container.children.length >= MAX_VISIBLE) {
      const children = Array.from(this.container.children);
      const victim = children.find((c) => !c.classList.contains('toast--error')) ?? children[0];
      victim?.remove();
    }

    this.container.appendChild(toast);

    if (lifetime > 0 && typeof window !== 'undefined') {
      let timer = window.setTimeout(remove, lifetime);
      const pause = () => window.clearTimeout(timer);
      const resume = () => {
        pause();
        timer = window.setTimeout(remove, 1500);
      };
      on(toast, 'pointerenter', pause);
      on(toast, 'pointerleave', resume);
      on(toast, 'focusin', pause);
      on(toast, 'focusout', resume);
    }

    return remove;
  }

  info(message, options) {
    return this.show(message, { ...options, type: 'info' });
  }

  success(message, options) {
    return this.show(message, { ...options, type: 'success' });
  }

  warning(message, options) {
    return this.show(message, { ...options, type: 'warning' });
  }

  error(message, options) {
    return this.show(message, { ...options, type: 'error' });
  }

  clear() {
    while (this.container.firstChild) this.container.removeChild(this.container.firstChild);
  }
}
