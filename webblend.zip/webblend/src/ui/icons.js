// Iconography: Google Material Symbols referenced by URL as <img>, per the
// project brief ("use Google free icons referenced as <img src=public URL>").
//
// The CSP only permits images from 'self', data:, blob: and fonts.gstatic.com,
// so the Google Fonts static host is the image source. When an icon cannot be
// fetched (offline, blocked, renamed upstream) we swap in a small inline SVG so
// the control never becomes an empty box. Buttons always carry an accessible
// name, so the fallback glyph is decorative only.

const SYMBOLS_BASE = 'https://fonts.gstatic.com/s/i/short-term/release/materialsymbolsoutlined';

/** Public URL for a Material Symbol name (no fetch happens here). */
export function materialIconUrl(name) {
  return `${SYMBOLS_BASE}/${encodeURIComponent(name)}/default/24px.svg`;
}

// Compact inline fallbacks. Not pixel-accurate Material glyphs - they exist to
// keep the UI legible when the network is unavailable. Keyed by symbol name.
const FALLBACK_PATHS = {
  play: 'M8 5v14l11-7z',
  pause: 'M6 5h4v14H6zM14 5h4v14h-4z',
  skip_previous: 'M6 6h2v12H6zM18 6v12l-9-6z',
  skip_next: 'M16 6h2v12h-2zM6 6l9 6-9 6z',
  navigate_before: 'M15 6l-6 6 6 6',
  navigate_next: 'M9 6l6 6-6 6',
  undo: 'M9 7H5v-4M5 7a8 8 0 1 1-1 6',
  redo: 'M15 7h4v-4M19 7a8 8 0 1 0 1 6',
  delete: 'M6 7h12M9 7V5h6v2M8 7l1 13h6l1-13',
  content_copy: 'M9 9h10v11H9zM5 4h10v3M5 4v11h3',
  add: 'M12 5v14M5 12h14',
  close: 'M6 6l12 12M18 6L6 18',
  visibility: 'M2 12s4-6 10-6 10 6 10 6-4 6-10 6-10-6-10-6zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z',
  visibility_off: 'M4 4l16 16M10 5a10 10 0 0 1 10 7 12 12 0 0 1-3 3M4 12s2-3 5-4',
  check: 'M5 13l4 4L19 7',
  warning: 'M12 4l9 16H3zM12 10v4M12 17h.01',
  info: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 11v6M12 8h.01',
  error: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM8 8l8 8M16 8l-8 8',
  lightbulb: 'M9 18h6M10 21h4M12 3a6 6 0 0 0-4 10c1 1 1 2 1 3h6c0-1 0-2 1-3a6 6 0 0 0-4-10z',
  wb_sunny: 'M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10zM12 2v2M12 20v2M2 12h2M20 12h2M5 5l1 1M18 18l1 1M19 5l-1 1M6 18l-1 1',
  open_with: 'M12 3v18M3 12h18M9 6l3-3 3 3M9 18l3 3 3-3M6 9l-3 3 3 3M18 9l3 3-3 3',
  rotate_right: 'M20 12a8 8 0 1 1-3-6M20 4v5h-5',
  settings: 'M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM4 12l-2-1 2-4 2 1 2-1 1-2h6l1 2 2 1 2-1 2 4-2 1v2l2 1-2 4-2-1-2 1-1 2H8l-1-2-2-1-2 1-2-4 2-1z',
  help: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM9 9a3 3 0 1 1 4 3c0 1-1 1-1 2M12 17h.01',
  folder_open: 'M3 6h6l2 2h10v10H3z',
  save: 'M5 4h11l3 3v13H5zM8 4v6h7V4M8 20v-6h8v6',
  upload: 'M12 20V8M7 13l5-5 5 5M5 4h14',
  download: 'M12 4v12M7 11l5 5 5-5M5 20h14',
  cloud: 'M7 18a4 4 0 0 1 0-8 5 5 0 0 1 9-2 4 4 0 0 1 1 8z',
  deployed_code: 'M12 3l8 4.5v9L12 21l-8-4.5v-9zM12 3v18M4 7.5l8 4.5 8-4.5',
  auto_awesome: 'M12 3l1.8 4.8L18.6 9.6 13.8 11.4 12 16.2 10.2 11.4 5.4 9.6 10.2 7.8z',
  accessibility_new: 'M12 4a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM6 9h12M12 9v5M12 14l-3 7M12 14l3 7',
  videocam: 'M3 7h11v10H3zM14 10l7-3v10l-7-3',
  grid_on: 'M4 4h16v16H4zM4 10h16M4 15h16M10 4v16M15 4v16',
  timeline: 'M4 12h4l2-5 3 10 2-5h5',
  layers: 'M12 3l9 5-9 5-9-5zM3 13l9 5 9-5',
  frame_inspect: 'M4 8V4h4M20 8V4h-4M4 16v4h4M20 16v4h-4',
  add_box: 'M4 4h16v16H4zM12 9v6M9 12h6',
  content_cut: 'M6 4l12 16M6 20L18 4M9 8a2 2 0 1 1-3-3 2 2 0 0 1 3 3zM18 3a2 2 0 1 1-3 3 2 2 0 0 1 3-3z',
};

const DEFAULT_PATH = 'M4 4h16v16H4z';

function svgFallback(name, size) {
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('width', String(size));
  svg.setAttribute('height', String(size));
  svg.setAttribute('fill', 'none');
  svg.setAttribute('stroke', 'currentColor');
  svg.setAttribute('stroke-width', '1.8');
  svg.setAttribute('stroke-linecap', 'round');
  svg.setAttribute('stroke-linejoin', 'round');
  svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('class', 'icon icon--svg');
  const path = document.createElementNS(ns, 'path');
  path.setAttribute('d', FALLBACK_PATHS[name] ?? DEFAULT_PATH);
  svg.appendChild(path);
  return svg;
}

/**
 * Build an icon element.
 * @param {string} name Material Symbol name (e.g. 'play_arrow')
 * @param {{ size?: number, label?: string, className?: string }} [options]
 *   `label` gives the icon an accessible name; omit it for decorative icons.
 */
export function icon(name, { size = 18, label, className = '' } = {}) {
  const img = document.createElement('img');
  img.className = `icon ${className}`.trim();
  img.src = materialIconUrl(name);
  img.width = size;
  img.height = size;
  img.decoding = 'async';
  img.loading = 'lazy';
  img.draggable = false;
  img.alt = label ?? '';
  if (!label) img.setAttribute('aria-hidden', 'true');
  img.addEventListener(
    'error',
    () => {
      const fallback = svgFallback(name, size);
      img.replaceWith(fallback);
    },
    { once: true },
  );
  return img;
}

export const FALLBACK_ICON_NAMES = Object.freeze(Object.keys(FALLBACK_PATHS));
