// Global keyboard shortcut dispatch and the binding table used by the help
// overlay. Bindings are declarative so the help text can never drift from the
// real keymap.

import { isTypingTarget } from './dom.js';

const MODIFIERS = ['ctrl', 'shift', 'alt'];

/** Parse "Ctrl+Shift+Z" into a matcher descriptor. */
export function parseCombo(combo) {
  const tokens = String(combo).split('+').map((t) => t.trim()).filter(Boolean);
  const descriptor = { ctrl: false, shift: false, alt: false, key: '' };
  for (const token of tokens) {
    const lower = token.toLowerCase();
    if (MODIFIERS.includes(lower)) descriptor[lower] = true;
    else descriptor.key = lower;
  }
  return descriptor;
}

function keyMatches(token, event) {
  const key = (event.key ?? '').toLowerCase();
  const code = (event.code ?? '').toLowerCase();
  switch (token) {
    case 'space':
      return key === ' ' || code === 'space';
    case 'esc':
    case 'escape':
      return key === 'escape';
    case 'del':
    case 'delete':
      return key === 'delete';
    case 'enter':
    case 'return':
      return key === 'enter';
    case 'backspace':
      return key === 'backspace';
    case 'tab':
      return key === 'tab';
    case 'home':
    case 'end':
    case 'pageup':
    case 'pagedown':
      return key === token;
    default:
      if (token.startsWith('arrow')) return key === token;
      if (token.startsWith('numpad')) return code === token;
      if (token.startsWith('digit')) return code === token;
      if (/^f\d{1,2}$/.test(token)) return key === token;
      return key === token;
  }
}

/**
 * @typedef {Object} Binding
 * @property {string} keys         Combo string, e.g. 'Ctrl+Z' or 'G'
 * @property {string} label        Human description for the help overlay
 * @property {string} [group]      Grouping for the help overlay
 * @property {() => boolean} [when] Optional predicate; binding is skipped when false
 * @property {(event: KeyboardEvent) => void} run
 */

export class Shortcuts {
  constructor() {
    /** @type {Binding[]} */
    this.bindings = [];
    this.enabled = true;
    this.target = null;
    this.onKeyDown = this.#handle.bind(this);
  }

  /** Register one binding. Returns this for chaining. */
  add(binding) {
    this.bindings.push({ group: 'General', ...binding });
    return this;
  }

  /** Register many bindings. */
  addAll(bindings) {
    for (const binding of bindings) this.add(binding);
    return this;
  }

  attach(target = window) {
    this.detach();
    this.target = target;
    target.addEventListener('keydown', this.onKeyDown);
    return this;
  }

  detach() {
    this.target?.removeEventListener('keydown', this.onKeyDown);
    this.target = null;
  }

  /** Bindings grouped for display, in registration order. */
  grouped() {
    const groups = new Map();
    for (const binding of this.bindings) {
      const list = groups.get(binding.group) ?? [];
      list.push(binding);
      groups.set(binding.group, list);
    }
    return Array.from(groups, ([group, list]) => ({ group, list }));
  }

  /** Display string for a binding, made platform-friendly (⌘ on macOS). */
  static display(keys) {
    const isMac = typeof navigator !== 'undefined' && /Mac|iPhone|iPad/.test(navigator.platform || '');
    if (!isMac) return keys;
    return keys.replace(/Ctrl/g, '⌘').replace(/Shift/g, '⇧').replace(/Alt/g, '⌥');
  }

  #handle(event) {
    if (!this.enabled) return;
    if (event.repeat && !event.ctrlKey && !event.metaKey) {
      // Allow held movement keys but ignore repeated command triggers.
    }
    for (const binding of this.bindings) {
      if (binding.when && !binding.when()) continue;
      if (!this.#matches(binding, event)) continue;
      if (isTypingTarget(event.target) && !binding.allowInInput) continue;
      event.preventDefault();
      try {
        binding.run(event);
      } catch (error) {
        console.error(`[shortcuts] "${binding.keys}" handler failed`, error);
      }
      return;
    }
  }

  #matches(binding, event) {
    const descriptor = parseCombo(binding.keys);
    const ctrl = event.ctrlKey || event.metaKey;
    if (descriptor.ctrl !== ctrl) return false;
    if (descriptor.shift !== event.shiftKey) return false;
    if (descriptor.alt !== event.altKey) return false;
    return keyMatches(descriptor.key, event);
  }
}
