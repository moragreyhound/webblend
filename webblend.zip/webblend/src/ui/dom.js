// Small DOM toolkit: an element factory, menu/dialog primitives, and helpers.
//
// Constraints this file respects:
//  - The server sets `style-src 'self'` (no 'unsafe-inline'), so nothing here
//    writes a `style` attribute or uses innerHTML. Dynamic styles go through
//    CSSOM (`element.style.setProperty`), which CSP does not restrict.
//  - Dialogs use the native <dialog> element so focus trapping, Esc handling and
//    focus restoration come from the platform rather than hand-rolled JS.

const KEBAB = /[A-Z]/g;

/** camelCase -> kebab-case for CSS property names. */
function cssName(key) {
  return key.startsWith('--') ? key : key.replace(KEBAB, (c) => `-${c.toLowerCase()}`);
}

function appendChild(node, child) {
  if (child === null || child === undefined || child === false || child === true) return;
  if (Array.isArray(child)) {
    for (const item of child) appendChild(node, item);
    return;
  }
  if (child instanceof Node) {
    node.appendChild(child);
    return;
  }
  node.appendChild(document.createTextNode(String(child)));
}

/**
 * Element factory.
 * `props` supports: class, text, dataset, style (object), on (event map),
 * ref (callback), and any attribute (aria-*, title, type, ...). Boolean false
 * omits the attribute; boolean true sets an empty attribute.
 *
 * @param {string} tag
 * @param {Record<string, unknown>} [props]
 * @param {...unknown} children
 * @returns {HTMLElement}
 */
export function h(tag, props = {}, ...children) {
  const element = document.createElement(tag);
  for (const [key, value] of Object.entries(props ?? {})) {
    if (value === null || value === undefined) continue;
    if (key === 'class' || key === 'className') {
      element.className = String(value);
    } else if (key === 'text') {
      element.textContent = String(value);
    } else if (key === 'style' && typeof value === 'object') {
      for (const [prop, val] of Object.entries(value)) {
        if (val === null || val === undefined) continue;
        element.style.setProperty(cssName(prop), String(val));
      }
    } else if (key === 'dataset' && typeof value === 'object') {
      for (const [dataKey, val] of Object.entries(value)) element.dataset[dataKey] = String(val);
    } else if (key === 'on' && typeof value === 'object') {
      for (const [type, handler] of Object.entries(value)) element.addEventListener(type, handler);
    } else if (key === 'ref' && typeof value === 'function') {
      value(element);
    } else if (value === false) {
      // omitted
    } else if (value === true) {
      element.setAttribute(key, '');
    } else {
      element.setAttribute(key, String(value));
    }
  }
  for (const child of children) appendChild(element, child);
  return element;
}

/** Remove every child of `node`. */
export function clear(node) {
  while (node.firstChild) node.removeChild(node.firstChild);
}

export function qs(selector, root = document) {
  return root.querySelector(selector);
}

export function qsa(selector, root = document) {
  return Array.from(root.querySelectorAll(selector));
}

/** addEventListener with a disposer; returns the disposer. */
export function on(target, type, handler, options) {
  target.addEventListener(type, handler, options);
  return () => target.removeEventListener(type, handler, options);
}

/** True when the event target is a text entry surface. */
export function isTypingTarget(target) {
  if (!target || !target.tagName) return false;
  const tag = target.tagName;
  return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || target.isContentEditable === true;
}

// ---------------------------------------------------------------------------
// Menus
// ---------------------------------------------------------------------------

/**
 * Build a dropdown menu.
 * @param {Array<{label?:string, icon?:Node, shortcut?:string, onSelect?:Function,
 *   checked?:boolean, disabled?:boolean, separator?:boolean}>} items
 * @returns {{ element: HTMLElement, open: Function, close: Function, toggle: Function,
 *   contains: (node: Node) => boolean, isOpen: () => boolean }}
 */
export function createMenu(items) {
  const element = h('div', { class: 'menu', role: 'menu', hidden: true });
  let open = false;
  let anchorEl = null;

  function menuItems() {
    return qsa('[role="menuitem"]', element);
  }

  function focusAt(index) {
    const list = menuItems().filter((el) => !el.disabled);
    if (list.length === 0) return;
    const wrapped = ((index % list.length) + list.length) % list.length;
    list[wrapped].focus();
  }

  for (const item of items) {
    if (item.separator) {
      element.appendChild(h('div', { class: 'menu__sep', role: 'separator' }));
      continue;
    }
    const button = h(
      'button',
      {
        class: 'menu__item',
        type: 'button',
        role: 'menuitem',
        disabled: item.disabled === true,
        'aria-checked': item.checked === undefined ? null : String(item.checked),
      },
      h('span', { class: 'menu__icon', 'aria-hidden': 'true' }, item.icon ?? null),
      h('span', { class: 'menu__label', text: item.label ?? '' }),
      item.shortcut ? h('span', { class: 'menu__shortcut', text: item.shortcut }) : null,
    );
    if (item.checked !== undefined) button.setAttribute('aria-pressed', String(item.checked));
    button.addEventListener('click', () => {
      close();
      item.onSelect?.();
    });
    element.appendChild(button);
  }

  function position() {
    if (!anchorEl) return;
    const rect = anchorEl.getBoundingClientRect();
    const menuRect = element.getBoundingClientRect();
    const margin = 6;
    let left = rect.left;
    let top = rect.bottom + margin;
    if (left + menuRect.width > window.innerWidth - margin) {
      left = Math.max(margin, window.innerWidth - menuRect.width - margin);
    }
    if (top + menuRect.height > window.innerHeight - margin) {
      top = Math.max(margin, rect.top - menuRect.height - margin);
    }
    element.style.setProperty('left', `${Math.round(left)}px`);
    element.style.setProperty('top', `${Math.round(top)}px`);
  }

  function handleDocumentPointer(event) {
    if (element.contains(event.target)) return;
    if (anchorEl && anchorEl.contains(event.target)) return;
    close();
  }

  function handleKey(event) {
    if (event.key === 'Escape') {
      event.preventDefault();
      close();
      anchorEl?.focus();
      return;
    }
    if (event.key === 'ArrowDown') {
      event.preventDefault();
      focusAt(currentIndex() + 1);
    } else if (event.key === 'ArrowUp') {
      event.preventDefault();
      focusAt(currentIndex() - 1);
    } else if (event.key === 'Home') {
      event.preventDefault();
      focusAt(0);
    } else if (event.key === 'End') {
      event.preventDefault();
      focusAt(menuItems().length - 1);
    }
  }

  function currentIndex() {
    return menuItems().indexOf(document.activeElement);
  }

  function open1(anchor) {
    if (open) {
      close();
      return;
    }
    anchorEl = anchor ?? null;
    element.hidden = false;
    open = true;
    anchorEl?.setAttribute('aria-expanded', 'true');
    position();
    document.addEventListener('pointerdown', handleDocumentPointer, true);
    element.addEventListener('keydown', handleKey);
    focusAt(0);
  }

  function close() {
    if (!open) return;
    open = false;
    element.hidden = true;
    anchorEl?.setAttribute('aria-expanded', 'false');
    document.removeEventListener('pointerdown', handleDocumentPointer, true);
    element.removeEventListener('keydown', handleKey);
    anchorEl = null;
  }

  document.body.appendChild(element);

  return {
    element,
    open: open1,
    close,
    toggle: (anchor) => (open ? close() : open1(anchor)),
    contains: (node) => element.contains(node),
    isOpen: () => open,
  };
}

// ---------------------------------------------------------------------------
// Dialogs (native <dialog>)
// ---------------------------------------------------------------------------

/**
 * Open a modal dialog. Returns a controller with `close(result)`.
 * @param {{ title?: string, body: Node|Node[], actions?: Array<{label:string,
 *   value?:unknown, variant?:string, autofocus?:boolean}>, onOpen?: Function }} config
 */
export function openDialog({ title, body, actions = [], onOpen } = {}) {
  const dialog = h('dialog', { class: 'dialog' });
  const form = h('form', { class: 'dialog__form', method: 'dialog' });
  let resolved;

  const finish = (value) => {
    if (!dialog.open) return;
    resolved = value;
    dialog.close();
  };

  if (title) form.appendChild(h('h2', { class: 'dialog__title', text: title }));
  const bodyNode = h('div', { class: 'dialog__body' });
  appendChild(bodyNode, body ?? null);
  form.appendChild(bodyNode);

  const footer = h('div', { class: 'dialog__actions' });
  for (const action of actions) {
    const button = h('button', {
      class: `btn${action.variant ? ` btn--${action.variant}` : ''}`,
      type: 'button',
      text: action.label,
    });
    button.addEventListener('click', () => finish(action.value));
    if (action.autofocus) queueMicrotask(() => button.focus());
    footer.appendChild(button);
  }
  if (actions.length > 0) form.appendChild(footer);
  dialog.appendChild(form);
  document.body.appendChild(dialog);

  dialog.addEventListener('close', () => {
    const result = resolved;
    dialog.remove();
    Promise.resolve(result);
  });
  // Click on the backdrop (outside the form) cancels.
  dialog.addEventListener('pointerdown', (event) => {
    if (event.target === dialog) finish(undefined);
  });

  dialog.showModal();
  onOpen?.(dialog, bodyNode);
  return {
    dialog,
    body: bodyNode,
    close: () => finish(undefined),
    finish,
    /** Resolves with the chosen action value once closed. */
    result: new Promise((resolve) => dialog.addEventListener('close', () => resolve(resolved))),
  };
}

/** Confirmation dialog. Resolves true when the user confirms. */
export function confirmDialog({
  title = 'Are you sure?',
  message = '',
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  danger = false,
} = {}) {
  const controller = openDialog({
    title,
    body: h('p', { class: 'dialog__message', text: message }),
    actions: [
      { label: cancelLabel, value: false },
      { label: confirmLabel, value: true, variant: danger ? 'danger' : 'primary', autofocus: true },
    ],
  });
  return controller.result.then((value) => value === true);
}

/** Prompt dialog with a single text field. Resolves the string, or null. */
export function promptDialog({ title = 'Rename', label = 'Name', value = '' } = {}) {
  const input = h('input', { class: 'input', type: 'text', value, 'aria-label': label });
  const controller = openDialog({
    title,
    body: h('label', { class: 'field' }, h('span', { class: 'field__label', text: label }), input),
    actions: [
      { label: 'Cancel', value: null },
      { label: 'Rename', value: '__ok__', variant: 'primary', autofocus: true },
    ],
    onOpen: () => input.select(),
  });
  return controller.result.then((result) => (result === '__ok__' ? input.value : null));
}

/** Replace a `{{CSP_NONCE}}` occurrence helper is server-side; nothing to do here. */
export const __internal = { cssName };
