// Timeline panel: transport controls, frame/fps settings, a scrubbable ruler and
// per-object keyframe tracks.
//
// The frame update path is deliberately split: `render()` rebuilds the (rarely
// changing) track structure, while `syncFrame()` only moves the playhead and
// updates the readout. Playback therefore never thrashes the DOM.

import { h, clear } from './dom.js';
import { icon } from './icons.js';
import { checkboxInput, numberInput, selectInput } from './fields.js';

export function createTimelinePanel(ctx) {
  const transport = h('div', { class: 'tl__transport' });
  const counter = h('input', {
    class: 'input input--tc',
    type: 'number',
    min: 1,
    step: 1,
    'aria-label': 'Current frame',
  });
  const total = h('span', { class: 'tl__total', text: '/ 120' });
  const tracks = h('div', { class: 'tl__tracks' });
  const ruler = h('div', {
    class: 'tl__ruler',
    role: 'slider',
    tabindex: 0,
    'aria-label': 'Timeline scrubber',
    'aria-valuemin': 1,
  });
  const playhead = h('div', { class: 'tl__playhead', 'aria-hidden': 'true' });
  const surface = h('div', { class: 'tl__surface' }, ruler, tracks, playhead);
  const empty = h('p', { class: 'tl__empty', text: 'No animated objects yet. Select an object and press K to key its transform.' });

  const loopBox = checkboxInput({ checked: ctx.timeline.loop, onChange: (v) => ctx.commands.setLoop(v) });
  const autoKeyBox = checkboxInput({ checked: ctx.timeline.autoKey, onChange: (v) => ctx.commands.setAutoKey(v) });

  const element = h(
    'section',
    { class: 'panel panel--timeline', 'aria-label': 'Timeline' },
    transport,
    surface,
    empty,
  );

  let playButton = null;

  function iconButton(iconName, label, onClick, extraClass = '') {
    const button = h('button', {
      class: `iconbtn ${extraClass}`.trim(),
      type: 'button',
      'aria-label': label,
      title: label,
    });
    button.appendChild(icon(iconName, { size: 16 }));
    button.addEventListener('click', onClick);
    return button;
  }

  function buildTransport() {
    clear(transport);
    playButton = iconButton(
      ctx.timeline.playing ? 'pause' : 'play_arrow',
      ctx.timeline.playing ? 'Pause (Space)' : 'Play (Space)',
      () => ctx.commands.togglePlay(),
      'iconbtn--primary',
    );
    transport.appendChild(iconButton('skip_previous', 'Jump to start (Home)', () => ctx.commands.setFrame(1)));
    transport.appendChild(iconButton('navigate_before', 'Previous frame (Left)', () => ctx.commands.stepFrame(-1)));
    transport.appendChild(playButton);
    transport.appendChild(iconButton('navigate_next', 'Next frame (Right)', () => ctx.commands.stepFrame(1)));
    transport.appendChild(iconButton('skip_next', 'Jump to end (End)', () => ctx.commands.setFrame(ctx.timeline.endFrame)));

    transport.appendChild(h('div', { class: 'tl__counter' }, counter, total));

    const keyButton = iconButton('add_box', 'Insert keyframe (K)', () => ctx.commands.insertKey(), 'iconbtn--key');
    transport.appendChild(keyButton);
    transport.appendChild(iconButton('delete', 'Delete keyframe at playhead', () => ctx.commands.deleteKey()));

    transport.appendChild(h('span', { class: 'spacer' }));

    const fps = selectInput({
      value: String(ctx.timeline.fps),
      options: ['12', '24', '30', '60'],
      onChange: (v) => ctx.commands.setFps(Number(v)),
    });
    transport.appendChild(h('label', { class: 'chk' }, h('span', { text: 'FPS' }), fps));

    const endInput = numberInput({
      value: ctx.timeline.endFrame,
      min: 2,
      max: 2000,
      step: 1,
      onCommit: (v) => ctx.commands.setEndFrame(v),
    });
    endInput.classList.add('input--short');
    transport.appendChild(h('label', { class: 'chk' }, h('span', { text: 'Frames' }), endInput));

    transport.appendChild(h('label', { class: 'chk' }, loopBox, h('span', { text: 'Loop' })));
    transport.appendChild(h('label', { class: 'chk' }, autoKeyBox, h('span', { text: 'Auto-key' })));
  }

  function niceStep(endFrame) {
    const candidates = [1, 2, 5, 10, 20, 25, 50, 100, 200, 500];
    const target = endFrame / 10;
    for (const step of candidates) if (step >= target) return step;
    return 1000;
  }

  function frameToPercent(frame) {
    const span = Math.max(1, ctx.timeline.endFrame - 1);
    return ((frame - 1) / span) * 100;
  }

  function frameFromClientX(clientX) {
    const rect = surface.getBoundingClientRect();
    if (rect.width <= 0) return 1;
    const ratio = Math.min(1, Math.max(0, (clientX - rect.left) / rect.width));
    return Math.round(1 + ratio * (ctx.timeline.endFrame - 1));
  }

  function buildTracks() {
    clear(tracks);
    clear(ruler);
    const keyed = ctx.timeline.keyedEntries(ctx.world.entries);
    surface.classList.toggle('is-empty', keyed.length === 0);
    empty.hidden = keyed.length > 0;
    if (keyed.length === 0) return;

    // Ruler ticks
    const step = niceStep(ctx.timeline.endFrame);
    const ticks = h('div', { class: 'tl__ticks', 'aria-hidden': 'true' });
    for (let frame = 1; frame <= ctx.timeline.endFrame; frame += step) {
      const tick = h('span', { class: 'tl__tick', text: String(frame) });
      tick.style.setProperty('left', `${frameToPercent(frame)}%`);
      ticks.appendChild(tick);
    }
    ruler.appendChild(ticks);

    for (const entry of keyed) {
      const keys = h('div', { class: 'tl__keys' });
      for (const key of entry.keys) {
        const diamond = h('button', {
          class: `tl__key${Math.round(key.f) === ctx.timeline.frame ? ' is-current' : ''}`,
          type: 'button',
          title: `${entry.name} - frame ${key.f}`,
          'aria-label': `${entry.name} keyframe at frame ${key.f}`,
        });
        diamond.style.setProperty('left', `${frameToPercent(key.f)}%`);
        diamond.addEventListener('click', (event) => {
          event.stopPropagation();
          ctx.commands.setFrame(key.f);
        });
        keys.appendChild(diamond);
      }
      const isSelected = ctx.world.selectedId === entry.id;
      const track = h(
        'div',
        { class: `tl__track${isSelected ? ' is-selected' : ''}` },
        h('button', {
          class: 'tl__track-name',
          type: 'button',
          text: entry.name,
          on: { click: () => ctx.world.select(entry.id) },
        }),
        keys,
      );
      tracks.appendChild(track);
    }
  }

  function syncFrame() {
    const { frame, endFrame, playing } = ctx.timeline;
    playhead.style.setProperty('left', `${frameToPercent(frame)}%`);
    if (document.activeElement !== counter) counter.value = String(frame);
    total.textContent = `/ ${endFrame}`;
    ruler.setAttribute('aria-valuemax', String(endFrame));
    ruler.setAttribute('aria-valuenow', String(frame));
    ruler.setAttribute('aria-valuetext', `Frame ${frame} of ${endFrame}`);
    if (playButton) {
      playButton.replaceChildren(icon(playing ? 'pause' : 'play_arrow', { size: 16 }));
      playButton.setAttribute('aria-label', playing ? 'Pause (Space)' : 'Play (Space)');
    }
    for (const node of tracks.querySelectorAll('.tl__key.is-current')) node.classList.remove('is-current');
    const selected = ctx.world.selectedEntry;
    if (selected) {
      const index = ctx.timeline.keyedEntries(ctx.world.entries).findIndex((e) => e.id === selected.id);
      const track = tracks.children[index];
      track?.querySelectorAll('.tl__key').forEach((node, i) => {
        if (Math.round(selected.keys[i]?.f) === frame) node.classList.add('is-current');
      });
    }
  }

  // Scrubbing
  let scrubbing = false;
  const scrub = (event) => ctx.commands.setFrame(frameFromClientX(event.clientX));
  surface.addEventListener('pointerdown', (event) => {
    if (event.target.closest('.tl__key') || event.target.closest('.tl__track-name')) return;
    scrubbing = true;
    surface.setPointerCapture?.(event.pointerId);
    scrub(event);
  });
  surface.addEventListener('pointermove', (event) => {
    if (!scrubbing) return;
    scrub(event);
  });
  surface.addEventListener('pointerup', (event) => {
    if (!scrubbing) return;
    scrubbing = false;
    surface.releasePointerCapture?.(event.pointerId);
  });
  surface.addEventListener('pointercancel', () => {
    scrubbing = false;
  });

  ruler.addEventListener('keydown', (event) => {
    if (event.key === 'ArrowLeft') {
      ctx.commands.stepFrame(-1);
      event.preventDefault();
    } else if (event.key === 'ArrowRight') {
      ctx.commands.stepFrame(1);
      event.preventDefault();
    } else if (event.key === 'Home') {
      ctx.commands.setFrame(1);
      event.preventDefault();
    } else if (event.key === 'End') {
      ctx.commands.setFrame(ctx.timeline.endFrame);
      event.preventDefault();
    }
  });

  counter.addEventListener('change', () => {
    const value = Number(counter.value);
    if (Number.isFinite(value)) ctx.commands.setFrame(value);
  });

  function render() {
    buildTransport();
    buildTracks();
    syncFrame();
  }

  ctx.bus.on('timeline.change', render);
  ctx.bus.on('timeline.play', () => {
    if (playButton) {
      playButton.replaceChildren(icon(ctx.timeline.playing ? 'pause' : 'play_arrow', { size: 16 }));
    }
  });
  ctx.bus.on('timeline.keys', render);
  ctx.bus.on('timeline.frame', syncFrame);
  ctx.bus.on('world.change', () => {
    buildTracks();
    syncFrame();
  });
  ctx.bus.on('selection.change', () => {
    buildTracks();
    syncFrame();
  });

  render();
  return { element, render, syncFrame };
}
