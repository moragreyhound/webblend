// Scene outliner: a filterable list of world entries with visibility toggles,
// inline rename and selection. It never mutates the scene directly - every
// action goes through ctx.commands so history/undo stays in one place.

import { h, clear, promptDialog } from './dom.js';
import { icon } from './icons.js';
import { getType } from '../objects/registry.js';

const MAX_ROWS = 500;

/**
 * @param {{ world: import('../world.js').World, commands: Record<string, Function> }} ctx
 */
export function createOutliner(ctx) {
  const list = h('ul', { class: 'outliner__list', role: 'list' });
  const count = h('span', { class: 'panel__count', text: '0' });
  const search = h('input', {
    class: 'input input--search',
    type: 'search',
    placeholder: 'Filter objects',
    'aria-label': 'Filter objects',
  });
  const overflow = h('p', { class: 'panel__note', hidden: true });

  const element = h(
    'aside',
    { class: 'panel panel--outliner', 'aria-label': 'Scene outliner' },
    h(
      'div',
      { class: 'panel__head' },
      h('h2', { class: 'panel__title', text: 'Scene' }),
      count,
    ),
    h('div', { class: 'panel__tools' }, search),
    list,
    overflow,
  );

  let query = '';
  search.addEventListener('input', () => {
    query = search.value.trim().toLowerCase();
    render();
  });

  function matches(entry) {
    if (!query) return true;
    return entry.name.toLowerCase().includes(query);
  }

  function row(entry, isSelected) {
    const type = getType(entry.typeId);
    const visibility = h('button', {
      class: 'iconbtn iconbtn--sm',
      type: 'button',
      'aria-label': `${entry.visible ? 'Hide' : 'Show'} ${entry.name}`,
      title: entry.visible ? 'Hide' : 'Show',
      'aria-pressed': String(entry.visible),
    });
    visibility.appendChild(icon(entry.visible ? 'visibility' : 'visibility_off', { size: 15 }));
    visibility.addEventListener('click', (event) => {
      event.stopPropagation();
      ctx.commands.setEntryVisible(entry, !entry.visible);
    });

    const select = h(
      'button',
      {
        class: 'outliner__select',
        type: 'button',
        'aria-pressed': String(isSelected),
        title: `${type?.label ?? entry.typeId} - double-click to rename`,
      },
      icon(type?.icon ?? 'deployed_code', { size: 15, className: 'outliner__icon' }),
      h('span', { class: 'outliner__name', text: entry.name }),
      entry.keys.length > 0
        ? icon('timeline', { size: 14, className: 'outliner__badge', label: `${entry.keys.length} keyframes` })
        : null,
    );
    select.addEventListener('click', () => ctx.world.select(entry.id));
    select.addEventListener('dblclick', () => rename(entry));

    const remove = h('button', {
      class: 'iconbtn iconbtn--sm outliner__remove',
      type: 'button',
      'aria-label': `Delete ${entry.name}`,
      title: 'Delete',
    });
    remove.appendChild(icon('delete', { size: 15 }));
    remove.addEventListener('click', (event) => {
      event.stopPropagation();
      ctx.commands.deleteEntry(entry);
    });

    const li = h(
      'li',
      { class: `outliner__row${isSelected ? ' is-selected' : ''}`, dataset: { id: entry.id } },
      visibility,
      select,
      remove,
    );
    return li;
  }

  async function rename(entry) {
    const next = await promptDialog({ title: 'Rename object', label: 'Name', value: entry.name });
    if (next !== null) ctx.commands.renameEntry(entry, next);
  }

  function emptyState() {
    if (query) {
      return h(
        'li',
        { class: 'outliner__empty' },
        h('p', { text: `No objects match “${query}”.` }),
        h('p', { class: 'muted', text: 'Try a shorter filter, or clear the search field.' }),
      );
    }
    return h(
      'li',
      { class: 'outliner__empty' },
      h('p', { text: 'The scene is empty.' }),
      h(
        'button',
        { class: 'btn btn--primary', type: 'button', text: 'Add a cube', on: { click: () => ctx.commands.create('cube') } },
      ),
      h('p', { class: 'muted', text: 'Or press Shift+A to open the Add menu.' }),
    );
  }

  function render() {
    clear(list);
    const entries = ctx.world.entries;
    count.textContent = String(entries.length);
    const visible = entries.filter(matches);
    if (visible.length === 0) {
      list.appendChild(emptyState());
      overflow.hidden = true;
      return;
    }
    const shown = visible.slice(0, MAX_ROWS);
    for (const entry of shown) list.appendChild(row(entry, ctx.world.selectedId === entry.id));
    if (visible.length > shown.length) {
      overflow.hidden = false;
      overflow.textContent = `Showing the first ${MAX_ROWS} of ${visible.length} objects. Refine the filter to find the rest.`;
    } else {
      overflow.hidden = true;
    }
  }

  // Keyboard navigation across rows: Up/Down move selection, F2/Enter rename.
  list.addEventListener('keydown', (event) => {
    if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') return;
    const rows = Array.from(list.querySelectorAll('.outliner__row'));
    if (rows.length === 0) return;
    const current = rows.findIndex((r) => r.classList.contains('is-selected'));
    const delta = event.key === 'ArrowDown' ? 1 : -1;
    const nextIndex = Math.min(rows.length - 1, Math.max(0, (current === -1 ? 0 : current + delta)));
    rows[nextIndex]?.querySelector('.outliner__select')?.focus();
    event.preventDefault();
  });

  ctx.bus.on('world.change', render);
  ctx.bus.on('world.entry', render);
  ctx.bus.on('selection.change', render);
  ctx.bus.on('timeline.keys', render);
  render();

  return { element, render };
}
