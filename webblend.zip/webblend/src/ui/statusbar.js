// Status bar: interaction mode, selection summary, scene stats and viewport fps.
// Updates are throttled so a 60fps render loop does not cause 60 DOM writes/s.

import { h } from './dom.js';

const FPS_INTERVAL = 250;

export function createStatusbar(ctx) {
  const modeChip = chip('mode', 'Object mode');
  const selChip = chip('sel muted', 'Nothing selected');
  const objectsChip = chip('stats', '0 objects');
  const vertsChip = chip('stats', '0 verts');
  const frameChip = chip('stats', 'frame 1 / 120');
  const fpsChip = chip('fps', '0 fps');
  const hint = chip('hint muted', 'Right-drag orbit · Middle-drag pan · Scroll zoom · WASD move · F frame');

  const element = h(
    'div',
    { class: 'statusbar', role: 'status', 'aria-live': 'off' },
    modeChip,
    selChip,
    objectsChip,
    vertsChip,
    frameChip,
    fpsChip,
    hint,
  );

  function render() {
    const { world, timeline, toolbarState } = ctx;
    const entry = world.selectedEntry;
    const stats = world.stats();

    modeChip.textContent = toolbarState.mode === 'edit' ? 'Edit mode' : 'Object mode';
    if (toolbarState.mode === 'edit' && entry) {
      selChip.textContent = `${ctx.editing.selected.size} / ${ctx.editing.vertexCount} vertices selected`;
    } else if (entry) {
      selChip.textContent = entry.name;
    } else {
      selChip.textContent = 'Nothing selected';
    }
    objectsChip.textContent = `${stats.total} object${stats.total === 1 ? '' : 's'}`;
    vertsChip.textContent = `${stats.vertices.toLocaleString()} verts`;
    frameChip.textContent = `frame ${timeline.frame} / ${timeline.endFrame}`;
  }

  function syncFrame() {
    frameChip.textContent = `frame ${ctx.timeline.frame} / ${ctx.timeline.endFrame}`;
  }

  function chip(kind, text) {
    return h('span', { class: `statusbar__item statusbar__item--${kind.split(' ')[0]}`, text });
  }

  let accumulator = 0;
  let lastFps = -1;
  ctx.onFrame((dt) => {
    accumulator += dt;
    if (accumulator * 1000 < FPS_INTERVAL) return;
    accumulator = 0;
    const fps = ctx.viewport.fps || 0;
    if (fps === lastFps) return;
    lastFps = fps;
    fpsChip.textContent = `${fps} fps`;
  });

  for (const type of ['selection.change', 'world.change', 'edit.selection', 'edit.change']) {
    ctx.bus.on(type, render);
  }
  ctx.bus.on('timeline.frame', syncFrame);

  render();
  return { element, render };
}
