// The animation timeline: frame clock, play/loop, and keyframe insertion.
// Keyframe *math* lives in keyframes.js (pure); this class owns state and emits
// bus events that the UI and the scene layer subscribe to.

import { bus } from '../core/bus.js';
import { upsertKey, removeKey, evalKeyframes } from './keyframes.js';
import { clamp } from '../core/math.js';

export const DEFAULT_FPS = 24;
export const DEFAULT_END_FRAME = 120;

export class Timeline {
  #accumulator = 0;

  constructor() {
    this.frame = 0;
    this.fps = DEFAULT_FPS;
    this.endFrame = DEFAULT_END_FRAME;
    this.loop = false;
    this.autoKey = false;
    this.playing = false;
  }

  /** Advance the playhead by `delta` seconds when playing. Returns the new frame. */
  tick(delta) {
    if (!this.playing) return this.frame;
    this.#accumulator += delta;
    const stepSeconds = 1 / this.fps;
    let steps = Math.floor(this.#accumulator / stepSeconds);
    this.#accumulator -= steps * stepSeconds;
    if (steps <= 0) return this.frame;

    let next = this.frame + steps;
    const last = this.endFrame;
    if (next > last) {
      if (this.loop) {
        next = ((next - 1) % (last + 1)) + 1; // frames are 1-based
      } else {
        next = last;
        this.pause();
      }
    }
    this.setFrame(next);
    return this.frame;
  }

  setFrame(frame) {
    const next = clamp(Math.round(frame), 1, Math.max(1, this.endFrame));
    if (next === this.frame) return;
    this.frame = next;
    bus.emit('timeline.frame', this.frame);
  }

  setEndFrame(endFrame) {
    const next = clamp(Math.round(endFrame), 1, 9999);
    this.endFrame = next;
    if (this.frame > next) this.setFrame(next);
    bus.emit('timeline.change', this.toJSON());
  }

  setFps(fps) {
    this.fps = clamp(Math.round(fps), 1, 120);
    bus.emit('timeline.change', this.toJSON());
  }

  play() {
    if (this.playing) return;
    this.playing = true;
    bus.emit('timeline.play', true);
  }

  pause() {
    if (!this.playing) return;
    this.playing = false;
    bus.emit('timeline.play', false);
  }

  toggle() {
    if (this.playing) this.pause();
    else this.play();
  }

  stop() {
    this.pause();
    this.setFrame(1);
  }

  hasKeys(entry) {
    return !!(entry && Array.isArray(entry.keys) && entry.keys.length > 0);
  }

  /** Insert a key for `entry` at the current frame (or an explicit frame). */
  insertKey(entry, frame = this.frame, transform) {
    if (!entry) return false;
    const key = {
      f: frame,
      position: transform.position,
      quaternion: transform.quaternion,
      scale: transform.scale,
    };
    if (transform.bones) key.bones = transform.bones;
    entry.keys = upsertKey(entry.keys ?? [], key);
    bus.emit('timeline.keys', { entryId: entry.id, frame: key.f, action: 'insert' });
    return true;
  }

  deleteKeyAt(entry, frame = this.frame) {
    if (!entry) return false;
    entry.keys = removeKey(entry.keys ?? [], frame);
    bus.emit('timeline.keys', { entryId: entry.id, frame, action: 'delete' });
    return true;
  }

  /** Evaluate an entry's keys at a frame (returns null when the entry has none). */
  evaluate(entry, frame = this.frame) {
    if (!this.hasKeys(entry)) return null;
    return evalKeyframes(entry.keys, frame);
  }

  /** All entries that carry keyframes, newest-first order is caller's concern. */
  keyedEntries(worldEntries) {
    return worldEntries.filter((entry) => this.hasKeys(entry));
  }

  clearKeys(entries) {
    for (const entry of entries) entry.keys = [];
    bus.emit('timeline.change', this.toJSON());
  }

  toJSON() {
    return {
      frame: this.frame,
      fps: this.fps,
      endFrame: this.endFrame,
      loop: this.loop,
      autoKey: this.autoKey,
      playing: this.playing,
    };
  }

  fromJSON(data) {
    if (!data) return;
    if (Number.isFinite(data.fps)) this.fps = clamp(Math.round(data.fps), 1, 120);
    if (Number.isFinite(data.endFrame)) this.endFrame = clamp(Math.round(data.endFrame), 1, 9999);
    this.loop = !!data.loop;
    this.autoKey = !!data.autoKey;
    this.playing = false;
    this.frame = clamp(Math.round(data.frame ?? 1), 1, this.endFrame);
  }
}