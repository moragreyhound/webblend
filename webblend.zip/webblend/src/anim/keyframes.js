// Keyframe interpolation. Pure math on plain arrays (no Three.js) so the
// sampling logic can be unit tested deterministically. The scene layer converts
// the returned arrays onto Object3D transforms.

import { clamp, lerp } from '../core/math.js';

/** Smooth ease-in-out, matching the studio's default interpolation feel. */
export function smoothstep(t) {
  const x = clamp(t, 0, 1);
  return x * x * (3 - 2 * x);
}

export function lerpArray(a, b, t) {
  const out = new Array(a.length);
  for (let i = 0; i < a.length; i += 1) out[i] = lerp(a[i], b[i], t);
  return out;
}

/**
 * Shortest-path spherical interpolation between quaternions [x, y, z, w].
 * Falls back to linear interpolation for (near) identical quaternions.
 */
export function slerpQuat(a, b, t) {
  let [ax, ay, az, aw] = a;
  let [bx, by, bz, bw] = b;
  let cos = ax * bx + ay * by + az * bz + aw * bw;
  if (cos < 0) {
    cos = -cos;
    bx = -bx; by = -by; bz = -bz; bw = -bw;
  }
  if (cos > 0.9995) {
    const out = [lerp(ax, bx, t), lerp(ay, by, t), lerp(az, bz, t), lerp(aw, bw, t)];
    return normalizeQuat(out);
  }
  const theta = Math.acos(clamp(cos, -1, 1));
  const sinTheta = Math.sin(theta);
  const wa = Math.sin((1 - t) * theta) / sinTheta;
  const wb = Math.sin(t * theta) / sinTheta;
  return normalizeQuat([
    ax * wa + bx * wb,
    ay * wa + by * wb,
    az * wa + bz * wb,
    aw * wa + bw * wb,
  ]);
}

export function normalizeQuat(q) {
  const len = Math.hypot(q[0], q[1], q[2], q[3]) || 1;
  return [q[0] / len, q[1] / len, q[2] / len, q[3] / len];
}

/** Binary search for the index of the last key whose frame <= target. */
export function findInsertIndex(keys, frame) {
  let lo = 0;
  let hi = keys.length - 1;
  while (hi - lo > 1) {
    const mid = (lo + hi) >> 1;
    if (keys[mid].f <= frame) lo = mid;
    else hi = mid;
  }
  return lo;
}

/**
 * Sample a transform at `frame`.
 * @param {Array<{f:number, position:number[], quaternion:number[], scale:number[], bones?:number[][]}>} keys
 * @returns {{position:number[], quaternion:number[], scale:number[], bones?:number[][]}|null}
 */
export function evalKeyframes(keys, frame) {
  if (!keys || keys.length === 0) return null;
  if (keys.length === 1) return cloneTransform(keys[0]);

  const first = keys[0];
  const last = keys[keys.length - 1];
  const f = clamp(frame, first.f, last.f);

  let a = first;
  let b = first;
  if (f >= last.f) {
    a = b = last;
  } else if (f > first.f) {
    const i = findInsertIndex(keys, f);
    a = keys[i];
    b = keys[i + 1] ?? keys[i];
  }

  const span = b.f - a.f;
  const e = span <= 0 ? 0 : smoothstep((f - a.f) / span);
  const result = {
    position: lerpArray(a.position, b.position, e),
    quaternion: slerpQuat(a.quaternion, b.quaternion, e),
    scale: lerpArray(a.scale, b.scale, e),
  };
  if (a.bones && b.bones) result.bones = lerpArray(a.bones, b.bones, e);
  else if (a.bones) result.bones = a.bones.map((row) => row.slice());
  return result;
}

export function cloneTransform(key) {
  const out = {
    position: key.position.slice(),
    quaternion: key.quaternion.slice(),
    scale: key.scale.slice(),
  };
  if (key.bones) out.bones = key.bones.map((row) => row.slice());
  return out;
}

/** Insert or replace a key at an integer frame; returns a new sorted array. */
export function upsertKey(keys, key) {
  const frame = Math.round(key.f);
  const next = keys.filter((k) => Math.round(k.f) !== frame);
  const pushed = {
    f: frame,
    position: key.position.slice(),
    quaternion: key.quaternion.slice(),
    scale: key.scale.slice(),
  };
  if (key.bones) pushed.bones = key.bones.map((row) => row.slice());
  next.push(pushed);
  next.sort((x, y) => x.f - y.f);
  return next;
}

export function removeKey(keys, frame) {
  return keys.filter((k) => Math.round(k.f) !== Math.round(frame));
}
