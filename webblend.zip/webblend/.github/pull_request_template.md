## Summary
<!-- What changed and why? Link the issue. -->

## Type
- [ ] feat  - [ ] fix  - [ ] perf  - [ ] refactor  - [ ] security  - [ ] docs  - [ ] chore

## AI Assistance Disclosure (required)
- [ ] No AI assistance
- [ ] AI-assisted (tool: <name>); a human reviewed and edited all output
- Human architect/approver: @<handle>
- Core design decisions authored or selected by a human: <describe briefly>

## Verification (exact commands + results)
```text
<command>  ->  <result>
```
**Not tested / known gaps:** <...>

## Security & Privacy
- [ ] New/changed routes have declared auth policy; no unintended public endpoints
- [ ] RLS present for SELECT/INSERT/UPDATE/DELETE with tests (if schema/policy touched)
- [ ] No secrets in code/logs; no private tokens in client bundle
- [ ] Inputs validated by schema; outputs use explicit DTOs
- [ ] Data inventory / approved-vendors updated (if data flows or SDKs changed)
- [ ] Consent, retention, and erasure paths covered
- [ ] SAST, SCA, secret scan green

## Licensing & IP
- [ ] No copyleft/unlicensed/near-verbatim code
- [ ] New dependencies reviewed; SBOM/THIRD_PARTY updated
- [ ] No third-party trademarks/assets without clearance

## UI / Brand / Accessibility (if UI changed)
- [ ] Brand principle(s) satisfied: <list>
- [ ] Tokens only; no raw values; screenshots (light/dark/mobile/desktop) attached
- [ ] All states implemented (loading/empty/error/success/offline/permission)
- [ ] Keyboard + screen-reader pass; axe clean; contrast verified
- [ ] Litmus tests (§5.5) passed

## Performance
- [ ] Budgets met; before/after metrics attached
- [ ] Query plans / indexes reviewed; caching reviewed

## Rollout
- Feature flag: <name/default>  - Rollback plan: <...>  - Monitoring: <dashboards/alerts>

## Accountability
- [ ] I have reviewed the entire diff and accept responsibility for this change ("the AI wrote it" is not a defense).
