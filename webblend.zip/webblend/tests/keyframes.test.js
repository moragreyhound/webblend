import test from 'node:test';
import assert from 'node:assert/strict';
import { evalKeyframes, upsertKey, removeKey, slerpQuat, smoothstep } from '../src/anim/keyframes.js';

const key = (f, pos) => ({ f, position: pos, quaternion: [0, 0, 0, 1], scale: [1, 1, 1] });

test('evalKeyframes returns null for an empty channel', () => {
  assert.equal(evalKeyframes([], 5), null);
  assert.equal(evalKeyframes(null, 5), null);
});

test('evalKeyframes holds the value before the first and after the last key', () => {
  const keys = [key(1, [0, 0, 0]), key(11, [10, 0, 0])];
  assert.deepEqual(evalKeyframes(keys, 1).position, [0, 0, 0]);
  assert.deepEqual(evalKeyframes(keys, 50).position, [10, 0, 0]);
});

test('evalKeyframes midpoint uses smoothstep easing (t=0.5 stays 0.5)', () => {
  const keys = [key(1, [0, 0, 0]), key(11, [10, 0, 0])];
  const mid = evalKeyframes(keys, 6).position;
  assert.ok(Math.abs(mid[0] - 5) < 1e-9, `expected ~5, got ${mid[0]}`);
});

test('evalKeyframes is monotonic through a simple channel', () => {
  const keys = [key(1, [0]), key(21, [20])];
  let previous = -Infinity;
  for (let f = 1; f <= 21; f += 1) {
    const v = evalKeyframes(keys, f).position[0];
    assert.ok(v >= previous, `non-monotonic at frame ${f}`);
    previous = v;
  }
});

test('slerpQuat halfway between identity and 90deg-Y yields 45deg-Y', () => {
  const half = Math.SQRT1_2;
  const a = [0, 0, 0, 1];
  const b = [0, half, 0, half];
  const q = slerpQuat(a, b, 0.5);
  const angle = 2 * Math.acos(Math.min(1, Math.abs(q[3])));
  assert.ok(Math.abs((angle * 180) / Math.PI - 45) < 0.1, `expected ~45deg, got ${(angle * 180) / Math.PI}`);
});

test('slerpQuat takes the shortest path for opposite hemispheres', () => {
  const a = [0, 0, 0, 1];
  const b = [0, 0, 0, -1]; // same rotation, negated
  const q = slerpQuat(a, b, 0.5);
  assert.ok(Math.abs(Math.abs(q[3]) - 1) < 1e-6);
});

test('upsertKey replaces an existing frame and keeps sorted order', () => {
  let keys = [key(1, [0]), key(5, [1])];
  keys = upsertKey(keys, key(5, [9]));
  assert.equal(keys.length, 2);
  assert.equal(keys.find((k) => k.f === 5).position[0], 9);
  keys = upsertKey(keys, key(3, [3]));
  assert.deepEqual(keys.map((k) => k.f), [1, 3, 5]);
});

test('removeKey deletes the matching frame', () => {
  const keys = removeKey([key(1, [0]), key(5, [1])], 5);
  assert.deepEqual(keys.map((k) => k.f), [1]);
});

test('smoothstep clamps outside [0,1]', () => {
  assert.equal(smoothstep(-3), 0);
  assert.equal(smoothstep(9), 1);
});
