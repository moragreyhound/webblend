import test from 'node:test';
import assert from 'node:assert/strict';
import { clamp, lerp, snap, round, degToRad, radToDeg } from '../src/core/math.js';

test('clamp bounds values and collapses NaN to the minimum', () => {
  assert.equal(clamp(5, 0, 10), 5);
  assert.equal(clamp(-3, 0, 10), 0);
  assert.equal(clamp(99, 0, 10), 10);
  assert.equal(clamp(Number.NaN, 2, 10), 2);
});

test('lerp interpolates', () => {
  assert.equal(lerp(0, 10, 0.5), 5);
  assert.equal(lerp(10, 0, 0.25), 7.5);
});

test('snap rounds to the step only when enabled', () => {
  assert.equal(snap(1.2, 0.5, true), 1);
  assert.equal(snap(1.2, 0.5, false), 1.2);
  assert.equal(snap(1.2, 0, true), 1.2);
});

test('round trims to the requested precision', () => {
  assert.equal(round(1.23456, 2), 1.23);
  assert.equal(round(1.005, 2), 1.01);
});

test('degree/radian conversion round-trips', () => {
  assert.ok(Math.abs(radToDeg(degToRad(90)) - 90) < 1e-9);
});
