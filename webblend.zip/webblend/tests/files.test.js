import test from 'node:test';
import assert from 'node:assert/strict';
import {
  extensionOf,
  baseNameOf,
  firstMtlLibrary,
  stripEditorNodes,
  validateProject,
  projectFileName,
  serializeProject,
  IMPORT_FORMATS,
  EXPORT_FORMATS,
} from '../src/io/format.js';

test('extensionOf lower-cases and ignores query/hash', () => {
  assert.equal(extensionOf('Model.OBJ'), 'obj');
  assert.equal(extensionOf('a/b/c.gltf?v=2'), 'gltf');
  assert.equal(extensionOf('archive.tar.gz'), 'gz');
});

test('extensionOf returns empty for dotless, dotfile and trailing-dot names', () => {
  assert.equal(extensionOf('README'), '');
  assert.equal(extensionOf('.gitignore'), '');
  assert.equal(extensionOf('trailing.'), '');
  assert.equal(extensionOf(''), '');
  assert.equal(extensionOf(null), '');
});

test('baseNameOf strips directories and extensions', () => {
  assert.equal(baseNameOf('C:\\models\\Robot.obj'), 'Robot');
  assert.equal(baseNameOf('assets/chair.glb'), 'chair');
  assert.equal(baseNameOf('plain'), 'plain');
  assert.equal(baseNameOf('Обезьяна.stl'), 'Обезьяна');
});

test('firstMtlLibrary reads the first mtllib reference only', () => {
  const obj = 'o Cube\nmtllib cube.mtl\nmtllib other.mtl\nv 0 0 0\n';
  assert.equal(firstMtlLibrary(obj), 'cube.mtl');
  assert.equal(firstMtlLibrary('v 0 0 0'), '');
  assert.equal(firstMtlLibrary(''), '');
});

test('import/export format lists are consistent and stable', () => {
  assert.deepEqual(IMPORT_FORMATS, ['obj', 'gltf', 'glb', 'stl', 'ply', 'fbx']);
  assert.deepEqual(EXPORT_FORMATS, ['glb', 'gltf', 'obj', 'stl']);
});

test('stripEditorNodes removes only the editor overlay nodes', () => {
  const makeNode = (name) => {
    const node = { name, children: [] };
    node.removeFromParent = () => {
      node.parent.children = node.parent.children.filter((c) => c !== node);
      node.parent = null;
    };
    return node;
  };
  const root = makeNode('Root');
  const helper = makeNode('__helper');
  const bone = makeNode('__bone');
  const real = makeNode('Body');
  const realChild = makeNode('__editor');
  real.children.push(realChild);
  realChild.parent = real;
  root.children.push(helper, bone, real);
  for (const child of root.children) child.parent = root;

  const nodes = [root, helper, bone, real, realChild];
  root.traverse = (fn) => { for (const n of nodes) fn(n); };

  stripEditorNodes(root);

  assert.deepEqual(root.children.map((n) => n.name), ['Body']);
  assert.deepEqual(real.children, []);
});

test('validateProject accepts a well-formed payload and both wrapper shapes', () => {
  const entry = { typeId: 'cube' };
  assert.deepEqual(validateProject({ app: 'webblend', world: { entries: [entry] } }), { ok: true });
  assert.deepEqual(validateProject({ entries: [entry] }), { ok: true });
  assert.deepEqual(validateProject({ entries: [] }), { ok: true });
});

test('validateProject rejects malformed input with a reason', () => {
  assert.match(validateProject(null).reason, /not a WebBlend project/);
  assert.match(validateProject({}).reason, /object list/);
  assert.match(validateProject({ entries: [null] }).reason, /malformed/);
  assert.match(validateProject({ entries: [{ typeId: 42 }] }).reason, /malformed/);
});

test('validateProject refuses an oversized object list', () => {
  const entries = Array.from({ length: 20001 }, () => ({ typeId: 'cube' }));
  assert.match(validateProject({ entries }).reason, /too many objects/);
});

test('projectFileName sanitizes names and defaults to scene', () => {
  assert.equal(projectFileName({ entries: [{ name: 'My Robot' }] }), 'My-Robot.webblend');
  assert.equal(projectFileName({ entries: [{ name: '../../etc/passwd' }] }), 'etc-passwd.webblend');
  assert.equal(projectFileName({ entries: [] }), 'scene.webblend');
  assert.equal(projectFileName({ entries: [{ name: '***' }] }), 'scene.webblend');
});

test('serializeProject stamps app/version and embeds the world payload', () => {
  const out = serializeProject({ serialize: () => ({ entries: [] }) });
  assert.equal(out.app, 'webblend');
  assert.equal(out.projectVersion, 1);
  assert.deepEqual(out.world, { entries: [] });
  assert.equal(typeof out.savedAt, 'string');
});
