import test from 'node:test';
import assert from 'node:assert/strict';
import { resolveWithin, MOUNTS } from '../server.js';

test('resolveWithin accepts files inside the base directory', () => {
  const base = 'C:/app/src';
  const resolved = resolveWithin(base, 'ui/toolbar.js');
  assert.ok(resolved);
  assert.ok(resolved.endsWith('ui\\toolbar.js') || resolved.endsWith('ui/toolbar.js'));
});

test('resolveWithin rejects parent traversal', () => {
  assert.equal(resolveWithin('C:/app/src', '../secret.txt'), null);
  assert.equal(resolveWithin('C:/app/src', 'ui/../../secret.txt'), null);
  assert.equal(resolveWithin('C:/app/src', '..%2f..%2fsecret'), null);
});

test('resolveWithin rejects dotfiles and hidden segments', () => {
  assert.equal(resolveWithin('C:/app/src', '.env'), null);
  assert.equal(resolveWithin('C:/app/src', 'ui/.hidden.js'), null);
});

test('resolveWithin rejects null bytes and empty input', () => {
  assert.equal(resolveWithin('C:/app/src', 'ui/a\0b.js'), null);
  assert.equal(resolveWithin('C:/app/src', ''), null);
  assert.equal(resolveWithin('C:/app/src', '///'), null);
});

test('resolveWithin rejects absolute-path injection', () => {
  // Windows drive-absolute and POSIX-absolute segments must not escape base.
  const a = resolveWithin('C:/app/src', 'C:/Windows/System32/drivers/etc/hosts');
  assert.ok(a === null || a.startsWith('C:\\app\\src') || a.startsWith('C:/app/src'));
});

test('mount allowlist exposes only expected prefixes', () => {
  const prefixes = MOUNTS.map((m) => m.prefix);
  assert.deepEqual(prefixes, ['/styles/', '/assets/', '/src/', '/vendor/three/']);
});
