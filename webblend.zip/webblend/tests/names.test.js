import test from 'node:test';
import assert from 'node:assert/strict';
import { uniqueName, baseName, sanitizeName } from '../src/core/names.js';

test('uniqueName returns the base name when free', () => {
  assert.equal(uniqueName('Cube', []), 'Cube');
});

test('uniqueName appends an incrementing suffix on collision', () => {
  assert.equal(uniqueName('Cube', ['Cube']), 'Cube 2');
  assert.equal(uniqueName('Cube', ['Cube', 'Cube 2']), 'Cube 3');
  assert.equal(uniqueName('Cube', ['Cube', 'Cube 2', 'Cube 3']), 'Cube 4');
});

test('sanitizeName strips control characters and collapses whitespace', () => {
  assert.equal(sanitizeName('  My\n\tObject  '), 'My Object');
  assert.equal(sanitizeName(''), 'Object');
  assert.equal(sanitizeName('   '), 'Object');
});

test('sanitizeName truncates to 64 characters', () => {
  const long = 'x'.repeat(200);
  assert.equal(sanitizeName(long).length, 64);
});

test('sanitizeName neutralizes a script-injection attempt as plain text', () => {
  const name = sanitizeName('<img src=x onerror=alert(1)>');
  assert.ok(!name.includes('\n'));
  assert.equal(typeof name, 'string');
});

test('baseName removes a trailing numeric suffix', () => {
  assert.equal(baseName('Cube 3'), 'Cube');
  assert.equal(baseName('Cube'), 'Cube');
  assert.equal(baseName('My 3D Model'), 'My 3D Model');
});
