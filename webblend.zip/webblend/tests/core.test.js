import test from 'node:test';
import assert from 'node:assert/strict';
import { Bus } from '../src/core/bus.js';
import { History } from '../src/core/history.js';

test('Bus delivers events to all subscribers', () => {
  const bus = new Bus();
  const seen = [];
  bus.on('x', (v) => seen.push(['a', v]));
  bus.on('x', (v) => seen.push(['b', v]));
  bus.emit('x', 1);
  assert.deepEqual(seen, [['a', 1], ['b', 1]]);
});

test('Bus unsubscribes via returned disposer', () => {
  const bus = new Bus();
  let count = 0;
  const off = bus.on('x', () => { count += 1; });
  bus.emit('x');
  off();
  bus.emit('x');
  assert.equal(count, 1);
});

test('Bus isolates a throwing listener', () => {
  const bus = new Bus();
  let reached = false;
  bus.on('x', () => { throw new Error('boom'); });
  bus.on('x', () => { reached = true; });
  assert.doesNotThrow(() => bus.emit('x'));
  assert.equal(reached, true);
});

test('History supports undo/redo and clears the redo branch on push', () => {
  const history = new History(10);
  assert.equal(history.canUndo(), false);
  history.push('s0');
  history.push('s1');
  assert.equal(history.undo('s2'), 's1');
  assert.equal(history.undo('s1'), 's0');
  assert.equal(history.redo('s0'), 's1');
  history.push('sX');
  assert.equal(history.canRedo(), false);
});

test('History enforces its capacity limit', () => {
  const history = new History(3);
  for (let i = 0; i < 10; i += 1) history.push(i);
  assert.equal(history.depth.undo, 3);
});

test('History drop removes the newest snapshot', () => {
  const history = new History(5);
  history.push('a');
  history.push('b');
  history.drop();
  assert.equal(history.undo('c'), 'a');
});
