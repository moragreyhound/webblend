# WebBlend Studio

A browser-based 3D creation suite — model, rig, animate, and simulate — built on
[three.js](https://threejs.org/). It runs entirely on your machine: there is no
backend, no account, and no telemetry. Imports, exports, and project files are
handled in the browser via the File API.

## Quick start

```sh
# macOS / Linux
./start.sh

# Windows
start.bat
```

Either script installs the one pinned dependency on first run and starts the
local server. Then open <http://127.0.0.1:5173>.

Or manually:

```sh
npm install
npm start
```

Requirements: Node.js 18 or newer and a WebGL2-capable browser.

## Commands

| Command | What it does |
| --- | --- |
| `npm start` | Serve the app at `http://127.0.0.1:5173` |
| `npm run check` | Syntax-check every first-party module (`node --check`) |
| `npm test` | Run the unit tests (`node --test`) |

Environment variables (all optional): `HOST` (default `127.0.0.1`) and `PORT`
(default `5173`). The server refuses to serve anything outside its allowlisted
mounts and rejects path traversal.

## Features

**Navigation** (Roblox Studio–style)
Right-drag orbits, middle-drag pans, scroll zooms. `WASD`/`QE` fly with
right-mouse look; a view cube and `Numpad` shortcuts snap to axis views.

**Modelling**
Primitives (cube, sphere, plane, cylinder, cone, torus, and more), a
vertex editor with box-select, and transform gizmos (move / rotate / scale) with
optional grid snap and local/world space.

**Shading**
Smooth, flat, and wireframe shading applied globally (View menu and toolbar).

**Rigging**
Armatures with bone chains; pose bones and reset the pose.

**Animation**
A keyframe timeline with per-object tracks, scrubbing, playback, loop, auto-key,
and frame/fps settings.

**Simulation**
GPU particle systems (dust, fire, smoke, snow, sparks …) with per-system
parameters, plus a smoke preset and an "emit burst" action.

**Import / export**
Import `.obj` (+`.mtl`), `.gltf`, `.glb`, `.stl`, `.ply`, and `.fbx` by picker or
drag-and-drop. Export `.glb`, `.gltf`, `.obj`, `.stl` (whole scene or selection).
Save and open `.webblend` project files.

**Editor chrome**
Outliner with filtering and visibility toggles, an inspector that edits
transform / geometry / material / light / camera / particles / armature, and
full keyboard access (`?` or `F1` for the shortcut list).

## Project layout

```
server.js            Zero-dependency static server with a nonce CSP
index.html           Shell + import map
public/styles/       tokens.css (design tokens) + app.css (components)
src/
  main.js            Entry point; error boundary
  app.js             Orchestrator: shell, commands, per-frame update
  world.js           Entry model, serialization, undo/redo
  core/              math, names, event bus, history, theme, version
  anim/              keyframes, timeline
  objects/           primitive registry, particles, armature
  scene/             viewport, camera, transform gizmo, picking, vertex editor
  io/                format helpers (pure) and file import/export (DOM/three)
  ui/                dom, icons, notifications, navcube, shortcuts, panels
tests/               node --test unit tests for the pure layers
```

Pure logic (core, anim, io/format) is kept free of DOM and three.js so it can be
unit-tested in Node; the DOM/WebGL layers are verified in the browser.

## Status and known limitations

- The three.js bundle means the initial JS payload exceeds the repository's
  170 KB budget. This is a known, in-progress exception — see `whereileft.md`.
- Imported models are serialized with `Object3D.toJSON`, which captures
  blob-URL texture sources that do not survive a page reload. Re-import the
  source files after reloading.
- The UI ships a dark theme. Light-theme tokens exist but are not yet wired to a
  toggle.
- Below 980 px wide the inspector hides; below 720 px the outliner hides. This is
  a desktop tool that expects a mouse for orbiting.

See `whereileft.md` for a full progress and handoff note.

## License

MIT. Rendering by three.js (MIT); see `THIRD_PARTY.md`.
