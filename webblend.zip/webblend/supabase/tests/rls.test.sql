-- Run with pgTAP. Pattern: prove ALLOW for owner, DENY for stranger/anon, for every operation.
begin;
select plan(8);

-- Fixtures (synthetic data only)
insert into auth.users (id, email) values
  ('00000000-0000-0000-0000-00000000000a', 'a@example.test'),
  ('00000000-0000-0000-0000-00000000000b', 'b@example.test');
insert into public.notes (id, owner_id, body) values
  ('11111111-1111-1111-1111-111111111111', '00000000-0000-0000-0000-00000000000a', 'A note');

-- RLS must be enabled
select ok((select relrowsecurity from pg_class where oid = 'public.notes'::regclass), 'RLS enabled on notes');

-- Act as user A (owner)
set local role authenticated;
set local request.jwt.claims = '{"sub":"00000000-0000-0000-0000-00000000000a"}';
select is((select count(*)::int from public.notes), 1, 'owner can SELECT own row');
select lives_ok($$update public.notes set body='edited' where id='11111111-1111-1111-1111-111111111111'$$, 'owner can UPDATE own row');

-- Act as user B (stranger)
set local request.jwt.claims = '{"sub":"00000000-0000-0000-0000-00000000000b"}';
select is((select count(*)::int from public.notes), 0, 'stranger cannot SELECT');
select throws_ok($$insert into public.notes (owner_id, body) values ('00000000-0000-0000-0000-00000000000a','spoof')$$,
  '42501', null, 'stranger cannot INSERT as another owner (WITH CHECK)');
select is((with d as (delete from public.notes where id='11111111-1111-1111-1111-111111111111' returning 1) select count(*)::int from d),
  0, 'stranger cannot DELETE');

-- Anonymous
set local role anon;
select is((select count(*)::int from public.notes), 0, 'anon cannot SELECT');

select * from finish();
rollback;
