# Third-Party Notices & Attributions

This project includes third-party software and assets under the licenses below.
Full license texts are in `/licenses/`. Generated from the SBOM on <YYYY-MM-DD>.

| Component | Version | License (SPDX) | Copyright holder(s) | Source URL | Modified? | Attribution/notice required |
|---|---|---|---|---|---|---|
| <package-name> | <x.y.z> | MIT | <Copyright (c) YEAR Holder> | <https://...> | No | Include license text |
| <apache-package> | <x.y.z> | Apache-2.0 | <Holder> | <https://...> | No | Include LICENSE and NOTICE |

## Copied or Adapted Code Blocks
| File / lines | Origin URL | Author | License | Attribution added where |
|---|---|---|---|---|
| <path:lines> | <url> | <author> | <license> | <inline header / this file> |

## Fonts, Icons, Images, Audio, Datasets
| Asset | Source | License | Attribution/Restrictions |
|---|---|---|---|
| <font/icon set> | <url> | <OFL-1.1 / etc.> | <...> |
