// WebBlend Studio - local static application server.
//
// Security posture (AGENTS.md 2.1 / 2.7):
//  - Binds to loopback by default; there is NO authentication because there is
//    no user data, no database, and no mutating API. The only non-asset route is
//    GET /healthz, which returns a constant and exposes no internals.
//  - Serves a fixed allowlist of directory mounts; path traversal is rejected
//    before any filesystem access.
//  - GET/HEAD only. Everything else is 405.
//  - Strict, nonce-based CSP for the one inline script (the import map).
//  - No directory listing, no dotfile serving, no source-map leaking of secrets.

import { createServer } from 'node:http';
import { createReadStream } from 'node:fs';
import { stat, readFile } from 'node:fs/promises';
import { randomBytes } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const HOST = process.env.HOST || '127.0.0.1';
const PORT = Number.parseInt(process.env.PORT || '5173', 10);

export const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.map': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.avif': 'image/avif',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.glb': 'model/gltf-binary',
  '.gltf': 'model/gltf+json',
  '.obj': 'text/plain; charset=utf-8',
  '.stl': 'model/stl',
  '.ply': 'application/octet-stream',
  '.wasm': 'application/wasm',
  '.txt': 'text/plain; charset=utf-8',
};

/** Directory mounts. A request may only resolve inside one of these. */
export const MOUNTS = [
  { prefix: '/styles/', dir: 'public/styles' },
  { prefix: '/assets/', dir: 'public/assets' },
  { prefix: '/src/', dir: 'src' },
  { prefix: '/vendor/three/', dir: 'node_modules/three' },
];

/**
 * Resolve a URL path safely inside `baseDir`.
 * Returns an absolute path, or null when the path is malformed or escapes baseDir.
 * Pure function - unit tested in tests/server-path.test.js.
 */
export function resolveWithin(baseDir, relPath) {
  if (typeof relPath !== 'string' || relPath.length === 0) return null;
  if (relPath.includes('\0')) return null;
  const segments = relPath.split(/[\\/]+/).filter((s) => s.length > 0);
  if (segments.length === 0) return null;
  if (segments.some((s) => s === '..' || s === '.' || s.startsWith('.'))) return null;
  const base = path.resolve(baseDir);
  const abs = path.resolve(base, ...segments);
  if (abs !== base && !abs.startsWith(base + path.sep)) return null;
  return abs;
}

function contentTypeFor(filePath) {
  return MIME[path.extname(filePath).toLowerCase()] || 'application/octet-stream';
}

function securityHeaders(nonce, { isHtml }) {
  const csp = [
    "default-src 'self'",
    `script-src 'self'${isHtml ? ` 'nonce-${nonce}'` : ''}`,
    "style-src 'self'",
    // Google-hosted Material Symbols icons are referenced by URL (see THIRD_PARTY.md).
    "img-src 'self' data: blob: https://fonts.gstatic.com",
    "font-src 'self'",
    "connect-src 'self' blob: data:",
    "worker-src 'self' blob:",
    "frame-ancestors 'none'",
    "base-uri 'none'",
    "form-action 'self'",
    "object-src 'none'",
  ].join('; ');
  return {
    'Content-Security-Policy': csp,
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=(), usb=()',
    'Cross-Origin-Opener-Policy': 'same-origin',
    'Cross-Origin-Resource-Policy': 'same-origin',
  };
}

async function sendFile(res, absPath, { nonce, cache, isHtml }) {
  let info;
  try {
    info = await stat(absPath);
  } catch {
    return sendError(res, 404, 'Not found');
  }
  if (!info.isFile()) return sendError(res, 404, 'Not found');

  const headers = {
    'Content-Type': contentTypeFor(absPath),
    'Content-Length': info.size,
    'Cache-Control': cache,
    ...securityHeaders(nonce, { isHtml }),
  };

  res.writeHead(200, headers);
  if (res.req.method === 'HEAD') return res.end();
  createReadStream(absPath).pipe(res);
}

function sendError(res, code, message) {
  const body = JSON.stringify({ error: message, code });
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...securityHeaders('', { isHtml: false }),
  });
  res.end(res.req.method === 'HEAD' ? undefined : body);
}

async function sendIndex(res, nonce) {
  const raw = await readFile(path.join(ROOT, 'index.html'), 'utf8');
  const html = raw.replaceAll('{{CSP_NONCE}}', nonce);
  res.writeHead(200, {
    'Content-Type': MIME['.html'],
    'Content-Length': Buffer.byteLength(html),
    'Cache-Control': 'no-store',
    ...securityHeaders(nonce, { isHtml: true }),
  });
  res.end(res.req.method === 'HEAD' ? undefined : html);
}

export function createApp() {
  return createServer(async (req, res) => {
    const nonce = randomBytes(16).toString('base64');

    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.setHeader('Allow', 'GET, HEAD');
      return sendError(res, 405, 'Method not allowed');
    }

    let pathname;
    try {
      pathname = new URL(req.url, 'http://localhost').pathname;
    } catch {
      return sendError(res, 400, 'Bad request');
    }

    // Public route allowlist: the app shell and a constant liveness probe.
    if (pathname === '/' || pathname === '/index.html') {
      try {
        return await sendIndex(res, nonce);
      } catch {
        return sendError(res, 500, 'Failed to render index');
      }
    }
    if (pathname === '/healthz') {
      res.writeHead(200, {
        'Content-Type': 'application/json; charset=utf-8',
        'Cache-Control': 'no-store',
        ...securityHeaders(nonce, { isHtml: false }),
      });
      return res.end(JSON.stringify({ status: 'ok' }));
    }
    if (pathname === '/favicon.ico') {
      return sendError(res, 404, 'Not found');
    }

    for (const mount of MOUNTS) {
      if (!pathname.startsWith(mount.prefix)) continue;
      const rel = pathname.slice(mount.prefix.length);
      const abs = resolveWithin(path.join(ROOT, mount.dir), rel);
      if (!abs) return sendError(res, 400, 'Invalid path');
      const isVendor = mount.prefix.startsWith('/vendor/');
      const cache = isVendor
        ? 'public, max-age=31536000, immutable'
        : 'no-store';
      return sendFile(res, abs, { nonce, cache, isHtml: false });
    }

    return sendError(res, 404, 'Not found');
  });
}

const server = createApp();
server.requestTimeout = 30_000;
server.headersTimeout = 20_000;

const isEntryPoint =
  typeof process.argv[1] === 'string' &&
  import.meta.url === pathToFileURL(process.argv[1]).href;

if (isEntryPoint) {
  server.listen(PORT, HOST, () => {
    const url = `http://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${PORT}/`;
    console.log(`\n  WebBlend Studio\n  serving ${ROOT}\n  ${url}\n`);
    if (HOST === '0.0.0.0') {
      console.warn('  WARNING: bound to all interfaces. This server has no authentication.\n');
    }
  });
  const shutdown = () => server.close(() => process.exit(0));
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

export default server;
